<?php
$_SESSION['api_id'][] = '1a4339a6d005f9c408391901068f892d';
$root = "gestion";
$Dir = $_SERVER["DOCUMENT_ROOT"]."/".$root."/excels"; //Directorio de archivos subidos
$ODir = "../".$root."/excels";

define("ROOT", "gestion");
define("NOMBRE_USUARIO", $_SESSION['api_id']['nombre']);
define("APELLIDO_USUARIO", $_SESSION['api_id']['apellido']);
define("PRIVILEGIO", $_SESSION['api_id']['nPrivilegio']);
define("JS", "https://".basename($_SERVER['SERVER_NAME'])."/".$root."/styles/js");
define("CSS", "https://".basename($_SERVER['SERVER_NAME'])."/".$root."/styles/css");
define("IMAGES", "https://".basename($_SERVER['SERVER_NAME'])."/".$root."/styles/images");
define("NOW", date('Y'));
ini_set("session.cookie_lifetime","30000");
ini_set("session.gc_maxlifetime","30000");

?>
