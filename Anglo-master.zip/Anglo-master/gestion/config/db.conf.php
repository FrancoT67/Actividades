<?php
define("DB_HOST", "localhost");
define("DB_USER", "clubangloviejo_user");
define("DB_PASS", "clubAngloViejoMente2019");
define("DB_NAME", "clubangloviejo");
?>
