<?php

/* ////////////////////////////////////////////////////////////////////////////////// */

function EnviarAlerta($tipo, $mensaje){
    echo $tipo.",".$mensaje;
}

function ErrorPrivilegio(){
    include('views/error.phtml');
}

function FormatDate($fecha){
    $dia=date("d",strtotime($fecha));
    $mes=date("m",strtotime($fecha));
    $ano=date("Y",strtotime($fecha));

    if($ano == '0000'){
      $fechaN = "";
    }else{
      $fechaN = $dia."/".$mes."/".$ano;
    }

    return $fechaN;
}

function FechaJuliana($fecha){

  $dia=date("d",strtotime($fecha));

  $mes=date("m",strtotime($fecha));

  $ano=date("Y",strtotime($fecha));


  return gregoriantojd ( $mes , $dia , $ano );
}

function GetDif($fecha){

    /*$dia=date("d");
    $mes=date("m");
    $ano=date("Y");

    $dia2=date("d",strtotime($fecha));
    $mes2=date("m",strtotime($fecha));
    $ano2=date("Y",strtotime($fecha));

    if($ano >= $ano2 && (($mes == $mes2 && $dia >= $dia2) || $mes > $mes2)){
        $mayor = true;
    }else{
        $mayor = false;
    }*/

    return FechaJuliana(date($fecha)) - FechaJuliana(date('Y-n-j'));

}

?>
