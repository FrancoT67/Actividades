<?php
session_start();
require("core/core.php");
require("config/sys.conf.php");
require("models/class.User.php");
require("models/class.Socio.php");
require("models/class.Deportivo.php");

define("TITLE", 'Campeonatos');

//Llamada a la vista
if($_SESSION['api_id']['login'])
{

  $user = new User($_SESSION['api_id']['uid']);

  define("PRIVILEGIO", $temp);

  $accion = (!empty($_POST['funcion'])) ? $_POST['funcion'] : ((!empty($vista[1])) ? $vista[1] : 'index');
  $dato = (!empty($_POST['dato'])) ? $_POST['dato'] : ((!empty($vista[2])) ? $vista[2] : NULL);

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR || $_SESSION['api_id']['uPrivilegio'] == User::TIPO_ESTADISTA || $_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO)
  {
    call_user_func($accion, $dato);
  }else{
    ErrorPrivilegio();
  }

}else
{
  //Llamada a la vista
  header("Location: /".$root."/login");
}

//Funcion muestra vista Indice
function index () {

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR || $_SESSION['api_id']['uPrivilegio'] == User::TIPO_ESTADISTA)
  {
    require_once("views/campeonatos.phtml");

  }else if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
    header("Location: /".$root."/logout");
  }else{
    ErrorPrivilegio();
  }

}

//Funcion muestra vista agregar
function agregar (){

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR)
  {
    $funcion = 'insertar';

    $ListaCategorias = Categoria::ListarCategorias();

    require_once("views/campeonatos_agregar.phtml");

  }else if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
    header("Location: /".$root."/logout");
  }else{
    ErrorPrivilegio();
  }

}

//Funcion info campeonato
function InfoCampeonato ($dato) {
  $campeonato = new Campeonato($dato);

  $resultado = array("cmid" => $campeonato->GetCmid(), "Nombre" => $campeonato->GetNombre(), "categoria" => $campeonato->GetCategoria(), "tipo" => $campeonato->GetTipo());

  echo json_encode($resultado);
}

//Funcion Insertar Campeonato Liga
function InsertarCampeonatoLiga () {

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR)
  {

    $nombre = $_POST['nombre'];
    $categoria = $_POST['categoria'];
    $fCreacion = date('Y-n-j');
    $tipo = $_POST['tipo'];

    $campeonato = new Campeonato(0, $nombre, $fCreacion, $categoria, 0, $tipo);
    $cmid = $campeonato->registro();

    if(is_numeric($cmid)) {

      $equipos = Equipo::ListarEquipos(0, 0, NULL, $categoria, NULL);

      //Calculo el total de eequipos
      $countequipos = count($equipos);
      //Calculo el total de fechas
      $countfechas = $countequipos -1;

      if($countequipos > 2){

        if($countequipos % 2 != 0){
          array_push($equipos, array('eid' => 0));
          $countequipos++;
          $countfechas++;
        }

        //Separo los dos primeros equipos
        $primerosequipos = array_slice($equipos, 0, 2); // 1, 2
        //Obtengo el resto de los equipos
        $restoequipos = array_slice($equipos, 2); // 3,4,5...
        //Invierto el orden del resto de los equipos
        $reversa = array_reverse($restoequipos);

        //Uno los dos array
        $completo = array_merge($primerosequipos, $reversa);

        // Primera fecha

        $array2[0] = $completo[1];

        for($i = 0; $i < ($countequipos - 2)/2; $i++){
          $array2[$i+1] = $completo[$i + 2];
          $array3[$i] = $completo[$countequipos-$i-1];
        }

        $array3 = array_reverse($array3);
        $array2 = array_merge($array2, $array3);

        $fecha[0] = $array2;

        // Resto de las fechas
        for($f = 0; $f < $countfechas - 1; $f++){
          $ultimo = $array2[count($array2) - 1];
          for($i = count($array2) - 1; $i > 0; $i--){
            $array2[$i] = $array2[$i-1];
          }
          $array2[0] = $ultimo;
          $fecha[$f+1] = $array2;
        }

        for($f = 0; $f < $countfechas; $f++){
          if($fecha[$f][0]['eid'] > 0){
            $campeonato->InsertarFecha($cmid, $equipos[0]['eid'], $fecha[$f][0]['eid'], $f+1, NULL, NULL, 0);
          }
          for($i = 0; $i < (count($fecha[$f]) - 2)/2; $i++){
            if($fecha[$f][$i + 1]['eid'] > 0 && $fecha[$f][count($fecha[$f])-$i-1]['eid'] > 0){
              $campeonato->InsertarFecha($cmid, $fecha[$f][count($fecha[$f])-$i-1]['eid'], $fecha[$f][$i + 1]['eid'], $f+1, NULL, NULL, 0);
            }
          }
        }

        if($f >= $countfechas){

          EnviarAlerta('success', 'Se creo correctamente el campeonato');

        }else{

          EnviarAlerta('error', 'No se pudieron crear las fechas');

        }
      }
    }else{

      EnviarAlerta('error', 'No se pudieron crear el campeonato');

    }

  }else if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
    header("Location: /".$root."/logout");
  }else{
    ErrorPrivilegio();
  }
}

//Funcion Insertar Campeonato Zonal
function InsertarCampeonatoZonal () {

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR)
  {

    $nombre = $_POST['nombre'];
    $categoria = $_POST['categoria'];
    $fCreacion = $_POST['fCreacion'];
    $zonas = $_POST['zonas'];
    $tipo = $_POST['tipo'];

    $campeonato = new Campeonato(0, $nombre, $fCreacion, $categoria, 0, $tipo);
    $cmid = $campeonato->registro();

    if(is_numeric($cmid) && count($zonas) > 2 && count($zonas['equipos']['datos']) < 1){
      foreach($zonas as $i => $zona){
        if($zona['nombre'] != 'Equipos'){

          $equipos = array();
          $fechas = array();
          $array2 = array();

          //echo "\nNombre:".$zona['nombre']." ID: ".$zona['id']."\n\n";
          //echo "-----------------------------\n\n";
          $countequipos = count($zona['datos']);

          $equipos = (array) $zona['datos'];

          //Calculo el total de fechas
          $countfechas = $countequipos -1;

          if($countequipos > 2){

            if($countequipos % 2 != 0){
              array_push($equipos, array('eid' => 0));
              $countequipos++;
              $countfechas++;
            }

            //Separo los dos primeros equipos
            $primerosequipos = array_slice($equipos, 0, 2); // 1, 2
            //Obtengo el resto de los equipos
            $restoequipos = array_slice($equipos, 2); // 3,4,5...
            //Invierto el orden del resto de los equipos
            $reversa = array_reverse($restoequipos);

            //Uno los dos array
            $completo = array_merge($primerosequipos, $reversa);

            // Primera fecha
            $array2[0] = $completo[1];

            for($i = 0; $i < ($countequipos - 2)/2; $i++){
              $array2[$i+1] = $completo[$i + 2];
              $array3[$i] = $completo[$countequipos-$i-1];
            }

            $array3 = array_reverse($array3);
            $array2 = array_merge($array2, $array3);

            $fecha[0] = $array2;

            // Resto de las fechas
            for($f = 0; $f < $countfechas - 1; $f++){
              $ultimo = $array2[count($array2) - 1];
              for($i = count($array2) - 1; $i > 0; $i--){
                $array2[$i] = $array2[$i-1];
              }
              $array2[0] = $ultimo;
              $fecha[$f+1] = $array2;
            }

            for($f = 0; $f < $countfechas; $f++){
              //echo "\n";
              //echo "fecha ".($f+1)."\n";
              //echo "================\n";
              if($fecha[$f][0]['eid'] > 0){
                //    echo $equipos[0]['nombre']." contra ".$fecha[$f][0]['nombre']."\n";
                $campeonato->InsertarFecha($cmid, $equipos[0]['eid'], $fecha[$f][0]['eid'], $f+1, NULL, NULL, 0, $zona['id']);
              }
              for($i = 0; $i < (count($fecha[$f]) - 2)/2; $i++){
                if($fecha[$f][$i + 1]['eid'] > 0 && $fecha[$f][count($fecha[$f])-$i-1]['eid'] > 0){
                  $campeonato->InsertarFecha($cmid, $fecha[$f][count($fecha[$f])-$i-1]['eid'], $fecha[$f][$i + 1]['eid'], $f+1, NULL, NULL, 0, $zona['id']);
                  //echo $fecha[$f][count($fecha[$f])-$i-1]['nombre']." contra ".$fecha[$f][$i + 1]['nombre']."\n";
                }
              }
            }

            if($f >= $countfechas){

              EnviarAlerta('success', 'Se creo correctamente el campeonato');

            }else{

              EnviarAlerta('error', 'No se pudieron crear las fechas');

            }
          }

        }
      }

    }else{

      EnviarAlerta('error', 'No se pudo crear el campeonato');

    }

  }else if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
    header("Location: /".$root."/logout");
  }else{
    ErrorPrivilegio();
  }
}


//Funcion Ver
function ver ($dato){

  require_once("views/campeonatos_ver.phtml");

}

//Funcion Ver Partido
function partido ($dato) {
  require_once("views/campeonatos_partido.phtml");
}

//Funcion Consulta campeonato
function ConsultaCampeonato ($dato) {

  $campeonato = new Campeonato($dato);

  $partidos = $campeonato->ListarFechas();
  $objPartido = new Partido();

  $anteriorFecha = 0;
  $fechas = array();

  if(is_array($partidos) || is_object($partidos))
  {
    foreach($partidos as $partido)
    {
      $equipo1 = Equipo::ObtenerPorId($partido['eid1']);
      $equipo2 = Equipo::ObtenerPorId($partido['eid2']);

      $totalGolesEquipo1 = 0;
      $totalGolesEquipo2 = 0;

      $golesEquipo1 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid1']);

      if(is_array($golesEquipo1) || is_object($golesEquipo1)){
        foreach($golesEquipo1 as $goles){
          $totalGolesEquipo1 += $goles['cantidad'];
        }
      }

      $golesEquipo2 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid2']);

      if(is_array($golesEquipo2) || is_object($golesEquipo2)){
        foreach($golesEquipo2 as $goles){
          $totalGolesEquipo2 += $goles['cantidad'];
        }
      }

      $partido['equipo1']['nombre'] = $equipo1->GetNombre();
      $partido['equipo2']['nombre'] = $equipo2->GetNombre();

      if($partido['eid1'] == $partido['suspendido']){
        $partido['equipo1']['goles'] = "GP";
        $partido['equipo2']['goles'] = "PP";
      }else if($partido['eid2'] == $partido['suspendido']){
        $partido['equipo2']['goles'] = "GP";
        $partido['equipo1']['goles'] = "PP";
      }else if($partido['suspendido'] == 0){
        $partido['equipo2']['goles'] = "PP";
        $partido['equipo1']['goles'] = "PP";
      }else{
        $partido['equipo1']['goles'] = $totalGolesEquipo1;
        $partido['equipo2']['goles'] = $totalGolesEquipo2;
      }

      $partidosjson[] = $partido;

      if($anteriorFecha != $partido['fecha']){
        $anteriorFecha = $partido['fecha'];
        //$fechas[] = array("fecha" => $partido['fecha']);
        array_push($fechas, $partido['fecha']);
      }
    }
  }

  $fechas = array_unique($fechas);

  sort($fechas);

  $resultado = array("fechas" => $fechas, "partidos" => $partidosjson);

  echo json_encode($resultado);
}

function provi($dato){
  $campeonato = new Campeonato($dato);

  $partidos = $campeonato->ListarFechas();
  $objPartido = new Partido();

  $equipos = array();

  if(is_array($partidos) || is_object($partidos))
  {
    foreach($partidos as $partido)
    {
      if(!in_array($partido['eid1'], $equipos)){
        $equipos[] = $partido['eid1'];
        $equipos[count($equipos)-1] = Equipo::ListarEquipos($partido['eid1'])[0];
      }

      if(!in_array($partido['eid2'], $equipos)){
        $equipos[] = $partido['eid2'];
        $equipos[count($equipos)-1] = Equipo::ListarEquipos($partido['eid2'])[0];
      }

    }
  }

}

//Funcion Consulta posiciones campeonato
function ConsultaPosicionesCampeonato ($dato) {
  $campeonato = new Campeonato($dato);

  $partidos = $campeonato->ListarFechas();

  $equipos = array();

  if(is_array($partidos) || is_object($partidos))
  {
    foreach($partidos as $partido)
    {
      if(!in_array($partido['eid1'], $equipos)){
        $equipos[] = $partido['eid1'];
        //$obj = Equipo::ObtenerPorId($partido['eid1']);
        //  $equipos[count($equipos)-1] = array("eid" => $obj->getId(), "nombre" => $obj->getNombre(), "categoria" => $obj->getCategoria());
        //$lista = Equipo::ListarEquipos($partido['eid1']);
        //$equipos[count($equipos)-1] = $lista[0];
      }

      if(!in_array($partido['eid2'], $equipos)){
        $equipos[] = $partido['eid2'];
        //$obj = Equipo::ObtenerPorId($partido['eid2']);
        //$equipos[count($equipos)-1] = array("eid" => $obj->getId(), "nombre" => $obj->getNombre(), "categoria" => $obj->getCategoria());
        //$lista = Equipo::ListarEquipos($partido['eid2']);
        //$equipos[count($equipos)-1] = $lista[0];
      }

    }
  }

  //$equipos = Equipo::ListarEquipos(0, 0, NULL, $campeonato->GetCategoria());
  $objPartido = new Partido();

  $timeNow = date('H:i:s');

  $zonas = array();
  $instancias = array();

  if(is_array($equipos) || is_object($equipos)){
    foreach($equipos as $i => $equipo){
      $obj = Equipo::ObtenerPorId($equipo);
      $equipos[$i] = array("eid" => $obj->getId(), "nombre" => $obj->getNombre(), "categoria" => $obj->getCategoria());
      $equipo = $equipos[$i];
      
      //$goles = $objPartido->ListarGoles(0,  0, 0, $equipo['eid']);
      $partidos = $campeonato->ListarFechas(0, $equipo['eid']);
      if(is_array($partidos)) {
        $firstPartido = end($partidos);
        $lastPartido = $partidos[0];
      } else {
        $lastPartido['zona'] = 0;
      }
      $equipos[$i]['pj'] = 0;
      $equipos[$i]['pg'] = 0;
      $equipos[$i]['pe'] = 0;
      $equipos[$i]['pp'] = 0;
      $equipos[$i]['gf'] = 0;
      $equipos[$i]['gc'] = 0;
      $equipos[$i]['pts'] = 0;
      $equipos[$i]['estado'] = "";
      $equipos[$i]['ps'] = 0; //Partidos suspendidos
      $equipos[$i]['zona'] = $lastPartido['zona'];
      $zonas[] = $lastPartido['zona'];
      //if($firstPartido['instancia']) {
        foreach ($partidos as $partido) {
          if (!empty($partido['instancia'])) {
            $instancias[] = $partido['instancia'];
          }
        }
      //}
      if(is_array($partidos) || is_object($partidos)){
        foreach($partidos as $partido){

          $DiffTime = strtotime($partido['hPartido']) - strtotime($timeNow);
          $DiffDate = FechaJuliana(date($partido['fPartido'])) - FechaJuliana(date('Y-n-j'));

          //$equipos[$i]['pj'] .= $DiffDate." ";

          if(($DiffDate < 0 && $partido['fPartido'] != '0000-00-00' && $partido['fecha'] > 0 && empty($partido['instancia'])) || ($DiffDate == 0 && $DiffTime < 0 && $partido['fPartido'] != '0000-00-00' && $partido['fecha'] > 0 && empty($partido['instancia']))){
            $equipos[$i]['pj']++;
            $golesEquipo1 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid1']);
            $golesEquipo2 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid2']);

            $totalGolesEquipo1 = 0;
            $totalGolesEquipo2 = 0;

            if($partido['suspendido'] == -1){

              $golesEquipo1 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid1']);

              if(is_array($golesEquipo1) || is_object($golesEquipo1)){
                foreach($golesEquipo1 as $goles){
                  $totalGolesEquipo1 += $goles['cantidad'];
                }
              }

              $golesEquipo2 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid2']);

              if(is_array($golesEquipo2) || is_object($golesEquipo2)){
                foreach($golesEquipo2 as $goles){
                  $totalGolesEquipo2 += $goles['cantidad'];
                }
              }

              if($partido['eid1'] == $equipo['eid']){
                $equipos[$i]['gf'] += $totalGolesEquipo1;
                $equipos[$i]['gc'] += $totalGolesEquipo2;
                if($totalGolesEquipo1 > $totalGolesEquipo2){
                  $equipos[$i]['pg'] += 1;
                  $equipos[$i]['pts'] += 3;
                }else if($totalGolesEquipo1 < $totalGolesEquipo2){
                  $equipos[$i]['pp'] += 1;
                }
              }else if($partido['eid2'] == $equipo['eid']){
                $equipos[$i]['gc'] += $totalGolesEquipo1;
                $equipos[$i]['gf'] += $totalGolesEquipo2;
                if($totalGolesEquipo2 > $totalGolesEquipo1){
                  $equipos[$i]['pg'] += 1;
                  $equipos[$i]['pts'] += 3;
                }else if($totalGolesEquipo2 < $totalGolesEquipo1){
                  $equipos[$i]['pp'] += 1;
                }
              }

              if($totalGolesEquipo2 == $totalGolesEquipo1){
                $equipos[$i]['pe'] += 1;
                $equipos[$i]['pts'] += 1;
              }
            }else{
              if($partido['suspendido'] == $equipos[$i]['eid']){
                $equipos[$i]['pg'] += 1;
                $equipos[$i]['pts'] += 3;
              }else if($partido['suspendido'] != $equipos[$i]['eid']){
                $equipos[$i]['pp'] += 1;
                $equipos[$i]['ps'] += 1;
              }
            }
          }
        }
        $descuento = $campeonato->VerPuntosDescontados($equipos[$i]['eid']);
        $equipos[$i]['pts'] -= $descuento['total'];
      }else{
        $equipos[$i]['nombre'] = '';
        $equipos[$i]['pts'] = -9999;
        $equipos[$i]['gc'] = 9999;
        $equipos[$i]['ps'] = 9999;
      }
    }
  }

  if(is_array($equipos) || is_object($equipos)){
    $cantidadEquipos = count($equipos);
    for($i = 0; $i < $cantidadEquipos; $i++){
      for($j = $i; $j < $cantidadEquipos; $j++){
        // Ordenamos equipos por puntos Equipo i < Equipo j
        if($equipos[$i]['pts'] < $equipos[$j]['pts']){
          $temp = $equipos[$i];
          $equipos[$i] = $equipos[$j];
          $equipos[$j] = $temp;
          // Ordenamos equipos si tienen los mismos puntos
        }else if($equipos[$i]['pts'] == $equipos[$j]['pts']){
          // Ordenamos equipos por partidos suspendidos Equipo i > Equipo j
          if($equipos[$i]['ps'] > $equipos[$j]['ps']){
            $temp = $equipos[$i];
            $equipos[$i] = $equipos[$j];
            $equipos[$j] = $temp;
            // Ordenamos si tienen la misma cantidad de partidos suspendidos
          }else if($equipos[$i]['ps'] == $equipos[$j]['ps']){
            // Ordena por partidos entre si
            $comparacion = CompararPartidos($dato, $equipos[$i]['eid'], $equipos[$j]['eid']);
            if($comparacion == 2){
              $temp = $equipos[$i];
              $equipos[$i] = $equipos[$j];
              $equipos[$j] = $temp;
            }
            // Ordenamos por diferencia de goles a favor menos goles en contra
            if(($equipos[$i]['gf']-$equipos[$i]['gc']) < ($equipos[$j]['gf']-$equipos[$j]['gc'])){
              $temp = $equipos[$i];
              $equipos[$i] = $equipos[$j];
              $equipos[$j] = $temp;
            }
            
          }
        }
      }
    }
  }

  $zonas = array_unique($zonas);

  $instancias = array_unique($instancias);

  $zonas = array_diff($zonas, [0]);

  sort($zonas);
  sort($instancias);

  echo json_encode(array("equipos" => $equipos, "zonas" => $zonas, "instancias" => $instancias));
}

// Funcion comparar partidos jugados entre si y ver quien gano mas partidos
function CompararPartidos ($cmid, $eid1, $eid2) {
  $objPartido = new Partido();
  $campeonato = new Campeonato($cmid);
  $pg1 = 0;
  $pg2 = 0;
  $partidos = $campeonato->ListarFechas(0, 0, $eid1, $eid2);
  if(is_array($partidos) || is_object($partidos)){
    foreach($partidos as $partido){
      $DiffTime = strtotime($partido['hPartido']) - strtotime($timeNow);
      $DiffDate = FechaJuliana(date($partido['fPartido'])) - FechaJuliana(date('Y-n-j'));
      if(($DiffDate < 0 && $partido['fPartido'] != '0000-00-00' ) || ($DiffDate == 0 && $DiffTime < 0 && $partido['fPartido'] != '0000-00-00' )){
        $golesEquipo1 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $eid1);
        $golesEquipo2 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $eid2);

        if($golesEquipo1 > $golesEquipo2){
          $pg1++;
        }else if($golesEquipo1 < $golesEquipo2){
          $pg2++;
        }
      }
    }
  }

  if($pg1 == $pg2){
    return 0;
  }else if($pg1 > $pg2){
    return 1;
  }else if($pg1 < $pg2){
    return 2;
  }
}

// Funcion quitar puntos a equipo en campeonato
function QuitarPuntos () {
  $cmid = $_POST['cmid'];
  $puntos = $_POST['puntos'];
  $eid = $_POST['eid'];
  $descripcion = $_POST['descripcion'];

  $campeonato = new Campeonato($cmid);

  $resultado = $campeonato->QuitarPuntos($eid, $puntos, $descripcion);

  if($resultado == 1){

    EnviarAlerta('success', 'Se modifico correctamente: '.$resultado);

  }else{

    EnviarAlerta('error', 'No se pudo modificar: '.$resultado);

  }
}

//Funcion Cambiar nombre del campeonato
function CambiarNombreCampeonato () {
  $cmid = $_POST['cmid'];
  $nombre = $_POST['nombre'];

  $campeonato = new Campeonato($cmid, $nombre);

  $resultado = $campeonato->modificar();

  if($resultado == 1){

    EnviarAlerta('success', 'Se modifico correctamente: '.$resultado);

  }else{

    EnviarAlerta('error', 'No se pudo modificar: '.$resultado);

  }

}

//Funcion Cambiar fecha partidos del campeonato
function CambiarFechaPartidos () {
  $cmid = $_POST['cmid'];
  $fecha = $_POST['fecha'];
  $fPartidos = $_POST['fPartidos'];

  if($fPartidos == NULL){
    $fPartidos = '0000-00-00';
  }

  $campeonato = new Campeonato();

  $resultado = $campeonato->EditarPartido(0, $cmid, 0, 0, $fecha, $fPartidos, NULL, 0);

  if($resultado){

    EnviarAlerta('success', 'Se modifico correctamente: '.$resultado);

  }else{

    EnviarAlerta('error', 'No se pudieron modificar: '.$resultado);

  }
}

//Funcion Cambiar fecha partido
function CambiarFechaPartido () {
  $ptid = $_POST['ptid'];
  $fecha = $_POST['fecha'];

  if($fecha == NULL){
    $fecha = '0000-00-00';
  }

  $campeonato = new Campeonato();

  $resultado = $campeonato->EditarPartido($ptid, 0, 0, 0, 0, $fecha, NULL, 0);

  if($resultado){

    EnviarAlerta('success', 'Se modifico correctamente: '.$resultado);

  }else{

    EnviarAlerta('error', 'No se pudieron modificar: '.$resultado);

  }
}

//Funcion Cambiar hora partido
function CambiarHoraPartido () {
  $ptid = $_POST['ptid'];
  $hora = $_POST['hora'];

  $campeonato = new Campeonato();

  $resultado = $campeonato->EditarPartido($ptid, 0, 0, 0, 0, NULL, $hora, 0);

  if($resultado){

    EnviarAlerta('success', 'Se modifico correctamente');

  }else{

    EnviarAlerta('error', 'No se pudieron modificar');

  }
}

//Funcion Cambiar cancha partido
function CambiarCanchaPartido () {
  $ptid = $_POST['ptid'];
  $cancha = $_POST['cancha'];

  $campeonato = new Campeonato();

  $resultado = $campeonato->EditarPartido($ptid, 0, 0, 0, 0, NULL, NULL, $cancha);

  if($resultado){

    EnviarAlerta('success', 'Se modifico correctamente');

  }else{

    EnviarAlerta('error', 'No se pudieron modificar');

  }
}

//Funcion Listar Campeonatos
function ListarCampeonatos () {
  $campeonatos = Campeonato::ListarCampeonatos();

  if(is_array($campeonatos) || is_object($campeonatos)){
    foreach($campeonatos as $i => $campeonato){
      $categoria = Categoria::ObtenerPorCid($campeonato['categoria']);
      $campeonatos[$i]['cid'] = $campeonato['categoria'];
      $campeonatos[$i]['categoria'] = $categoria->GetNombre();
    }
  }

  echo json_encode($campeonatos);

}

//Funcion Eliminar Campeonato
function eliminar ($cmid) {
  $campeonato = new Campeonato ($cmid);

  $resultado = $campeonato->eliminar();

  //EnviarAlerta('success', 'Se elimino correctamente');

  if($resultado == 1){

    EnviarAlerta('success', 'Se elimino correctamente');

  }else{

    EnviarAlerta('error', 'No se pudo eliminar: '.$resultado);

  }
}

//Funcion obtener planilla de campo del partido
function ObtenerPlanilladeCampo () {

  $cmid = $_POST['cmid'];
  $ptid = $_POST['ptid'];

  $campeonato = new Campeonato ($cmid);

  $campeonato->ObtenerPlanilladeCampo ($ptid);
}

//Funcion obtener planilla de campo del partido
function ObtenerPlanillasdeCampo ($dato) {

  $fecha = 0;
  $zona = -1;
  $instancia = 0;

  $cmid = $_POST['cmid'];
  if(!empty($_POST['fecha']))
  $fecha = $_POST['fecha'];
  if(!empty($_POST['zona']))
  $zona = $_POST['zona'];
  if(!empty($_POST['instancia']))
  $instancia = $_POST['instancia'];

  $campeonato = new Campeonato ($cmid);

  $campeonato->ObtenerPlanillasdeCampo ($fecha, $zona, $instancia);
}

//Funcion Consulta Partido
function ConsultaPartido ($dato) {
  $partido = new Partido($dato);

  $campeonato = new Campeonato($partido->GetCmid());
  $categoria = Categoria::ObtenerPorCid($campeonato->GetCategoria());
  $equipo1 = Equipo::ObtenerPorId($partido->GetEquipo1());
  $equipo2 = Equipo::ObtenerPorId($partido->GetEquipo2());

  $golesEquipo1 = $partido->ListarGoles(0, $dato, 0, $partido->GetEquipo1());
  if(is_array($golesEquipo1)){
    foreach($golesEquipo1 as $goles){
      $totalGolesEquipo1 += $goles['cantidad'];
    }
  }else{
    $totalGolesEquipo1 = 0;
  }
  //$totalGolesEquipo1 = count($golesEquipo1);

  $golesEquipo2 = $partido->ListarGoles(0, $dato, 0, $partido->GetEquipo2());
  if(is_array($golesEquipo2)){
    foreach($golesEquipo2 as $goles){
      $totalGolesEquipo2 += $goles['cantidad'];
    }
  }else{
    $totalGolesEquipo2 = 0;
  }
  //$totalGolesEquipo2 = count($golesEquipo2);

  $consulta = array("ptid" => $partido->GetPtid(),
  "fPartido" => $partido->GetfPartido(),
  "fecha" => $partido->GetFecha(),
  "instancia" => $partido->GetInstancia(),
  "campeonato" => array("cmid" => $campeonato->GetCmid(),
  "nombre" => $campeonato->GetNombre(),
  "categoria" => array("cid" => $categoria->GetCid(),
  "nombre" => $categoria->GetNombre())),
  "equipo1" => array("eid" => $equipo1->GetId(),
  "nombre" => $equipo1->GetNombre(),
  "goles" => $totalGolesEquipo1,
  "tarjetas" => array("amarillas" => array("total" => 0),
  "rojas" => array("total" => 0))),
  "equipo2" => array("eid" => $equipo2->GetId(),
  "nombre" => $equipo2->GetNombre(),
  "goles" => $totalGolesEquipo2,
  "tarjetas" => array("amarillas" => array("total" => 0),
  "rojas" => array("total" => 0))));

  echo json_encode($consulta);
}

//Funcion Suspender Partido
function SuspenderPartido () {
  $ptid = $_POST['ptid'];
  $suspendido = $_POST['suspendido'];
  $comentario = $_POST['comentario'];

  $partido = new Partido($ptid);

  $resultado = $partido->SuspenderPartido($suspendido, $comentario);

  if($resultado == 1){

    EnviarAlerta('success', 'Se suspendio el partido correctamente');

  }else{

    EnviarAlerta('error', 'No se pudo suspender el partido: '.$resultado);

  }
}

//Funcion Listar Jugadores Partido
function ListarJugadores ($dato) {

  $eid = $_POST['eid'];
  $ptid = $_POST['ptid'];

  $objJugador = new Jugador();
  $objTarjeta = new Tarjeta();
  $objPartido = new Partido($ptid);

  //$jugadores = $objJugador->ListarJugadoresHistorial(0, $eid);
  $jugadores = Jugador::listarJugadoresHistorial($eid, $objPartido->GetfPartido());

  //echo $jugadores;

  $resultado = [];

  if(is_array($jugadores) || is_object($jugadores)){
    foreach($jugadores as $i => $jugador){
     // if($jugador['activo'] == Socio::ESTADO_ACTIVO){
        $golesJugador = $objPartido->ListarGoles(0, $ptid, $jugador['jid'], $eid);
        if(is_array($golesJugador)){
          $totalGoles = $golesJugador[0]['cantidad'];
        }else{
          $totalGoles = 0;
        }
        $objJugador = new Jugador($jugador['jid']);        
        $tarjetasRojas = $objJugador->ListarTarjetasRojas(0, $objPartido->GetCmid());
        $tarjetasAmarillas = $objJugador->ListarTarjetasAmarillas(0, $objPartido->GetCmid());
        $tarjetasAmarillasPartido = $objJugador->ListarTarjetasAmarillas($ptid);
        //echo $tarjetasAmarillasPartido;
        $tarjetasRojasPartido = $objJugador->ListarTarjetasRojas($ptid);
        $jugadores[$i]['goles'] = $golesJugador;
        $jugadores[$i]['goles']['total'] = $totalGoles;
        $jugadores[$i]['tarjetas']['amarillas'] = $tarjetasAmarillasPartido;
        $jugadores[$i]['tarjetas']['rojas'] = $tarjetasRojasPartido;
        $jugadores[$i]['tarjetas']['amarillas']['totalpartido'] = count($tarjetasAmarillasPartido);
        $jugadores[$i]['tarjetas']['rojas']['totalpartido'] = count($tarjetasRojasPartido);
        $jugadores[$i]['tarjetas']['amarillas']['total'] = count($tarjetasAmarillas);
        $jugadores[$i]['tarjetas']['rojas']['total'] = count($tarjetasRojas);

        /******************************************** SUSPENSIONES COMISION ****************************************************/
        $suspensionObj = new Suspension(0, Database::TABLA_SUSPENSIONES_JUGADOR, Database::TABLA_SUSPENSIONES_JUGADOR_CUMPLIDAS, 'jid');
        //$suspensionesTribunal = $suspensionObj->ListarSuspensiones($jugador['jid'], 0, $objPartido->GetCmid(), NULL, -1, -1, NULL);
        $suspensionesTribunal = $suspensionObj->ListarSuspensiones($jugador['jid'], 0, 0, NULL, -1, -1, NULL);
        $suspensionesComision = $suspensionObj->ListarSuspensiones($jugador['jid'], 0, 0, NULL, -1, 0, NULL);

        if(is_array($suspensionesComision)){
          foreach($suspensionesComision as $s => $suspension){
            if($suspension['fecha'] == 0){
              //jugadores[$i]['fechacumplida'] = 0;
              $datetime1 = new DateTime(date('y-m-j'));
              $datetime2 = new DateTime($suspensionesComision[$s]['fVencimiento']);
              $interval = $datetime1->diff($datetime2);
              $dias = $interval->format('%R%a');
              $suspensionesComision[$s]['dias'] = intval($dias);
              if((FechaJuliana($suspensionesComision[$s]['fVencimiento']) - FechaJuliana($objPartido->GetfPartido())) < 0){
                unset($suspensionesComision[$s]);
              }else{
                if($dias <= 0 && !($suspensionesComision[$s]['fVencimiento'] == '0000-00-00' || empty($suspensionesComision[$s]['fVencimiento']))){
                  $suspensionesComision[$s]['cumplida'] = 1;
                  //unset($suspensionesComision[$s]);
                }else if($suspensionesComision[$s]['fVencimiento'] == '0000-00-00'){
                  $suspensionesComision[$s]['cumplida'] = 0;
                }else if(empty($suspensionesComision[$s]['fVencimiento'])){
                  $suspensionesComision[$s]['cumplida'] = 0;
                }else{
                  $suspensionesComision[$s]['cumplida'] = 0;
                }
              }
            }
          }
        }

        /******************************************** SUSPENSIONES TRIBUNAL ****************************************************/
        if(is_array($suspensionesTribunal)){
          foreach($suspensionesTribunal as $s => $suspension){
            $suspensionObj->SetSPID($suspension['spid']);
            $cumplidas = $suspensionObj->ListarFechasCumplidas($objPartido->GetFecha());
            $suspensionesTribunal [$s]['cumplidas'] = $cumplidas;
            $suspensionesTribunal [$s]['cumplidas']['total'] = count($cumplidas);
            //$jugadores[$i]['fechacumplida'] = 0;
            if(is_array($cumplidas)){
              foreach($cumplidas as $cumplida){
                $difFechas = (FechaJuliana($cumplida['fEmision']) - FechaJuliana($objPartido->GetfPartido()));
                $jugadores[$i]['dias'] = $difFechas;
                if ($cumplida['fecha'] == 0) {
                  if ($cumplida['spid'] == $suspension['spid'] && $cumplida['instancia'] == $objPartido->GetInstancia()) {
                    $jugadores[$i]['fechacumplida'] = 1;
                  }
                } else {
                  if($cumplida['spid'] == $suspension['spid'] && $cumplida['fecha'] == $objPartido->GetFecha() && $difFechas > 0 && $difFechas < 8){
                    $jugadores[$i]['fechacumplida'] = 1;
                  }
                }
              }
            }
            if($suspensionesTribunal [$s]['cumplidas']['total'] >= $suspensionesTribunal [$s]['fechas'] && $suspensionesTribunal [$s]['estado'] == Suspension::ESTADO_EFECTIVA){
              $suspensionesTribunal [$s]['cumplida'] = 1;
              //unset($suspensionesTribunal[$s]);
            }else{
              $suspensionesTribunal [$s]['cumplida'] = 0;
            }
            if((FechaJuliana($objPartido->GetfPartido()) - FechaJuliana($suspensionesTribunal[$s]['fEmision'])) <= 0){
              unset($suspensionesTribunal[$s]);
            }
            if((FechaJuliana($objPartido->GetfPartido()) - FechaJuliana($suspensionesTribunal[$s]['fEmision'])) > 0 && $suspensionesTribunal[$s]['cumplida'] && !$jugadores[$i]['fechacumplida']){
              unset($suspensionesTribunal[$s]);
            }
          }
        }

        if(is_array($suspensionesTribunal) && is_array($suspensionesComision)){
          $jugadores[$i]['suspensiones'] = array_merge(array_values($suspensionesTribunal), array_values($suspensionesComision));
        }else if(is_array($suspensionesTribunal) && !is_array($suspensionesComision)){
          $jugadores[$i]['suspensiones'] = array_values($suspensionesTribunal);
        }else if(!is_array($suspensionesTribunal) && is_array($suspensionesComision)){
          $jugadores[$i]['suspensiones'] = array_values($suspensionesComision);
        }/*else{
          $jugadores[$i]['suspensiones'][0]['cumplida'] = 1;
        }*/

        $jugadores[$i]['totalsuspensiones'] = count($jugadores[$i]['suspensiones']);
        $resultado[] = $jugadores[$i];
      }
   // }
  }

  echo json_encode($resultado);
}

//Funcion eliminar gol
function EliminarGol ($dato) {
  $partido = new Partido();

  $resultado = $partido->EliminarGol($dato);

  if($resultado == 1){

    EnviarAlerta('success', 'Se elimino correctamente');

  }else{

    EnviarAlerta('error', 'No se pudo eliminar: '.$resultado);

  }
}

//Funcion Insertar Gol
function InsertarGol ($dato) {

  $jid = $_POST['jid'];
  $eid = $_POST['eid'];
  $ptid = $_POST['ptid'];
  $cantidad = $_POST['cantidad'];

  $partido = new Partido($ptid);

  $resultado = $partido->InsertarGol($jid, $eid, $cantidad);

  if($resultado == 1){

    EnviarAlerta('success', 'Se agrego correctamente');

  }else{

    EnviarAlerta('error', 'No se pudo agregar: '.$resultado);

  }
}

//Funcion Insertar Tarjeta
function InsertarTarjeta ($dato) {
  $tipo = $_POST['tipo'];
  $jid = $_POST['jid'];
  $ptid = $_POST['ptid'];
  $comentario = $_POST['comentario'];
  $fecha = date('Y-n-j');

  $tarjeta = new Tarjeta(0, $jid, $ptid, $tipo, $comentario, $fecha);

  $resultado = $tarjeta->registro();

  if($resultado == 1){

    EnviarAlerta('success', 'Se agrego correctamente');

  }else{

    EnviarAlerta('error', 'No se pudo agregar: '.$resultado);

  }
}

//Funcion Eliminar Tarjeta
function EliminarTarjeta ($dato) {
  $tarjeta = new Tarjeta($dato);

  $resultado = $tarjeta->eliminar();

  if($resultado == 1){

    EnviarAlerta('success', 'Se elimino correctamente');

  }else{

    EnviarAlerta('error', 'No se pudo eliminar: '.$resultado);

  }
}

//Funcion consulta posicion Categorias
function ConsultaPosicionesCategorias ($dato) {

  $cmidPost = 0;

  if(!empty($_POST['cmid'])){
    $cmidPost = $_POST['cmid'];
  }

  $ListaCategorias = Categoria::ListarCategorias(NULL, $dato);

  $timeNow = date('H:i:s');

  if(is_array($ListaCategorias)){

    foreach($ListaCategorias as $c => $categoria){

      $ListaCampeonatos = Campeonato::ListarCampeonatos($cmidPost, 0, $categoria['cid']);

      if(is_array($ListaCampeonatos)){
        //foreach($ListaCampeonatos as $cmp => $campeonato){}
        //$campeonato = new Campeonato($campeonato['cmid']);
        $campeonato = new Campeonato($ListaCampeonatos[count($ListaCampeonatos)-1]['cmid']);
        //$equipos = Equipo::ListarEquipos(0, 0, NULL, $campeonato->GetCategoria());

        $partidos = $campeonato->ListarFechas();

        $equipos = array();

        if(is_array($partidos) || is_object($partidos))
        {
          foreach($partidos as $partido)
          {
            if(!in_array($partido['eid1'], $equipos)){
              $equipos[] = $partido['eid1'];
              //$obj = Equipo::ObtenerPorId($partido['eid1']);
              //  $equipos[count($equipos)-1] = array("eid" => $obj->getId(), "nombre" => $obj->getNombre(), "categoria" => $obj->getCategoria());
              //$lista = Equipo::ListarEquipos($partido['eid1']);
              //$equipos[count($equipos)-1] = $lista[0];
            }

            if(!in_array($partido['eid2'], $equipos)){
              $equipos[] = $partido['eid2'];
              //$obj = Equipo::ObtenerPorId($partido['eid2']);
              //$equipos[count($equipos)-1] = array("eid" => $obj->getId(), "nombre" => $obj->getNombre(), "categoria" => $obj->getCategoria());
              //$lista = Equipo::ListarEquipos($partido['eid2']);
              //$equipos[count($equipos)-1] = $lista[0];
            }

          }
        }

        //$equipos = Equipo::ListarEquipos(0, 0, NULL, $campeonato->GetCategoria());
        $objPartido = new Partido();

        $timeNow = date('H:i:s');

        $zonas = array();
        $instancias = array();

        if(is_array($equipos) || is_object($equipos)){
          foreach($equipos as $i => $equipo){
            $obj = Equipo::ObtenerPorId($equipo);
            $equipos[$i] = array("eid" => $obj->getId(), "nombre" => $obj->getNombre(), "categoria" => $obj->getCategoria());
            $equipo = $equipos[$i];

            //$goles = $objPartido->ListarGoles(0,  0, 0, $equipo['eid']);
            $partidos = $campeonato->ListarFechas(0, $equipo['eid']);
            if(is_array($partidos))
            $lastPartido = $partidos[0];
            else {
              $lastPartido['zona'] = 0;
            }
            $equipos[$i]['pj'] = 0;
            $equipos[$i]['pg'] = 0;
            $equipos[$i]['pe'] = 0;
            $equipos[$i]['pp'] = 0;
            $equipos[$i]['gf'] = 0;
            $equipos[$i]['gc'] = 0;
            $equipos[$i]['pts'] = 0;
            $equipos[$i]['estado'] = "";
            $equipos[$i]['ps'] = 0; //Partidos suspendidos
            $equipos[$i]['zona'] = $lastPartido['zona'];
            $zonas[] = $lastPartido['zona'];
            if(!empty($lastPartido['instancia'])) {
              $instancias[] = $lastPartido['instancia'];
            }
            if(is_array($partidos) || is_object($partidos)){
              foreach($partidos as $partido){

                $DiffTime = strtotime($partido['hPartido']) - strtotime($timeNow);
                $DiffDate = FechaJuliana(date($partido['fPartido'])) - FechaJuliana(date('Y-n-j'));

                //$equipos[$i]['pj'] .= $DiffDate." ";

                if(($DiffDate < 0 && $partido['fPartido'] != '0000-00-00' && $partido['fecha'] > 0 && empty($partido['instancia'])) || ($DiffDate == 0 && $DiffTime < 0 && $partido['fPartido'] != '0000-00-00' && $partido['fecha'] > 0 && empty($partido['instancia']))){
                  $equipos[$i]['pj']++;
                  $golesEquipo1 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid1']);
                  $golesEquipo2 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid2']);

                  $totalGolesEquipo1 = 0;
                  $totalGolesEquipo2 = 0;

                  if($partido['suspendido'] == -1){

                    $golesEquipo1 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid1']);

                    if(is_array($golesEquipo1) || is_object($golesEquipo1)){
                      foreach($golesEquipo1 as $goles){
                        $totalGolesEquipo1 += $goles['cantidad'];
                      }
                    }

                    $golesEquipo2 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid2']);

                    if(is_array($golesEquipo2) || is_object($golesEquipo2)){
                      foreach($golesEquipo2 as $goles){
                        $totalGolesEquipo2 += $goles['cantidad'];
                      }
                    }

                    if($partido['eid1'] == $equipo['eid']){
                      $equipos[$i]['gf'] += $totalGolesEquipo1;
                      $equipos[$i]['gc'] += $totalGolesEquipo2;
                      if($totalGolesEquipo1 > $totalGolesEquipo2){
                        $equipos[$i]['pg'] += 1;
                        $equipos[$i]['pts'] += 3;
                      }else if($totalGolesEquipo1 < $totalGolesEquipo2){
                        $equipos[$i]['pp'] += 1;
                      }
                    }else if($partido['eid2'] == $equipo['eid']){
                      $equipos[$i]['gc'] += $totalGolesEquipo1;
                      $equipos[$i]['gf'] += $totalGolesEquipo2;
                      if($totalGolesEquipo2 > $totalGolesEquipo1){
                        $equipos[$i]['pg'] += 1;
                        $equipos[$i]['pts'] += 3;
                      }else if($totalGolesEquipo2 < $totalGolesEquipo1){
                        $equipos[$i]['pp'] += 1;
                      }
                    }

                    if($totalGolesEquipo2 == $totalGolesEquipo1){
                      $equipos[$i]['pe'] += 1;
                      $equipos[$i]['pts'] += 1;
                    }
                  }else{
                    if($partido['suspendido'] == $equipos[$i]['eid']){
                      $equipos[$i]['pg'] += 1;
                      $equipos[$i]['pts'] += 3;
                    }else if($partido['suspendido'] != $equipos[$i]['eid']){
                      $equipos[$i]['pp'] += 1;
                      $equipos[$i]['ps'] += 1;
                    }
                  }
                }
              }
              $descuento = $campeonato->VerPuntosDescontados($equipos[$i]['eid']);
              $equipos[$i]['pts'] -= $descuento['total'];
            }else{
              $equipos[$i]['nombre'] = '';
              $equipos[$i]['pts'] = -9999;
              $equipos[$i]['gc'] = 9999;
              $equipos[$i]['ps'] = 9999;
            }
          }
        }

        if(is_array($equipos) || is_object($equipos)){
          $cantidadEquipos = count($equipos);
          for($i = 0; $i < $cantidadEquipos; $i++){
            for($j = $i; $j < $cantidadEquipos; $j++){
              // Ordenamos equipos por puntos Equipo i < Equipo j
              if($equipos[$i]['pts'] < $equipos[$j]['pts']){
                $temp = $equipos[$i];
                $equipos[$i] = $equipos[$j];
                $equipos[$j] = $temp;
                // Ordenamos equipos si tienen los mismos puntos
              }else if($equipos[$i]['pts'] == $equipos[$j]['pts']){
                // Ordenamos equipos por partidos suspendidos Equipo i > Equipo j
                if($equipos[$i]['ps'] > $equipos[$j]['ps']){
                  $temp = $equipos[$i];
                  $equipos[$i] = $equipos[$j];
                  $equipos[$j] = $temp;
                  // Ordenamos si tienen la misma cantidad de partidos suspendidos
                }else if($equipos[$i]['ps'] == $equipos[$j]['ps']){
                  $comparacion = CompararPartidos($dato, $equipos[$i]['eid'], $equipos[$j]['eid']);
                  if($comparacion == 2){
                    $temp = $equipos[$i];
                    $equipos[$i] = $equipos[$j];
                    $equipos[$j] = $temp;
                  }
                  // Ordenamos por diferencia de goles a favor menos goles en contra
                  if(($equipos[$i]['gf']-$equipos[$i]['gc']) < ($equipos[$j]['gf']-$equipos[$j]['gc'])){
                    $temp = $equipos[$i];
                    $equipos[$i] = $equipos[$j];
                    $equipos[$j] = $temp;
                  }
                  
                }
              }
            }
          }
        }
        $zonas = array_unique($zonas);

        $instancias = array_unique($instancias);

        $zonas = array_diff($zonas, [0]);

        sort($zonas);
        sort($instancias);
        $ListaCategorias[$c]['tipo'] = $campeonato->GetTipo();
        $ListaCategorias[$c]['zonas'] = $zonas;
        $ListaCategorias[$c]['equipos'] = $equipos;//$equipos;
        $ListaCategorias[$c]['instancias'] = $instancias;
      }
    }
  }

  echo json_encode($ListaCategorias);
}

//Funcion Consulta categoria campeonato
function ConsultaCampeonatoCatergorias ($dato) {

  $cmidPost = 0;

  if(!empty($_POST['cmid'])){
    $cmidPost = $_POST['cmid'];
  }

  $ListaCategorias = Categoria::ListarCategorias(NULL, $dato);

  if(is_array($ListaCategorias)){

    foreach($ListaCategorias as $c => $categoria){

      $ListaCampeonatos = Campeonato::ListarCampeonatos($cmidPost, 0, $categoria['cid']);

      if(is_array($ListaCampeonatos)){
        //foreach($ListaCampeonatos as $campeonato){}
        $endCampeonato = end($ListaCampeonatos);
        $campeonato = new Campeonato($endCampeonato['cmid']);

        $golesJugadores = $campeonato->GolesPorJugador();

        if(is_array($golesJugadores)){
          foreach($golesJugadores as $ju => $gol){
            $jugador = new Jugador($gol['jid']);
            $equipo = Equipo::ObtenerPorJId($gol['jid']);
            $socio = new Socio($jugador->GetSid());
            $usuario = User::ObtenerPorId($socio->GetUid());
            $golesJugadores[$ju]['equipo'] = $equipo->GetNombre();
            $golesJugadores[$ju]['apellido'] = $usuario->GetApellido();
            $golesJugadores[$ju]['nombre'] = $usuario->GetNombre();
          }
        }

        $partidos = $campeonato->ListarFechas();
        $objPartido = new Partido();
        $partidosjson = array();
        $anteriorFecha = 0;
        $fechas = array();

        if(is_array($partidos) || is_object($partidos))
        {
          foreach($partidos as $partido)
          {
            //if(empty($partido['instancia'])){
            $equipo1 = Equipo::ObtenerPorId($partido['eid1']);
            $equipo2 = Equipo::ObtenerPorId($partido['eid2']);

            $totalGolesEquipo1 = 0;
            $totalGolesEquipo2 = 0;

            $golesEquipo1 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid1']);

            if(is_array($golesEquipo1) || is_object($golesEquipo1)){
              foreach($golesEquipo1 as $goles){
                $totalGolesEquipo1 += $goles['cantidad'];
              }
            }

            $golesEquipo2 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid2']);

            if(is_array($golesEquipo2) || is_object($golesEquipo2)){
              foreach($golesEquipo2 as $goles){
                $totalGolesEquipo2 += $goles['cantidad'];
              }
            }

            $partido['equipo1']['nombre'] = $equipo1->GetNombre();
            $partido['equipo2']['nombre'] = $equipo2->GetNombre();

            if($partido['eid1'] == $partido['suspendido']){
              $partido['equipo1']['goles'] = "GP";
              $partido['equipo2']['goles'] = "PP";
            }else if($partido['eid2'] == $partido['suspendido']){
              $partido['equipo2']['goles'] = "GP";
              $partido['equipo1']['goles'] = "PP";
            }else if($partido['suspendido'] == 0){
              $partido['equipo2']['goles'] = "PP";
              $partido['equipo1']['goles'] = "PP";
            }else{
              $partido['equipo1']['goles'] = $totalGolesEquipo1;
              $partido['equipo2']['goles'] = $totalGolesEquipo2;
            }

            $partido['jugado'] = (GetDif($partido['fPartido']) < 0) ? 1 : 0;

            $partidosjson[] = $partido;

            if($anteriorFecha != $partido['fecha']){
              $anteriorFecha = $partido['fecha'];
              //$fechas[] = array("fecha" => $partido['fecha']);
              array_push($fechas, $partido['fecha']);
            }
            // }
          }
        }

        $fechas = array_unique($fechas);

        sort($fechas);

        $ListaCategorias[$c]['fechas'] = $fechas;
        $ListaCategorias[$c]['partidos'] = $partidosjson;

        //    }
      }

    }
  }

  $resultado = array("partidos" => $ListaCategorias, "goles" => $golesJugadores);

  echo json_encode($resultado);
}

//Funcion consulta posicion equipo
function ConsultaPosicionesEquipo () {

  $eid = $_POST['eid'];

  $equipoObj = Equipo::ObtenerPorId($eid);

  $ListaCategorias = Categoria::ListarCategorias(NULL, $equipoObj->GetCategoria());

  $timeNow = date('H:i:s');

  if(is_array($ListaCategorias)){

    foreach($ListaCategorias as $c => $categoria){

      $ListaCampeonatos = Campeonato::ListarCampeonatos(0, 0, $categoria['cid']);

      if(is_array($ListaCampeonatos)){
        //foreach($ListaCampeonatos as $cmp => $campeonato){}
        //$campeonato = new Campeonato($campeonato['cmid']);
        $campeonato = new Campeonato($ListaCampeonatos[count($ListaCampeonatos)-1]['cmid']);
        //$equipos = Equipo::ListarEquipos(0, 0, NULL, $campeonato->GetCategoria());

        $partidos = $campeonato->ListarFechas();

        $equipos = array();

        if(is_array($partidos) || is_object($partidos))
        {
          foreach($partidos as $partido)
          {
            //if(empty($partido['instancia'])){
            if(!in_array($partido['eid1'], $equipos)){
              $equipos[] = $partido['eid1'];
              //$obj = Equipo::ObtenerPorId($partido['eid1']);
              //  $equipos[count($equipos)-1] = array("eid" => $obj->getId(), "nombre" => $obj->getNombre(), "categoria" => $obj->getCategoria());
              //$lista = Equipo::ListarEquipos($partido['eid1']);
              //$equipos[count($equipos)-1] = $lista[0];
            }

            if(!in_array($partido['eid2'], $equipos)){
              $equipos[] = $partido['eid2'];
              //$obj = Equipo::ObtenerPorId($partido['eid2']);
              //$equipos[count($equipos)-1] = array("eid" => $obj->getId(), "nombre" => $obj->getNombre(), "categoria" => $obj->getCategoria());
              //$lista = Equipo::ListarEquipos($partido['eid2']);
              //$equipos[count($equipos)-1] = $lista[0];
            }
          }
          //}
        }


        $zonas = array();

        $objPartido = new Partido();
        $ListaCategorias[$c]['totalequipos'] = count($equipos);
        $n = 0;
        if(is_array($equipos) || is_object($equipos)){
          foreach($equipos as $i => $equipo){
            $obj = Equipo::ObtenerPorId($equipo);
            $equipos[$i] = array("eid" => $obj->getId(), "nombre" => $obj->getNombre(), "categoria" => $obj->getCategoria());
            $equipo = $equipos[$i];
            //$goles = $objPartido->ListarGoles(0,  0, 0, $equipo['eid']);
            //$arquero = Jugador::ListarJugadores(0, $equipo['eid'], NULL, 0, Jugador::POSICION_ARQUERO);
            $partidos = $campeonato->ListarFechas(0, $equipo['eid']);
            if (is_array($partidos)) {
              $lastPartido = $partidos[0];              
              $arquero = Jugador::listarJugadoresHistorial ($equipo['eid'], $lastPartido['fPartido'], NULL, -1, Jugador::POSICION_ARQUERO);              
              $equipos[$i]['arquero'] = $arquero[0];
            } else {
              $lastPartido['zona'] = 0;
            }
            $equipos[$i]['pj'] = 0;
            $equipos[$i]['pg'] = 0;
            $equipos[$i]['pe'] = 0;
            $equipos[$i]['pp'] = 0;
            $equipos[$i]['gf'] = 0;
            $equipos[$i]['gc'] = 0;
            $equipos[$i]['pts'] = 0;
            $equipos[$i]['ps']= 0; //Partidos suspendidos
            $equipos[$i]['zona'] = $lastPartido['zona'];
            $zonas[] = $lastPartido['zona'];
            if(is_array($partidos) || is_object($partidos)){
              foreach($partidos as $p => $partido){
                // if(empty($partido['instancia'])){
                $DiffTime = strtotime($partido['hPartido']) - strtotime($timeNow);
                $DiffDate = FechaJuliana(date($partido['fPartido'])) - FechaJuliana(date('Y-n-j'));
                if(($DiffDate < 0 && $partido['fPartido'] != '0000-00-00' && $partido['fecha'] > 0 && empty($partido['instancia'])) || ($DiffDate == 0 && $DiffTime < 0 && $partido['fPartido'] != '0000-00-00' && $partido['fecha'] > 0 && empty($partido['instancia']))){
                  $equipos[$i]['pj'] += 1;
                  $golesEquipo1 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid1']);
                  $golesEquipo2 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid2']);
                  $equipos[$i]['zona'] = $partido['zona'];
                  $totalGolesEquipo1 = 0;
                  $totalGolesEquipo2 = 0;

                  if($partido['suspendido'] == -1){

                    $golesEquipo1 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid1']);

                    if(is_array($golesEquipo1) || is_object($golesEquipo1)){
                      foreach($golesEquipo1 as $goles){
                        $totalGolesEquipo1 += $goles['cantidad'];
                      }
                    }

                    $golesEquipo2 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid2']);

                    if(is_array($golesEquipo2) || is_object($golesEquipo2)){
                      foreach($golesEquipo2 as $goles){
                        $totalGolesEquipo2 += $goles['cantidad'];
                      }
                    }

                    if($partido['eid1'] == $equipo['eid']){
                      $equipos[$i]['gf'] += $totalGolesEquipo1;
                      $equipos[$i]['gc'] += $totalGolesEquipo2;
                      if($totalGolesEquipo1 > $totalGolesEquipo2){
                        $equipos[$i]['pg'] += 1;
                        $equipos[$i]['pts'] += 3;
                      }else if($totalGolesEquipo1 < $totalGolesEquipo2){
                        $equipos[$i]['pp'] += 1;
                      }
                    }else if($partido['eid2'] == $equipo['eid']){
                      $equipos[$i]['gc'] += $totalGolesEquipo1;
                      $equipos[$i]['gf'] += $totalGolesEquipo2;
                      if($totalGolesEquipo2 > $totalGolesEquipo1){
                        $equipos[$i]['pg'] += 1;
                        $equipos[$i]['pts'] += 3;
                      }else if($totalGolesEquipo2 < $totalGolesEquipo1){
                        $equipos[$i]['pp'] += 1;
                      }
                    }

                    if($totalGolesEquipo2 == $totalGolesEquipo1){
                      $equipos[$i]['pe'] += 1;
                      $equipos[$i]['pts'] += 1;
                    }
                  }else{
                    if($partido['suspendido'] == $equipos[$i]['eid']){
                      $equipos[$i]['pg'] += 1;
                      $equipos[$i]['pts'] += 3;
                    }else if($partido['suspendido'] != $equipos[$i]['eid']){
                      $equipos[$i]['pp'] += 1;
                      $equipos[$i]['ps'] += 1;
                    }
                  }
                }
                //}
              }
              $descuento = $campeonato->VerPuntosDescontados($equipos[$i]['eid']);
              $equipos[$i]['pts'] -= $descuento['total'];
            }else{
              $equipos[$i]['nombre'] = '';
              $equipos[$i]['pts'] = -9999;
              $equipos[$i]['gc'] = 9999;
              $equipos[$i]['ps'] = 9999;
            }
          }
        }

        if(is_array($equipos) || is_object($equipos)){
          $cantidadEquipos = count($equipos);
          for($i = 0; $i < $cantidadEquipos; $i++){
            for($j = $i; $j < $cantidadEquipos; $j++){
              // Ordenamos equipos por puntos Equipo i < Equipo j
              if($equipos[$i]['pts'] < $equipos[$j]['pts']){
                $temp = $equipos[$i];
                $equipos[$i] = $equipos[$j];
                $equipos[$j] = $temp;
                // Ordenamos equipos si tienen los mismos puntos
              }else if($equipos[$i]['pts'] == $equipos[$j]['pts']){
                // Ordenamos equipos por partidos suspendidos Equipo i > Equipo j
                if($equipos[$i]['ps'] > $equipos[$j]['ps']){
                  $temp = $equipos[$i];
                  $equipos[$i] = $equipos[$j];
                  $equipos[$j] = $temp;
                  // Ordenamos si tienen la misma cantidad de partidos suspendidos
                }else if($equipos[$i]['ps'] == $equipos[$j]['ps']){
                  $comparacion = CompararPartidos($dato, $equipos[$i]['eid'], $equipos[$j]['eid']);
                  if($comparacion == 2){
                    $temp = $equipos[$i];
                    $equipos[$i] = $equipos[$j];
                    $equipos[$j] = $temp;
                  }
                  // Ordenamos por diferencia de goles a favor menos goles en contra
                  if(($equipos[$i]['gf']-$equipos[$i]['gc']) < ($equipos[$j]['gf']-$equipos[$j]['gc'])){
                    $temp = $equipos[$i];
                    $equipos[$i] = $equipos[$j];
                    $equipos[$j] = $temp;
                  }
                  
                }
              }
            }
          }
        }

        if(is_array($equipos) || is_object($equipos)){
          $zona = 0;
          foreach($equipos as $equipo){
            if($equipo['eid'] == $eid){
              $zona = $equipo['zona'];
              break;
            }
          }
          $j = 0;
          foreach($equipos as $equipo){
            if($equipo['zona'] == $zona){
              $j++;
            }
            if($equipo['eid'] == $eid){
              echo $j;
              return 0;
            }
          }
        }
      }
    }
  }
}

// Funcion Estado Campeonato
function EstadoCampeonato ($campeonato) {

  $estado = 1 + ($campeonato['estado'] * -1);

  $cmp = new Campeonato($campeonato['cmid'], $campeonato['nombre'], $campeonato['fCreacion'], 0, $estado);
  $resultado = $cmp->modificar();

  //EnviarAlerta('success', 'Se modifico correctamente');

  if($resultado == 1){
    EnviarAlerta('success', 'Se modifico correctamente');
  }else{
    EnviarAlerta('success', 'Hubo un error: '.$resultado);
  }
}

// Funcion Lista instancias
function ListarInstancias () {

  $resultado = Campeonato::ListarInstancias();

  echo json_encode($resultado);

}

// Funcion Crear Partido Instancia
function CrearPartidoInstancia () {

  $cmid = $_POST['cmid'];
  $eid1 = $_POST['equipo1'];
  $eid2 = $_POST['equipo2'];
  $instancia = $_POST['instancia'];
  $estadistica = $_POST['estadistica'];

  $partido = new Partido();

  $resultado = $partido->InsertarPartido($cmid, $eid1, $eid2, 0, NULL, NULL, 0, 0, $instancia, $estadistica);

  if($resultado == 1){
    EnviarAlerta('success', 'Se creo correctamente');
  }else{
    EnviarAlerta('success', 'Hubo un error: '.$resultado);
  }
}
?>
