<?php
require("models/class.User.php");

if($_SESSION['api_id']['login']){
  $User = new User();
  $User->logout();
}
header("Location: /".$root."/login");
?>
