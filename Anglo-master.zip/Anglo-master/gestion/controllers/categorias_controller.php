<?php
session_start();
require("core/core.php");
require("config/sys.conf.php");
require("models/class.User.php");
require("models/class.Socio.php");
require("models/class.Deportivo.php");

define("TITLE", "Categorias");

//Llamada a la vista
if($_SESSION['api_id']['login'])
{

    $user = new User($_SESSION['api_id']['uid']);

    define("PRIVILEGIO", $temp);

    $accion = (!empty($_POST['funcion'])) ? $_POST['funcion'] : ((!empty($vista[1])) ? $vista[1] : 'index');
    $dato = (!empty($_POST['dato'])) ? $_POST['dato'] : ((!empty($vista[2])) ? $vista[2] : NULL);

    call_user_func($accion, $dato);

}else
{
    //Llamada a la vista
    header("location:login");
}

//Funcion muestra vista Indice
function index () {

    if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
        header("Location: /".$root."/logout");
    }else{
        $lista = Categoria::ListarCategorias();

        require_once("views/categorias.phtml");
    }

}

//Funcion muestra vista agregar
function agregar () {

    $funcion = 'insertar';

    $ListaCategorias = Categoria::ListarCategorias();

    require_once("views/categorias_agregar.phtml");

}

//Funcion Listar Categorias
function ListarCategorias ($dato) {

    if($dato > 0){

        $categoria = Categoria::ObtenerPorCid($dato);

        $resultado = array("cid" => $categoria->GetCid(), "nombre" => $categoria->GetNombre());

        echo json_encode($resultado);

    }else{

        $ListaCategorias = Categoria::ListarCategorias();

        echo json_encode($ListaCategorias);

    }

}

//Funcion Editar
function editar ($cid) {

    $funcion = 'actualizar';

    $categoria = Categoria::ObtenerPorCid($cid);

    $ListaCategorias = Categoria::ListarCategorias();

    $CID = $cid;
    $Nombre = $categoria->getNombre();

    require_once("views/categorias_agregar.phtml");

}

//Funcion Ver
function ver ($cid) {

    require_once("views/categorias_ver.phtml");

}

//Funcion Eliminar
function eliminar ($cid) {

    $categoria = new Categoria($cid);

    if($resultado = $categoria->eliminar()){

        EnviarAlerta('success', 'Se elimino correctamente la categoria');

    }else{

        EnviarAlerta('error', 'No se pudo eliminar la categoria');

    }

}

//Funcion Insertar
function insertar () {

    $Nombre = $_POST['nombre'];

    $categoria = new Categoria();

    if($CID = $categoria->registro($Nombre)){

        EnviarAlerta('success', 'Se creo la categoria correctamente');

    }else{

        EnviarAlerta('error', 'No se pudo crear la categoria.');

    }
}

//Funcion Actualizar
function actualizar () {

    $CID = $_POST['id'];
    $Nombre = $_POST['nombre'];

    $categoria = new Categoria($CID);

    if($CID = $categoria->modificar($Nombre)){

        EnviarAlerta('success', 'Se actualizo la categoria correctamente');

    }else{

        EnviarAlerta('error', 'No se pudo actualizar la categoria.');

    }
}

//Funcion Insertar categoria
function InsertarCategoria ($dato) {
    $nombre = $_POST['nombre'];

    $categoria = new Categoria();

    if($resultado = $categoria->registro($nombre)){

        EnviarAlerta('success', 'Se creo la categoria correctamente: '.$resultado);

    }else{

        EnviarAlerta('error', 'No se pudo crear la categoria: '.$resultado);

    }
}

?>
