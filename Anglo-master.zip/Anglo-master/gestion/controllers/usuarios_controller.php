<?php
session_start();
require("core/core.php");
require("config/sys.conf.php");
require("models/class.User.php");
require("models/class.Socio.php");
require("models/class.Facturacion.php");
require("models/class.Deportivo.php");

define("TITLE", "Usuarios");

//Llamada a la vista
if($_SESSION['api_id']['login'])
{

  $user = new User($_SESSION['api_id']['uid']);

  define("PRIVILEGIO", $temp);

  $accion = (!empty($_POST['funcion'])) ? $_POST['funcion'] : ((!empty($vista[1])) ? $vista[1] : 'index');
  $dato = (!empty($_POST['dato'])) ? $_POST['dato'] : ((!empty($vista[2])) ? $vista[2] : NULL);

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR || $_SESSION['api_id']['uPrivilegio'] == User::TIPO_COBRADOR || $_SESSION['api_id']['uPrivilegio'] == User::TIPO_ESTADISTA)
  {
    call_user_func($accion, $dato);
  }else if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
    header("Location: /".$root."/logout");
  }else{
    ErrorPrivilegio();
  }


}else
{
  //Llamada a la vista
  header("Location: /".$root."/login");
}

//Funcion muestra vista Indice
function index (){

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR)
  {
    $ListaAdministradores = User::ListarUsuarios(User::TIPO_ADMINISTRADOR);
    $ListaCobradores = User::ListarUsuarios(User::TIPO_COBRADOR);
    $ListaEstadistas = User::ListarUsuarios(User::TIPO_ESTADISTA);
	//var_dump($ListaEstadistas);
    
	if (empty($ListaEstadistas)) {
		$ListaEstadistas = array();
	}

	$lista = array_merge($ListaAdministradores, $ListaCobradores, $ListaEstadistas);

    require_once("views/usuarios.phtml");

  }else{
    ErrorPrivilegio();
  }

}

//Funcion Listar Usuarios
function RegexUsuarios () {
  $nombre = $_POST['nombre'];

  $usuarios = User::RegexUsuarios($nombre);

  echo json_encode($usuarios);
}

//Funcion Verificar Privilegio Admin
function esAdmin() {
  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR)
  {
    echo true;
  }else{
    echo false;
  }
}

//Funcion Verificar Privilegio Cobrador
function esCobrador () {
  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_COBRADOR){
    echo true;
  }else{
    echo false;
  }
}

//Funcion Verificar Privilegio Estadista
function esEstadista () {
  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ESTADISTA){
    echo true;
  }else{
    echo false;
  }
}


//Funcion muestra vista agregar
function agregar (){

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR){

    $funcion = 'insertar';

    $privilegios = User::ListarPrivilegios();

    require_once("views/usuarios_agregar.phtml");

  }else{
    ErrorPrivilegio();
  }

}

//Funcion Editar
function editar ($uid){

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR){
    $funcion = 'actualizar';

    $privilegios = User::ListarPrivilegios();

    $usuario = User::ObtenerPorId($uid);

    $Id = $usuario->getId();
    $Nombre = $usuario->getNombre();
    $Apellido = $usuario->GetApellido();
    $Dni = $usuario->GetDni();
    $Clave = $usuario->GetClave();
    $Pais = $usuario->GetPais();
    $Provincia = $usuario->GetProvincia();
    $Localidad = $usuario->GetLocalidad();
    $Direccion = $usuario->GetDireccion();
    $Telefono = $usuario->GetTelefono();
    $Sexo = $usuario->GetSexo();
    $fNacimiento = $usuario->GetfNacimiento();
    $Tipo = $usuario->GetTipo();
    $Email = $usuario->GetEmail();

    require_once("views/usuarios_agregar.phtml");
  }else{
    ErrorPrivilegio();
  }

}

//Funcion Eliminar
function eliminar ($uid){

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR){

    if($la = User::eliminar($uid)){

      EnviarAlerta('success', 'Se elimino correctamente el usuario');

    }else{

      EnviarAlerta('error', 'No se pudo eliminar el usuario');

    }

  }else{
    EnviarAlerta('error', 'No tiene permisos');
  }

}

//Funcion Insertar
function insertar (){

  $parametro = new User();

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR){
    $user = new User($_SESSION['api_id']['uid']);
    $socio = new Socio();
    $jugador = new Jugador();

    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $dni = $_POST['dni'];
    $clave = $_POST['clave'];
    $pais = $_POST['pais'];
    $provincia = $_POST['provincia'];
    $localidad = $_POST['localidad'];
    $direccion = $_POST['direccion'];
    $telefono = $_POST['telefono'];
    $sexo = $_POST['sexo'];
    $fNacimiento = $_POST['fNacimiento'];
    $tipo = $_POST['tipo'];
    $email = $_POST['email'];
    $cobro = $_POST['cobro'];

    if($uid = $user->registro($nombre, $apellido, $dni, $clave, $pais,
    $provincia, $localidad, $direccion, $telefono, $sexo, $fNacimiento, $tipo, $email)){

      if($tipo == Socio::TIPO_SOCIO){

        try {
          $sid = $socio->registro($uid);

          if($cobro){
            // Obtengo el parametro del valor de la inscripcion
            $InscripcionMonto = $parametro->GetParametro(103);
            $deuda = new Deuda(0, 'Inscripcion '.date('Y'), date('Y-n-j'), date('Y')."-".(date('n')+1)."-".date('j'), $InscripcionMonto['valor'], $sid);
            $resultado = $deuda->registroSocio();

            //EnviarAlerta('success', $resultado);
          }

          if($jid = $jugador->registro($sid)){
            EnviarAlerta('success', 'Se creo el usuario correctamente: '.$jid);
          }else{
            EnviarAlerta('error', 'No se pudo crear al jugador socio: '.$sid);
          }

        } catch (Exception $e) {
          EnviarAlerta('error', 'No se pudo crear el socio usuario: '.$e);
        }

      }else{
        EnviarAlerta('success', 'Se creo el usuario correctamente');
      }

    }else{

      EnviarAlerta('error', 'No se pudo crear el usuario correctamente: '.$uid);

    }
  }else{
    EnviarAlerta('error', 'No tiene permisos');
  }
}

//Funcion Actualizar
function actualizar (){
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);
  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR){

    $user = new User($_SESSION['api_id']['uid']);

    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $dni = $_POST['dni'];
    $clave = $_POST['clave'];
    $pais = $_POST['pais'];
    $provincia = $_POST['provincia'];
    $localidad = $_POST['localidad'];
    $direccion = $_POST['direccion'];
    $telefono = $_POST['telefono'];
    $sexo = $_POST['sexo'];
    $fNacimiento = $_POST['fNacimiento'];
    $tipo = $_POST['tipo'];
    $email = $_POST['email'];

    $nombreImagen = '';

    if(isset($_FILES['imagen'])){
      $path = $_FILES['imagen']['name'];
      $ext = pathinfo($path, PATHINFO_EXTENSION);
      $nombreImagen = date('Ynjgis') . '.' . $ext;
      $target_file = $_SERVER['DOCUMENT_ROOT'] . '/gestion/styles/images/socios/' . $nombreImagen;
      move_uploaded_file($_FILES['imagen']['tmp_name'], $target_file);
      $user->agregarImagen($id, $nombreImagen);
    }

    if($user->modificar($id, $nombre, $apellido, $dni, $clave, $pais,
    $provincia, $localidad, $direccion, $telefono, $sexo, $fNacimiento, $email, $tipo)){
      
      EnviarAlerta('success', 'Se modifico el usuario correctamente');

    }else{

      EnviarAlerta('error', 'No se pudo modificar el usuario correctamente');

    }

  }else{
    EnviarAlerta('error', 'No tiene permisos');
  }
}

?>
