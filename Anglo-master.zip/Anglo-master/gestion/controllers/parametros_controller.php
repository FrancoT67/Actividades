<?php
session_start();
require("core/core.php");
require("config/sys.conf.php");
require("models/class.User.php");
require("models/class.Socio.php");
require("models/class.Deportivo.php");

define("TITLE", 'Parametros');

//Llamada a la vista
if($_SESSION['api_id']['login'])
{

  $user = new User($_SESSION['api_id']['uid']);

  define("PRIVILEGIO", $temp);

  $accion = (!empty($_POST['funcion'])) ? $_POST['funcion'] : ((!empty($vista[1])) ? $vista[1] : 'index');
  $dato = (!empty($_POST['dato'])) ? $_POST['dato'] : ((!empty($vista[2])) ? $vista[2] : NULL);

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR)
  {
      call_user_func($accion, $dato);
  }else if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
      header("Location: /".$root."/logout");
  }else{
      ErrorPrivilegio();
  }

}else
{
  //Llamada a la vista
  header("Location: /".$root."/login");
}

//Funcion muestra vista Indice
function index () {

    require_once("views/parametros.phtml");

}

//Funcion Listar Parametros
function ListarParametros ($dato) {
    global $user;

    echo json_encode($user->GetParametros());
}

//Funcion Editar Parametro
function EditarParametro () {

    global $user;

    $pid = $_POST['pid'];
    $comentario = $_POST['comentario'];
    $valor = $_POST['valor'];

    $resultado = $user->EditarParametro($pid, $comentario, $valor);

    if($resultado){

        EnviarAlerta('success', 'Se modifico correctamente: '.$resultado);

    }else{

        EnviarAlerta('error', 'No se pudo modificar: '.$resultado);

    }

}

?>
