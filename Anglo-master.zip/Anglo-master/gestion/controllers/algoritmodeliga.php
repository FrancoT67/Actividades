<?php

$equipos = array(1,2,3,4,5,6,7,8,9,10);

//Separo los dos primeros equipos
$primerosequipos = array_slice($equipos, 0, 2); // 1, 2
//Obtengo el resto de los equipos
$restoequipos = array_slice($equipos, 2); // 3,4,5...
//Invierto el orden del resto de los equipos
$reversa = array_reverse($restoequipos);

//Uno los dos array
$completo = array_merge($primerosequipos, $reversa);

//Calculo el total de eequipos
$countequipos = count($equipos);
//Calculo el total de fechas
$countfechas = $countequipos -1;

// Primera fecha

$array2[0] = $completo[1];

for($i = 0; $i < ($countequipos - 2)/2; $i++){
	$array2[$i+1] = $completo[$i + 2];
	$array3[$i] = $completo[$countequipos-$i-1];
}

$array3 = array_reverse($array3);
$array2 = array_merge($array2, $array3);

$fecha[0] = $array2;

// Resto de las fechas

for($f = 0; $f < $countfechas - 1; $f++){
	$ultimo = $array2[count($array2) - 1];
	for($i = count($array2) - 1; $i > 0; $i--){
		$array2[$i] = $array2[$i-1];
	}
	$array2[0] = $ultimo;
	$fecha[$f+1] = $array2;
}

for($f = 0; $f < $countfechas; $f++){
	echo "fecha".($f+1).": ";
	echo $equipos[0]." vs ".$fecha[$f][0]."<br>";
	for($i = 0; $i < (count($fecha[$f]) - 2)/2; $i++){
		echo $fecha[$f][count($fecha[$f])-$i-1]." vs ".$fecha[$f][$i + 1]."<br>";
	}
}
?>
