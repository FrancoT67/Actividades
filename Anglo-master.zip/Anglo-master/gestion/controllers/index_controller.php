<?php
session_start();
require("core/core.php");
require("config/sys.conf.php");
require("models/class.User.php");
require("models/class.Socio.php");
require("models/class.Deportivo.php");

define("TITLE", 'Inicio');

//Llamada a la vista
if($_SESSION['api_id']['login'])
{

  $user = new User($_SESSION['api_id']['uid']);

  define("PRIVILEGIO", $temp);

  $accion = (!empty($_POST['funcion'])) ? $_POST['funcion'] : ((!empty($vista[1])) ? $vista[1] : 'index');
  $dato = (!empty($_POST['dato'])) ? $_POST['dato'] : ((!empty($vista[2])) ? $vista[2] : NULL);

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR || $_SESSION['api_id']['uPrivilegio'] == User::TIPO_COBRADOR)
  {
      call_user_func($accion, $dato);
  }else if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ESTADISTA){
      header("Location: /".$root."/campeonatos");
  }else if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
      header("Location: /".$root."/logout");
  }else{
      header("Location: /".$root."/logout");
  }

}else
{
  header("Location: /".$root."/logout");
}

//Funcion muestra vista Indice
function index () {

    require_once("views/index.phtml");

}

//Funcion Consulta estado del sistema
function ConsultaEstadoSistema ($dato) {

    // Obtengo lista de socios activos
    $socios = Socio::ListarSocios(Socio::ESTADO_ACTIVO);

    // Contador de socios sin cuotas emitidas
    $sociosSinCuotas = 0;

    // Verifico si tengo una lista
    // y reccorro la misma para ver
    // si tienen emitida la cuota del mes actual
    if(is_array($socios) || is_object($socios)) {
        foreach($socios as $socio) {

            // Genero objeto Socio
            $socioTemp = new Socio($socio['sid']);

            $month = date('m');
            $year = date('Y');

            // Obtengo lista de cuotas pagadas de este mes
            $cuotasPagadas = $socioTemp->ListarCuotasPagadas($month, $year);

            // Obtengo lista de cuotas impagas de este mes
            $cuotasImpagas = $socioTemp->ListarCuotasImpagas($month, $year);

            if(count($cuotasPagadas) == 0 && count($cuotasImpagas) == 0) {
                $sociosSinCuotas++;
            }
        }
    }

    // Obtengo lista de equipos activos
    $equipos = Equipo::ListarEquipos(0, 0, NULL, NULL, NULL, 1, 1);

    // Contador de socios sin contribuciones emitidas
    $equiposSinContribuciones = 0;

    // Array de cuotas unicas
    $cuotasUnicas = array();

    // Verifico si tengo una lista
    // y reccorro la misma para ver
    // si tienen emitida la contribucion del mes actual
    if(is_array($equipos) || is_object($equipos)) {
        foreach($equipos as $equipo) {

            // Genero objeto Socio
            $equipoTemp = new Equipo($equipo['eid']);

            $month = date('m');
            $year = date('Y');

            // Obtengo lista de contribuciones pagadas de este mes
            $contribucionesPagadas = $equipoTemp->ListarContribucionDeportiva($month, $year, Equipo::CONTRIBUCION_ESTADO_PAGADA);

            // Obtengo lista de contribuciones impagas de este mes
            $contribucionesImpagas = $equipoTemp->ListarContribucionDeportiva($month, $year, Equipo::CONTRIBUCION_ESTADO_IMPAGA);

            // Obtengo lista de contribuciones sin factura de este mes
            $contribucionesSinFactura = $equipoTemp->ListarContribucionDeportiva($month, $year, NULL, -1);

            if(is_array($contribucionesSinFactura)){
                $cuotasUnicas = array_merge($cuotasUnicas, $contribucionesSinFactura);
            }

            if(count($contribucionesPagadas) == 0 && count($contribucionesImpagas) == 0) {
                $equiposSinContribuciones++;
            }
        }
    }

    $consulta = array("sociosSinCuota" => $sociosSinCuotas,
    "equiposSinContribuciones" => $equiposSinContribuciones, "cuotasUnicas" => $cuotasUnicas);

    echo json_encode($consulta);

}

?>
