<?php
ob_end_clean();
header ('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header ('Content-Disposition: attachment;filename="' . $_POST['filename'] . date('j-n-Y') . '.xlsx"');
header ('Cache-Control: max-age=0');

session_start();
require("core/core.php");
require("config/sys.conf.php");
require("models/class.User.php");
require("models/class.Socio.php");
require("models/class.Facturacion.php");
require("models/class.Deportivo.php");
require("core/PHPExcel/PHPExcel/IOFactory.php");
require("core/PHPExcel/PHPExcel.php");

define("TITLE", 'Excel');

//Llamada a la vista
if($_SESSION['api_id']['login'])
{

    $user = new User($_SESSION['api_id']['uid']);

    define("PRIVILEGIO", $temp);

    $accion = (!empty($_POST['funcion'])) ? $_POST['funcion'] : ((!empty($vista[1])) ? $vista[1] : 'index');
    $dato = (!empty($_POST['dato'])) ? $_POST['dato'] : ((!empty($vista[2])) ? $vista[2] : NULL);

    if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR || $_SESSION['api_id']['uPrivilegio'] == User::TIPO_COBRADOR)
    {
        call_user_func($accion, $dato);
    }else if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ESTADISTA){
        header("Location: /".$root."/campeonatos");
    }else if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
        header("Location: /".$root."/logout");
    }else{
        header("Location: /".$root."/logout");
    }

}else
{
    header("Location: /".$root."/logout");
}

//Funcion Genera Excel deudas socios
function ConsultaDeudasSocios () {

    global $user;

    $filename = "Deudas socios";

    PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);

    $objPHPExcel = new PHPExcel();
    $objPHPExcel->getProperties()->setCreator("Treemind")
    ->setLastModifiedBy("Treemind")
    ->setTitle($filename)
    ->setSubject($filename)
    ->setDescription($filename)
    ->setKeywords($filename)
    ->setCategory($filename);

    $objPHPExcel->setActiveSheetIndex(0)
    ->setCellValue('A1', "Socio Id")
    ->setCellValue('B1', "Apellido")
    ->setCellValue('C1', "Nombre")
    ->setCellValue('D1', "Monto")
    ->setCellValue('E1', "Descripcion")
    ->setCellValue('F1', "Fecha de Emision");

    $ArrayCell = array('C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U');

    $style = array(
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        )
    );

    $objPHPExcel->setActiveSheetIndex(0)->getDefaultStyle()->applyFromArray($style);

    $socios = Socio::ListarSocios();

    $count = 2;

    if(is_array($socios)){
        foreach($socios as $socio){
            $cuotas = Cuota::ListarCuotas(0, $socio['sid'], 0, 0, Cuota::ESTADO_IMPAGA);
            $jugador = Jugador::ObtenerPorSid($socio['sid']);
            // Obtengo el parametro del valor de la cuota social
            $CuotaMonto = $user->GetParametro(100);
            if($jugador->GetId() > 0){
                $multas = $jugador->ListarMultasImpagas();
            }

            $deudas = Deuda::ListarDeudasSocio($socio['sid'], 0, 0, Deuda::ESTADO_IMPAGA);

            if(is_array($cuotas)){
                foreach($cuotas as $cuota){
                    $objPHPExcel->setActiveSheetIndex(0)
                    ->setCellValue('A'.($count), $socio['sid'])
                    ->setCellValue('B'.($count), $socio['apellido'])
                    ->setCellValue('C'.($count), $socio['nombre'])
                    ->setCellValue('D'.($count), (($cuota['monto'] == 0) ? $CuotaMonto['valor'] : $cuota['monto']))
                    ->setCellValue('E'.($count), 'Cuota '.FormatDate($cuota['fEmision']))
                    ->setCellValue('F'.($count), FormatDate($cuota['fEmision']));
                    $count++;
                }
            }
                
            if(is_array($multas)){
                foreach($multas as $multa){
                    $tipoMulta = Multa::ListarTiposMultas($multa['tmid']);
                    $objPHPExcel->setActiveSheetIndex(0)
                    ->setCellValue('A'.($count), $socio['sid'])
                    ->setCellValue('B'.($count), $socio['apellido'])
                    ->setCellValue('C'.($count), $socio['nombre'])
                    ->setCellValue('D'.($count), (($multa['monto'] == 0) ? $tipoMulta[0]['precio'] : $multa['monto']))
                    ->setCellValue('E'.($count), 'Multa '.FormatDate($multa['fEmision']))
                    ->setCellValue('F'.($count), FormatDate($multa['fEmision']));
                    $count++;
                }
            }

            if(is_array($deudas)){
                foreach($deudas as $deuda){
                    $objPHPExcel->setActiveSheetIndex(0)
                    ->setCellValue('A'.($count), $socio['sid'])
                    ->setCellValue('B'.($count), $socio['apellido'])
                    ->setCellValue('C'.($count), $socio['nombre'])
                    ->setCellValue('D'.($count), $deuda['importe'])
                    ->setCellValue('E'.($count), $deuda['concepto'])
                    ->setCellValue('F'.($count), FormatDate($deuda['fEmision']));
                    $count++;
                }
            }
        }
    }

    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
    $objWriter->save('php://output');
}

//Funcion Genera Excel deudas equipos
function ConsultaDeudasEquipos () {

    global $user;

    $filename = "Deudas equipos";

    PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);

    $objPHPExcel = new PHPExcel();
    $objPHPExcel->getProperties()->setCreator("Treemind")
    ->setLastModifiedBy("Treemind")
    ->setTitle($filename)
    ->setSubject($filename)
    ->setDescription($filename)
    ->setKeywords($filename)
    ->setCategory($filename);

    $objPHPExcel->setActiveSheetIndex(0)
    ->setCellValue('A1', "Equipo Id")
    ->setCellValue('B1', "Nombre")
    ->setCellValue('C1', "Categoria")
    ->setCellValue('D1', "Monto")
    ->setCellValue('E1', "Descripcion")
    ->setCellValue('F1', "Fecha de Emision");

    $ArrayCell = array('C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U');

    $style = array(
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        )
    );

    $objPHPExcel->setActiveSheetIndex(0)->getDefaultStyle()->applyFromArray($style);

    $equipos = Equipo::ListarEquipos();

    $count = 2;

    if(is_array($equipos)){
        foreach($equipos as $equipo){
            $equipoObj = new Equipo($equipo['eid']);
            $categoria = Categoria::ObtenerPorCid($equipo['categoria']);
            $contribuciones = $equipoObj->ListarContribucionDeportiva(0, 0, Equipo::CONTRIBUCION_ESTADO_IMPAGA);
            // Obtengo el parametro del valor de la cuota unica
            $CuotaMonto = $user->GetParametro(101);
            if($equipoObj->GetId() > 0){
                $multas = $equipoObj->ListarMultasImpagas();
            }
            $deudas = Deuda::ListarDeudasEquipo($equipo['eid'], 0, 0, Deuda::ESTADO_IMPAGA);

            if(is_array($contribuciones)){
                foreach($contribuciones as $contribucione){
                    $objPHPExcel->setActiveSheetIndex(0)
                    ->setCellValue('A'.($count), $equipo['eid'])
                    ->setCellValue('B'.($count), $equipo['nombre'])
                    ->setCellValue('C'.($count), $categoria->GetNombre())
                    ->setCellValue('D'.($count), (($contribucione['monto'] == 0) ? $CuotaMonto['valor'] : $contribucione['monto']))
                    ->setCellValue('E'.($count), 'Cuota '.FormatDate($contribucione['fEmision']))
                    ->setCellValue('F'.($count), FormatDate($contribucione['fEmision']));
                    $count++;
                }
            }

            if(is_array($multas)){
                foreach($multas as $multa){
                    $tipoMulta = Multa::ListarTiposMultas($multa['tmid']);
                    $objPHPExcel->setActiveSheetIndex(0)
                    ->setCellValue('A'.($count), $equipo['eid'])
                    ->setCellValue('B'.($count), $equipo['nombre'])
                    ->setCellValue('C'.($count), $categoria->GetNombre())
                    ->setCellValue('D'.($count), (($multa['monto'] == 0) ? $tipoMulta[0]['precio'] : $multa['monto']))
                    ->setCellValue('E'.($count), 'Multa '.FormatDate($multa['fEmision']))
                    ->setCellValue('F'.($count), FormatDate($multa['fEmision']));
                    $count++;
                }
            }

            if(is_array($deudas)){
                foreach($deudas as $deuda){
                    $objPHPExcel->setActiveSheetIndex(0)
                    ->setCellValue('A'.($count), $equipo['eid'])
                    ->setCellValue('B'.($count), $equipo['nombre'])
                    ->setCellValue('C'.($count), $categoria->GetNombre())
                    ->setCellValue('D'.($count), $deuda['importe'])
                    ->setCellValue('E'.($count), $deuda['concepto'])
                    ->setCellValue('F'.($count), FormatDate($deuda['fEmision']));
                    $count++;
                }
            }
        }
    }

    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
    $objWriter->save('php://output');
    
    //echo $deudas;
    //echo $multa;
    //echo $contribuciones;

}

//Funcion Genera Excel jugadores activos
function ConsultaJugadoresActivos () {
    $filename = "Jugador activos";

    PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);

    $objPHPExcel = new PHPExcel();
    $objPHPExcel->getProperties()->setCreator("Treemind")
    ->setLastModifiedBy("Treemind")
    ->setTitle($filename)
    ->setSubject($filename)
    ->setDescription($filename)
    ->setKeywords($filename)
    ->setCategory($filename);

    $objPHPExcel->setActiveSheetIndex(0)
    ->setCellValue('A1', "Socio Id")
    ->setCellValue('B1', "Apellido")
    ->setCellValue('C1', "Nombre")
    ->setCellValue('D1', "Equipo")
    ->setCellValue('E1', "Categoria")
    ->setCellValue('F1', "DNI")
    ->setCellValue('G1', "Fecha de Nacimiento");

    $ArrayCell = array('C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U');

    $style = array(
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        )
    );

    $objPHPExcel->setActiveSheetIndex(0)->getDefaultStyle()->applyFromArray($style);

    $jugadores = Jugador::ListarJugadores(0, 0, NULL, Socio::ESTADO_ACTIVO);

    if(is_array($jugadores)){
        foreach($jugadores as $j => $jugador){
            $categoria = Categoria::ObtenerPorCid($jugador['categoria']);

            $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.($j+2), $jugador['sid'])
            ->setCellValue('B'.($j+2), $jugador['apellido'])
            ->setCellValue('C'.($j+2), $jugador['nombre'])
            ->setCellValue('D'.($j+2), $jugador['equipo'])
            ->setCellValue('E'.($j+2), $categoria->GetNombre())
            ->setCellValue('F'.($j+2), $jugador['dni'])
            ->setCellValue('G'.($j+2), FormatDate($jugador['fNacimiento']));
        }
    }

    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
    $objWriter->save('php://output');
}

//Funcion Genera Excel cobros
function ConsultaCobros () {

    global $user;

    $fDesde = $_POST['fDesde'];
    $fHasta = $_POST['fHasta'];

    $filename = "cobros";//"Cobros ".FormatDate($fDesde)." - ".FormatDate($fHasta);

    PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);

    $objPHPExcel = new PHPExcel();
    $objPHPExcel->getProperties()->setCreator("Treemind")
    ->setLastModifiedBy("Treemind")
    ->setTitle($filename)
    ->setSubject($filename)
    ->setDescription($filename)
    ->setKeywords($filename)
    ->setCategory($filename);

    $objPHPExcel->setActiveSheetIndex(0)
    ->setCellValue('A1', "Id Cobro")
    ->setCellValue('B1', "Equipo")
    ->setCellValue('C1', "Categoria")
    ->setCellValue('D1', "Id Equipo")
    ->setCellValue('E1', "Socio")
    ->setCellValue('F1', "Id Socio")
    ->setCellValue('G1', "Concepto")
    ->setCellValue('H1', "Fecha de cobro")
    ->setCellValue('I1', "Monto")
    ->setCellValue('J1', "Forma")
    ->setCellValue('K1', "Comentario")
    ->setCellValue('L1', "Id Factura")
    ->setCellValue('M1', "Cobrador");

    $ArrayCell = array('C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U');

    $style = array(
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        )
    );

    $objPHPExcel->setActiveSheetIndex(0)->getDefaultStyle()->applyFromArray($style);

    $count = 2;

    //Contribuciones generales
    $equipoNull = new Equipo(0);
    $contribuciones = $equipoNull->ListarContribucionDeportiva();
    //Deudas equipos generales
    $deudasEquipos = Deuda::ListarDeudasEquipo();
    //Multas equipos
    $multasEquipoObj = new Multa(0, Database::TABLA_MULTAS_EQUIPO, 'equipo');
    $multasEquipos = $multasEquipoObj->ListarMultas();

    $listaFacturas = array();

    if(is_array($contribuciones)){
        foreach($contribuciones as $contribucion){
            if($contribucion['fid'] > 0){
                if($contribucion['eid'] > 0){
                    $equipo = Equipo::ObtenerPorId($contribucion['eid']);
                    $categoria = Categoria::ObtenerPorCid($equipo->GetCategoria());
                    $listaFacturas[] = $contribucion['fid'];
                }
                $cobros = Cobro::ListarCobros(0, $contribucion['fid'], 0.0, 0, 0, NULL, 0, $fDesde, $fHasta);
                if(is_array($cobros)){
                    foreach($cobros as $cobro){
                        $cobrador = User::ObtenerPorId($cobro['cobrador']);
                        $objPHPExcel->setActiveSheetIndex(0)
                        ->setCellValue('A'.($count), $cobro['cbid'])
                        ->setCellValue('B'.($count), $equipo->GetNombre())
                        ->setCellValue('C'.($count), $categoria->GetNombre())
                        ->setCellValue('D'.($count), $equipo->GetId())
                        ->setCellValue('G'.($count), 'Cuota unica '.FormatDate($contribucion['fEmision']))
                        ->setCellValue('H'.($count), FormatDate($cobro['fPago']))
                        ->setCellValue('I'.($count), $cobro['monto'])
                        ->setCellValue('J'.($count), $cobro['forma'])
                        ->setCellValue('K'.($count), $cobro['comentario'])
                        ->setCellValue('L'.($count), $cobro['fid'])
                        ->setCellValue('M'.($count), $cobro['cobrador']."-".$cobrador->GetApellido()." ".$cobrador->GetNombre());
                        $count++;
                    }
                }
            }
        }
    }

    if(is_array($deudasEquipos)){
        foreach($deudasEquipos as $deuda){
            if($deuda['fid'] > 0){
                if($deuda['eid'] > 0){
                    $equipo = Equipo::ObtenerPorId($deuda['eid']);
                    $categoria = Categoria::ObtenerPorCid($equipo->GetCategoria());
                    //$listaFacturas[] = $contribucion['fid'];
                }
                $cobros = Cobro::ListarCobros(0, $deuda['fid'], 0.0, 0, 0, NULL, 0, $fDesde, $fHasta);
                if(is_array($cobros)){
                    foreach($cobros as $cobro){
                        $cobrador = User::ObtenerPorId($cobro['cobrador']);
                        $objPHPExcel->setActiveSheetIndex(0)
                        ->setCellValue('A'.($count), $cobro['cbid'])
                        ->setCellValue('B'.($count), $equipo->GetNombre())
                        ->setCellValue('C'.($count), $categoria->GetNombre())
                        ->setCellValue('D'.($count), $equipo->GetId())
                        ->setCellValue('G'.($count), $deuda['concepto'])
                        ->setCellValue('H'.($count), FormatDate($cobro['fPago']))
                        ->setCellValue('I'.($count), $cobro['monto'])
                        ->setCellValue('J'.($count), $cobro['forma'])
                        ->setCellValue('K'.($count), $cobro['comentario'])
                        ->setCellValue('L'.($count), $cobro['fid'])
                        ->setCellValue('M'.($count), $cobro['cobrador']."-".$cobrador->GetApellido()." ".$cobrador->GetNombre());
                        $count++;
                    }
                }
            }
        }
    }

    if(is_array($multasEquipos)){
        foreach($multasEquipos as $multa){
            if($multa['fid'] > 0){
                $tipoMulta = Multa::ListarTiposMultas($multa['tmid']);
                if($multa['equipo'] > 0){
                    $equipo = Equipo::ObtenerPorId($multa['equipo']);
                    $categoria = Categoria::ObtenerPorCid($equipo->GetCategoria());
                    //$listaFacturas[] = $contribucion['fid'];
                }
                $cobros = Cobro::ListarCobros(0, $multa['fid'], 0.0, 0, 0, NULL, 0, $fDesde, $fHasta);
                if(is_array($cobros)){
                    foreach($cobros as $cobro){
                        $cobrador = User::ObtenerPorId($cobro['cobrador']);
                        $objPHPExcel->setActiveSheetIndex(0)
                        ->setCellValue('A'.($count), $cobro['cbid'])
                        ->setCellValue('B'.($count), $equipo->GetNombre())
                        ->setCellValue('C'.($count), $categoria->GetNombre())
                        ->setCellValue('D'.($count), $equipo->GetId())
                        ->setCellValue('G'.($count), $tipoMulta[0]['descripcion']." ".FormatDate($multa['fEmision']))
                        ->setCellValue('H'.($count), FormatDate($cobro['fPago']))
                        ->setCellValue('I'.($count), $cobro['monto'])
                        ->setCellValue('J'.($count), $cobro['forma'])
                        ->setCellValue('K'.($count), $cobro['comentario'])
                        ->setCellValue('L'.($count), $cobro['fid'])
                        ->setCellValue('M'.($count), $cobro['cobrador']."-".$cobrador->GetApellido()." ".$cobrador->GetNombre());
                        $count++;
                    }
                }
            }
        }
    }

    //Cuotas Socios generales
    $cuotaObj = new Cuota();
    $cuotas = $cuotaObj->ListarCuotas();

    //Deudas Socios generales
    $deudasSocios = Deuda::ListarDeudasSocio();
    //Multas Socios
    $multasSocioObj = new Multa(0, Database::TABLA_MULTAS_JUGADOR, 'jugador');
    $multasSocios = $multasSocioObj->ListarMultas();

    if(is_array($cuotas)){
        foreach($cuotas as $cuota){
            if($cuota['fid'] > 0 && !in_array($cuota['fid'], $listaFacturas)){
                if($cuota['sid'] > 0){
                    $jugador = Jugador::ObtenerPorSid($cuota['sid']);
                    $socio = new Socio($cuota['sid']);
                    $usuario = User::ObtenerPorId($socio->GetUid());
                    $equipo = Equipo::ObtenerPorId($jugador->GetEquipo());
                    $categoria = Categoria::ObtenerPorCid($equipo->GetCategoria());
                }
                $cobros = Cobro::ListarCobros(0, $cuota['fid'], 0.0, 0, 0, NULL, 0, $fDesde, $fHasta);
                if(is_array($cobros)){
                    foreach($cobros as $cobro){
                        $cobrador = User::ObtenerPorId($cobro['cobrador']);
                        $objPHPExcel->setActiveSheetIndex(0)
                        ->setCellValue('A'.($count), $cobro['cbid'])
                        ->setCellValue('B'.($count), $equipo->GetNombre())
                        ->setCellValue('C'.($count), $categoria->GetNombre())
                        ->setCellValue('D'.($count), $equipo->GetId())
                        ->setCellValue('E'.($count), $usuario->GetApellido()." ".$usuario->GetNombre())
                        ->setCellValue('F'.($count), $cuota['sid'])
                        ->setCellValue('G'.($count), 'Cuota Social '.FormatDate($cuota['fEmision']))
                        ->setCellValue('H'.($count), FormatDate($cobro['fPago']))
                        ->setCellValue('I'.($count), $cobro['monto'])
                        ->setCellValue('J'.($count), $cobro['forma'])
                        ->setCellValue('K'.($count), $cobro['comentario'])
                        ->setCellValue('L'.($count), $cobro['fid'])
                        ->setCellValue('M'.($count), $cobro['cobrador']."-".$cobrador->GetApellido()." ".$cobrador->GetNombre());
                        $count++;
                    }
                }
            }
        }
    }

    if(is_array($deudasSocios)){
        foreach($deudasSocios as $deuda){
            if($deuda['fid'] > 0){
                if($deuda['sid'] > 0){
                    $jugador = Jugador::ObtenerPorSid($deuda['sid']);
                    $socio = new Socio($deuda['sid']);
                    $usuario = User::ObtenerPorId($socio->GetUid());
                    $equipo = Equipo::ObtenerPorId($jugador->GetEquipo());
                    $categoria = Categoria::ObtenerPorCid($equipo->GetCategoria());
                }
                $cobros = Cobro::ListarCobros(0, $deuda['fid'], 0.0, 0, 0, NULL, 0, $fDesde, $fHasta);
                if(is_array($cobros)){
                    foreach($cobros as $cobro){
                        $cobrador = User::ObtenerPorId($cobro['cobrador']);
                        $objPHPExcel->setActiveSheetIndex(0)
                        ->setCellValue('A'.($count), $cobro['cbid'])
                        ->setCellValue('B'.($count), $equipo->GetNombre())
                        ->setCellValue('C'.($count), $categoria->GetNombre())
                        ->setCellValue('D'.($count), $equipo->GetId())
                        ->setCellValue('E'.($count), $usuario->GetApellido()." ".$usuario->GetNombre())
                        ->setCellValue('F'.($count), $deuda['sid'])
                        ->setCellValue('G'.($count), $deuda['concepto'])
                        ->setCellValue('H'.($count), FormatDate($cobro['fPago']))
                        ->setCellValue('I'.($count), $cobro['monto'])
                        ->setCellValue('J'.($count), $cobro['forma'])
                        ->setCellValue('K'.($count), $cobro['comentario'])
                        ->setCellValue('L'.($count), $cobro['fid'])
                        ->setCellValue('M'.($count), $cobro['cobrador']."-".$cobrador->GetApellido()." ".$cobrador->GetNombre());
                        $count++;
                    }
                }
            }
        }
    }

    if(is_array($multasSocios)){
        foreach($multasSocios as $multa){
            if($multa['fid'] > 0){
                $tipoMulta = Multa::ListarTiposMultas($multa['tmid']);
                if($multa['jugador'] > 0){
                    $jugador = new Jugador($multa['jugador']);
                    $socio = new Socio($jugador->GetSid());
                    $usuario = User::ObtenerPorId($socio->GetUid());
                    $equipo = Equipo::ObtenerPorId($jugador->GetEquipo());
                    $categoria = Categoria::ObtenerPorCid($equipo->GetCategoria());
                }
                $cobros = Cobro::ListarCobros(0, $multa['fid'], 0.0, 0, 0, NULL, 0, $fDesde, $fHasta);
                if(is_array($cobros)){
                    foreach($cobros as $cobro){
                        $cobrador = User::ObtenerPorId($cobro['cobrador']);
                        $objPHPExcel->setActiveSheetIndex(0)
                        ->setCellValue('A'.($count), $cobro['cbid'])
                        ->setCellValue('B'.($count), $equipo->GetNombre())
                        ->setCellValue('C'.($count), $categoria->GetNombre())
                        ->setCellValue('D'.($count), $equipo->GetId())
                        ->setCellValue('E'.($count), $usuario->GetApellido()." ".$usuario->GetNombre())
                        ->setCellValue('F'.($count), $jugador->GetSid())
                        ->setCellValue('G'.($count), $tipoMulta[0]['descripcion']." ".FormatDate($multa['fEmision']))
                        ->setCellValue('H'.($count), FormatDate($cobro['fPago']))
                        ->setCellValue('I'.($count), $cobro['monto'])
                        ->setCellValue('J'.($count), $cobro['forma'])
                        ->setCellValue('K'.($count), $cobro['comentario'])
                        ->setCellValue('L'.($count), $cobro['fid'])
                        ->setCellValue('M'.($count), $cobro['cobrador']."-".$cobrador->GetApellido()." ".$cobrador->GetNombre());
                        $count++;
                    }
                }
            }
        }
    }

    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
    $objWriter->save('php://output');
}

// Funcion generar excel deudas
function ExcelDeudas(){

    var_dump($_POST['header']);
    ob_end_clean();
    $header = json_decode($_POST['header']);
    $deudas = json_decode($_POST['deudas']);

    var_dump($header);
    var_dump($deudas);

    /*
    global $user;

    $filename = "deudas";

    PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);

    $objPHPExcel = new PHPExcel();
    $objPHPExcel->getProperties()->setCreator("Treemind")
    ->setLastModifiedBy("Treemind")
    ->setTitle($filename)
    ->setSubject($filename)
    ->setDescription($filename)
    ->setKeywords($filename)
    ->setCategory($filename);

    $objPHPExcel->setActiveSheetIndex(0)
    ->setCellValue('A1', "Id Cobro")
    ->setCellValue('B1', "Equipo")
    ->setCellValue('C1', "Categoria")
    ->setCellValue('D1', "Id Equipo")
    ->setCellValue('E1', "Socio")
    ->setCellValue('F1', "Id Socio")
    ->setCellValue('G1', "Concepto")
    ->setCellValue('H1', "Fecha de cobro")
    ->setCellValue('I1', "Monto")
    ->setCellValue('J1', "Forma")
    ->setCellValue('K1', "Comentario")
    ->setCellValue('L1', "Id Factura")
    ->setCellValue('M1', "Cobrador");

    $ArrayCell = array('C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U');

    $style = array(
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        )
    );

    $objPHPExcel->setActiveSheetIndex(0)->getDefaultStyle()->applyFromArray($style);
    */

}
?>
