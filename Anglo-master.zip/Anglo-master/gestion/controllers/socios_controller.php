<?php
session_start();
require("core/core.php");
require("config/sys.conf.php");
require("models/class.User.php");
require("models/class.Socio.php");
require("models/class.Facturacion.php");
require("models/class.Deportivo.php");

define("TITLE", "Socios");

//Llamada a la vista
if($_SESSION['api_id']['login'])
{

  $user = new User($_SESSION['api_id']['uid']);

  define("PRIVILEGIO", $temp);

  $accion = (!empty($_POST['funcion'])) ? $_POST['funcion'] : ((!empty($vista[1])) ? $vista[1] : 'index');
  $dato = (!empty($_POST['dato'])) ? $_POST['dato'] : ((!empty($vista[2])) ? $vista[2] : NULL);

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR || $_SESSION['api_id']['uPrivilegio'] == User::TIPO_COBRADOR)
  {
    call_user_func($accion, $dato);
  }else if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
    header("Location: /".$root."/logout");
  }else{
    ErrorPrivilegio();
  }

}else
{

  //Llamada a la vista
  header("location:  /".$root."/login");

}

//Funcion muestra vista Indice
function index (){

  //$socios = new Socio();
  require_once("views/socios.phtml");

}

//Funcion Listar Socios
function ListarSocios ($activo) {
  $lista = Socio::ListarSocios($activo);

  if(is_object($lista) || is_array($lista)){
    foreach($lista as $i => $socio){
      $SocioTemp = Socio::ObtenerPorUid($socio['uid']);
      $estadoCuota = $SocioTemp->ConsultaVecimientoCuotas();

      if($socio['activo'] == 1){
        $lista[$i]['activo'] = 'activo';
      }else{
        $lista[$i]['activo'] = 'inactivo';
      }

      if($estadoCuota == Cuota::CONSULTA_OK){
        $alertaCuota = "PAGADA";
        $alertaColor = "teal";
      }else if($estadoCuota == Cuota::CONSULTA_VENCIDO){
        $alertaCuota = "VENCIDO";
        $alertaColor = "pink";
      }else if($estadoCuota == Cuota::CONSULTA_ADVERTENCIA){
        $alertaCuota = "POR VENCER";
        $alertaColor = "orange";
      }else if($estadoCuota == Cuota::CONSULTA_NA_REGISTRO){
        $alertaCuota = "NA";
        $alertaColor = "pink";
      }else if($estadoCuota == Cuota::CONSULTA_IMPAGA){
        $alertaCuota = "IMPAGA";
        $alertaColor = "pink";
      }

      $edad = User::GetEdad($socio['fNacimiento']);

      $lista[$i]['cuota']['estado'] = $alertaCuota;
      $lista[$i]['cuota']['color'] = $alertaColor;
      $lista[$i]['edad'] = $edad;


    }
  }

  echo json_encode($lista);
}

//Funcion Regex Socios
function RegexSocio () {
  $nombre = $_POST['nombre'];

  $usuarios = User::RegexUsuarios($nombre);

    if(is_array($usuarios)){
        foreach($usuarios as $u => $usuario){
            $socio = Socio::ObtenerPorUid($usuario['id']);
            $usuarios[$u]['sid'] = $socio->GetId();
        }
    }

    echo json_encode($usuarios);
}

//Funcion Ver
function ver ($uid){

  $funcion = 'actualizar';

  require_once("views/socios_editar.phtml");

}

function ConsultaSocioPorUid ($uid) {

  // Tomo la variable global user
  global $user;

  // Genero el objeto usuario (del socio) apartir del UID (obtenido del socio)
  $usuario = User::ObtenerPorId($uid);

  // Genero el objeto socio apartir de UID
  $socio = Socio::ObtenerPorUid($uid);  

  // Obtengo el nombre del socio
  $NombreSocio = $usuario->getNombre();

  $DniSocio = $usuario->GetDNI();

  $ImagenSocio = $usuario->GetImagen();

  // Obtengo el apellido del socio
  $ApellidoSocio = $usuario->GetApellido();


  $resultado = array(
    "socio" => array("nombre" => $NombreSocio,
    "sid" => $socio->GetId(),
    "dni" => $DniSocio,
    "imagen" => $ImagenSocio,
    "apellido" => $ApellidoSocio)
  );

  echo json_encode($resultado);
}

function ConsultaSocio ($uid) {

  // Tomo la variable global user
  global $user;

  // Genero el objeto socio apartir de UID
  $socio =  new Socio($uid);

  // Genero el objeto usuario (del socio) apartir del UID (obtenido del socio)
  $usuario = User::ObtenerPorId($socio->GetUid());

  // Obtengo el nombre del socio
  $NombreSocio = $usuario->getNombre();

  // Obtengo el apellido del socio
  $ApellidoSocio = $usuario->GetApellido();

  // Obtengo el estado (activo o inactivo) del socio
  $ActivoSocio = $socio->GetActivo();

  // Obtengo estado de cuotas del socio
  $estadoCuota = $socio->ConsultaVecimientoCuotas();

  // Obtengo el estado de la inscripcion del socio
  $inscripcion = $socio->ConsultaInscripcion();

  if($inscripcion['estado'] == Socio::INSCRIPCION_VENCIDO){
    $colorTaskInscripcion = 'pink';
    $messageTaskInscripcion = 'VENCIDO';
  }else if($inscripcion['estado'] == Socio::INSCRIPCION_OK){
    $colorTaskInscripcion = 'teal';
    $messageTaskInscripcion = 'VALIDO';
  }else if($inscripcion['estado'] == Socio::INSCRIPCION_ADVERTENCIA){
    $colorTaskInscripcion = 'orange';
    $messageTaskInscripcion = 'POR VENCER';
  }

  $emmac = $socio->ConsultaEMMAC();

  if($emmac['estado'] == Socio::EMMAC_VENCIDO){
    $colorTaskEMMAC = 'pink';
    $messageTaskEMMAC = 'VENCIDO';
  }else if($emmac['estado'] == Socio::EMMAC_OK){
    $colorTaskEMMAC = 'teal';
    $messageTaskEMMAC = 'VALIDO';
  }else if($emmac['estado'] == Socio::EMMAC_ADVERTENCIA){
    $colorTaskEMMAC = 'orange';
    $messageTaskEMMAC = 'POR VENCER';
  }else if($emmac['estado'] == Socio::EMMAC_NA_REGISTRO){
    $colorTaskEMMAC = 'grey';
    $messageTaskEMMAC = 'SIN DATOS';
  }

  // Obtengo el parametro del valor de la cuota social
  $CuotaMonto = $user->GetParametro(100);

  // Obtengo la lista de cuotas pagadas del socio
  $cuotasPagadas = $socio->ListarCuotasPagadas($month, $year);

  // Obtengo la lsita de cuotas impagas del socio
  $cuotasImpagas = $socio->ListarCuotasImpagas($month, $year);

  // Genero el objeto jugador apartir del SID
  $jugador = Jugador::ObtenerPorSid($socio->GetId());

  if(is_object($jugador) && $jugador->GetId() > 0){

    // Obtengo la lista de multas pagadas del jugador
    $multasPagadas = $jugador->ListarMultasPagadas($year);

    // Obtengo la lista de multas impagas del jugador
    $multasImpagas = $jugador->ListarMultasImpagas($year);

    // Obtengo el historial de equipos del jugador
    $historialEquipos = $jugador->HistorialEquipos();

  }

  // Obtengo la lista de deudas pagadas del socio
  $deudasPagadas = Deuda::ListarDeudasSocio($socio->GetId(), $month, $year, Deuda::ESTADO_PAGADA);

  // Obtengo la lsita de deudas impagas del socio
  $deudasImpagas = Deuda::ListarDeudasSocio($socio->GetId(), $month, $year, Deuda::ESTADO_IMPAGA);

  // Genero el objeto equipo apartir del EID
  $equipo = Equipo::ObtenerPorId($jugador->GetEquipo());

  $totalJugadores = $equipo->TotalJugadores();

  // Genero color de aviso de equipo
  if($equipo->GetId() > 0){
    $colorEquipo = "teal";
  }else{
    $colorEquipo = "pink";
  }

  // Genero el objeto categoria apartir del CID
  $categoria = Categoria::ObtenerPorCid($equipo->GetCategoria());

  $nombreEquipo = $equipo->GetNombre();
  $categoriaEquipo = $categoria->GetNombre();


  $resultado = array(
    "jid" => $jugador->GetId(),
    "socio" => array("nombre" => $NombreSocio,
    "sid" => $socio->GetId(),
    "apellido" => $ApellidoSocio,
    "activo" => $ActivoSocio,
    "estadoCuota" => $estadoCuota),

    "equipo" => array("color" => $colorEquipo,
    "nombre" => ((!empty($nombreEquipo)) ? $nombreEquipo : 'Sin equipo'),
    "categoria" => ((!empty($categoriaEquipo)) ? $categoriaEquipo : 'Sin Categoria'),
    "totaljugadores" => $totalJugadores['total']),

    "historialequipos" => $historialEquipos,

    "baja" => array("fecha" => $socio->GetfBaja()),

    "inscripcion" => array("color" => $colorTaskInscripcion,
    "mensaje" => $messageTaskInscripcion,
    "fecha" => $inscripcion['fecha']),

    "emmac" => array("color" => $colorTaskEMMAC,
    "mensaje" => $messageTaskEMMAC,
    "fecha" => $emmac['fecha'],
    "dias"  => $emmac['dias']),

    "cuotamonto" => $CuotaMonto,

    "cuotaspagadas" => (!empty($cuotasPagadas)) ? $cuotasPagadas : array(),

    "cuotasimpagas" => (!empty($cuotasImpagas)) ? $cuotasImpagas : array(),

    "multaspagadas" => (!empty($multasPagadas)) ? $multasPagadas : array(),

    "multasimpagas" => (!empty($multasImpagas)) ? $multasImpagas : array(),

    "deudaspagadas" => (!empty($deudasPagadas)) ? $deudasPagadas : array(),

    "deudasimpagas" => (!empty($deudasImpagas)) ? $deudasImpagas : array()
  );

  echo json_encode($resultado);
}

function EliminarCuota ($cid) {

  $cuota = new Cuota($cid);
  if($resultado = Cuota::eliminar($cid)){
    if ($cuota->getFid() > 0) {
      $factura = new Facturacion($cuota->getFid());
      $factura->eliminar();
    }
    EnviarAlerta('success', 'Se elimino correctamente la cuota');

  }else{

    EnviarAlerta('error', 'No se elimino la cuota');

  }

}

function EliminarCuotasImpagas () {

  $sid = $_POST['sid'];
  $estado = Cuota::ESTADO_IMPAGA;

  if($resultado = Cuota::eliminar(0, $sid, $estado)){

    EnviarAlerta('success', 'Se eliminaron correctamente las cuotas');

  }else{

    EnviarAlerta('error', 'No se eliminaron las cuotas');

  }

}

//Funcion Insertar Cuota
function InsertarCuota (){

  $fEmision = $_POST['fEmision'];
  $fVencimiento = $_POST['fVencimiento'];
  $monto = $_POST['monto'];
  $sid = $_POST['sid'];
  $estado = $_POST['estado'];

  $socio = new Socio($sid);
  try {
    $socio->EmitirCuota($fEmision, $fVencimiento, $monto, $estado);
    EnviarAlerta('success', 'Se creo la cuota correctamente');
  }
  
  //catch exception
  catch(Exception $e) {
    EnviarAlerta('error', 'No se pudo crear la cuota correctamente: '.$e);
  }

}

//Funcion Editar Cuota
function EditarCuota (){

  $fEmision = $_POST['fEmision'];
  $fVencimiento = $_POST['fVencimiento'];
  $monto = $_POST['monto'];
  $cid = $_POST['cid'];
  $estado = $_POST['estado'];
  $fid = $_POST['fid'];

  $socio = new Socio($sid);

  if($socio->EditarCuota ($cid, $fEmision, $fVencimiento, $fPago, $monto, $estado, $fid)){

    EnviarAlerta('success', 'Se edito la cuota correctamente: '.$fid);

  }else{

    EnviarAlerta('success', 'Se edito la cuota correctamente: '.$fid);
    //EnviarAlerta('error', 'No se pudo crear la cuota correctamente');

  }

}

//Funcion Renovar Emmac
function RenovarEMMAC () {

  $sid = $_POST['sid'];
  $fecha = $_POST['fecha'];

  $socio = new Socio($sid);

  if($socio->RenovacionEMMAC($fecha)){

    EnviarAlerta('success', 'Se renovo exitosamente');

  }else{

    EnviarAlerta('error', 'No se pudo renovar');

  }

}

//Funcion Renovar Inscripcion
function RenovarInscripcion () {

  $sid = $_POST['sid'];
  $fecha = $_POST['fecha'];

  $socio = new Socio($sid);

  if($socio->RenovacionInscripcion($fecha)){

    EnviarAlerta('success', 'Se renovo exitosamente');

  }else{

    EnviarAlerta('error', 'No se pudo renovar');

  }

}

//Funcion Pagar Cuota
function PagarCuota ($dato) {

  $cid = $_POST['cid'];
  $fid = $_POST['fid'];

  global $user;

  $CuotaMonto = $user->GetParametro(100);

  $socio = new Socio();

  if($resultado = $socio->PagarCuota(0, $CuotaMonto['valor'], $fid))
  {

    EnviarAlerta('success', 'Se efectuo exitosamente: '.$resultado);

  }else{

    EnviarAlerta('error', 'No se pudo efectuar: '.$resultado);

  }
}

//Funcion Cancelar Pago Cuota
function CancelarPagoCuota ($dato) {

  $cid = $_POST['cid'];
  $fid = $_POST['fid'];

  global $user;

  $CuotaMonto = $user->GetParametro(100);

  $socio = new Socio();

  if($resultado = $socio->CancelarPagoCuota(0, $fid))
  {

    EnviarAlerta('success', 'Se efectuo exitosamente: '.$resultado);

  }else{

    EnviarAlerta('error', 'No se pudo efectuar: '.$resultado);

  }
}

//Funcion Pagar Multa
function PagarMulta ($dato) {

  // Tomo la variable global user
  global $user;

  // Obtengo datos de POST
  //$datos = explode(",", $dato);

  // Guardo MID (id de multa)
  //$mid = $datos[0];
  $mid = $_POST['mid'];

  // Guardo monto de la multa
  //$monto = $datos[1];
  //$monto = $_POST['monto'];

  // Guardo FID (id de factura)
  $fid = $_POST['fid'];

  // Genero el objeto Jugador
  $jugador = new Jugador();

  // Confirmo si se efectuo el pago
  if($resultado = $jugador->PagarMulta(0, $fid))
  {

    EnviarAlerta('success', 'Se efectuo exitosamente');

  }else{

    EnviarAlerta('error', 'No se pudo efectuar: '.$resultado);

  }
}

//Funcion dar baja socio
function DarBaja ($dato) {

  // Genero el objeto Socio apartir del dato POST
  $socio = new Socio($dato);

  // Confirmo si se efectuo la accion
  if($resultado = $socio->DarBaja())
  {

    EnviarAlerta(1, 'Se efectuo exitosamente');

  }else{

    EnviarAlerta(0, 'No se pudo efectuar: '.$resultado);

  }

}

//Funcion dar alta socio
function DarAlta ($dato) {

  $parametro = new User();

  // Genero el objeto Socio apartir del dato POST
  $socio = new Socio($dato);

  // Confirmo si se efectuo la accion
  if($resultado = $socio->DarAlta())
  {

    if(!empty($_POST['inscripcion']) && $_POST['inscripcion'] == 1){
      // Obtengo el parametro del valor de la inscripcion
      $InscripcionMonto = $parametro->GetParametro(103);
      /*$mes = date('n')+1;
      $fecha = date('Y')."-".$mes."-".date('j');
      if($mes > 12){
        $fecha = (date('Y')+1)."-1-".date('j');
      }*/
      $deuda = new Deuda(0, 'Inscripcion '.date('Y'), date('Y-n-j'), date('Y-n-j'), $InscripcionMonto['valor'], $dato);
      $resultado = $deuda->registroSocio();
    }

    EnviarAlerta(1, 'Se efectuo exitosamente');

  }else{

    EnviarAlerta(0, 'No se pudo efectuar: '.$resultado);

  }

}

//Funcion Emitir cuotas sociales
//a todos los socios que no tengan
//cuota emitida del mes
function EmitirCuotasSociales ($dato) {

  global $user;

  $CuotaMonto = $user->GetParametro(102);

  $month = $dato;

  // Obtengo lista de socios activos
  $socios = Socio::ListarSocios(Socio::ESTADO_ACTIVO);

  // Contador de socios sin cuotas emitidas
  $sociosSinCuotas = 0;

  // Verifico si tengo una lista
  // y reccorro la misma para ver
  // si tienen emitida la cuota del mes actual
  if(is_array($socios) || is_object($socios)) {
    foreach($socios as $socio) {

      // Genero objeto Socio
      $socioTemp = new Socio($socio['sid']);

      $year = date('Y');

      $inscripcion = $socioTemp->ConsultaInscripcion();

      $fechaInscripcion = explode("-", $inscripcion['fecha']);

      // Obtengo lista de cuotas pagadas de este mes
      $cuotasPagadas = $socioTemp->ListarCuotasPagadas($month, $year);

      // Obtengo lista de cuotas impagas de este mes
      $cuotasImpagas = $socioTemp->ListarCuotasImpagas($month, $year);

      //if(count($cuotasPagadas) == 0 && count($cuotasImpagas) == 0 && $socio['activo']) {
      if($socio['activo']) {
        $socioTemp->EmitirCuota(date('Y-n-j'), date('Y-n')."-".$CuotaMonto['valor'], 0, Cuota::ESTADO_IMPAGA);
        $sociosSinCuotas++;
      }
    }

    if($sociosSinCuotas > 0){

      EnviarAlerta('success', 'Se efectuo exitosamente');

    }else{

      EnviarAlerta('error', 'No se pudo efectuar');

    }
  }
}

// Funcion listar deudas socio
function deudasSocio($sid){

  global $user;

  $cuotas = Cuota::ListarCuotas(0, $sid, 0, 0, Cuota::ESTADO_IMPAGA);
  $jugador = Jugador::ObtenerPorSid($sid);
  $equipo = Equipo::ObtenerPorId($jugador->GetEquipo());
  // Obtengo el parametro del valor de la cuota social
  $CuotaMonto = $user->GetParametro(100);
  if($jugador->GetId() > 0){
    $multas = $jugador->ListarMultasImpagas();
  }

  $deudas = Deuda::ListarDeudasSocio($sid, 0, 0, Deuda::ESTADO_IMPAGA);

  $lista = array();

  if(is_array($cuotas)){
    foreach($cuotas as $cuota){
      $saldo = 0;
      if($cuota['fid'] > 0){
        $cobros = Cobro::ListarCobros(0, $cuota['fid']);
        if(is_array($cobros)){
          foreach($cobros as $cobro){
            $saldo += $cobro['monto'];
          }
        }
      }
      $monto = (($cuota['monto'] == 0) ? $CuotaMonto['valor'] : $cuota['monto']);
      $lista[] = array("descripcion" => ' Cuota '.FormatDate($cuota['fEmision'].(($cuota['fid'] > 0) ? ' Factura ID: '.$cuota['fid'] : '')),
      "equipo" => $equipo->GetNombre(),
      "monto" => $monto,
      "saldo" => $monto-$saldo,
      "fEmision" => $cuota['fEmision'], "fVencimiento" => $cuota['fVencimiento']);
    }
  }

  if(is_array($multas)){
    foreach($multas as $multa){
      $tipoMulta = Multa::ListarTiposMultas($multa['tmid']);
      $saldo = 0;
      if($multa['fid'] > 0){
        $cobros = Cobro::ListarCobros(0, $multa['fid']);
        if(is_array($cobros)){
          foreach($cobros as $cobro){
            $saldo += $cobro['monto'];
          }
        }
      }
      $monto = (($multa['monto'] == 0) ? $tipoMulta[0]['precio'] : $multa['monto']);
      $lista[] = array("descripcion" => ' Multa '.FormatDate($multa['fEmision'].(($multa['fid'] > 0) ? ' Factura ID: '.$multa['fid'] : '')),
      "equipo" => $equipo->GetNombre(),
      "monto" => $monto,
      "saldo" => $monto-$saldo,
      "fEmision" => $multa['fEmision'], "fVencimiento" => '');
    }
  }

  if(is_array($deudas)){
    foreach($deudas as $deuda){
      $saldo = 0;
      if($deuda['fid'] > 0){
        $cobros = Cobro::ListarCobros(0, $deuda['fid']);
        if(is_array($cobros)){
          foreach($cobros as $cobro){
            $saldo += $cobro['monto'];
          }
        }
      }
      $lista[] = array("descripcion" => $deuda['concepto'].(($deuda['fid'] > 0) ? ' Factura ID: '.$deuda['fid'] : ''),
      "equipo" => $equipo->GetNombre(),
      "monto" => $deuda['importe'],
      "saldo" => $deuda['importe']-$saldo,
      "fEmision" => $deuda['fEmision'], "fVencimiento" => $deuda['fVencimiento']);
    }
  }

  echo json_encode($lista);
}

//Funcion Insertar Deuda
function InsertarDeuda (){

  $fEmision = $_POST['fEmision'];
  $fVencimiento = $_POST['fVencimiento'];
  $monto = $_POST['fImporte'];
  $descripcion = $_POST['dDescripcion'];
  $sid = $_POST['sid'];
  $estado = $_POST['estado'];

  $socio = new Socio($sid);
  $deuda = new Deuda(0, $descripcion, $fEmision, $fVencimiento, $monto, $sid);
  if($deuda->registroSocio()){

    EnviarAlerta('success', 'Se creo la deuda correctamente');

  }else{

    EnviarAlerta('success', 'Se creo la deuda correctamente');
    //EnviarAlerta('error', 'No se pudo crear la cuota correctamente');

  }

}
?>
