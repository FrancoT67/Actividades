<?php

error_reporting(E_ALL);
session_start();
require('config/cache.conf.php');
//require("config/sys.conf.php");
require("models/class.User.php");


/*if($_SESSION['api_id']['login'] == true)
{
header("Location: index");
}else
{*/
if($_POST['login'] == 1){
    $nick = $_POST['nick'];
    $password = $_POST['password'];
    $User = new User();
    echo $User->login($nick, $password);
    //require_once("views/index.phtml");
}else if($_POST['login'] == 2){

    if($_SESSION['api_id']['login'] != true){
        $User = new User();
        $User->invitado();
    }

}else{
    //Llamada a la vista
    define("TITLE", 'Login');
    //define('TITLE', "Login");
    require_once("views/login.phtml");
}
//}

?>
