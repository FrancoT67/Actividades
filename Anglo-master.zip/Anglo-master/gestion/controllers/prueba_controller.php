<?php
$equipos_zona1 = array("equipo1", "equipo2", "equipo3", "equipo4");
$equipos_zona2 = array("equipo5", "equipo6", "equipo7", "equipo8");
$puntos_zona1 = array();                                    // Puntos de cada equipo de la primera zona.
$puntos_zona2 = array();                                    // Puntos de cada equipo de la segunda zona.
$cant_partidos = (count($equipos_zona1) + count($equipos_zona2)) - 1;                                       // Partidos de la semi o final.
$partidos_zona1 = array();                                           // Arreglo con los partidos de la primera zona.
$partidos_zona2 = array();                                           // Arreglo con los partidos de la segunda zona.
$cuantsemis = 4;

if(count($equipos_zona1) % 2 == 0 && count($equipos_zona2) % 2 == 0)
{

    foreach($equipos_zona1 as $equipofijo){
            foreach($equipos_zona1 as $equipos){
                    if($equipofijo == $equipos){
                            continue;
                    }
                    $combinaciones = array($equipofijo,$equipos);
                    sort($combinaciones);                                   // Ordeno el arreglo
                    if(!in_array($combinaciones,$partidos_zona1)){           // Si no esta agrego el partido
                            $partidos_zona1[] = $combinaciones;
                    }
            }
    }

    for ($row = 0; $row < count($partidos_zona1, COUNT_RECURSIVE); $row++){
        for ($col = 0; $col < count($partidos_zona1, COUNT_RECURSIVE); $col++)
        {
            echo $partidos_zona1[$row][$col];

        }
        echo "<br>";
    }


    foreach($equipos_zona2 as $equipofijo){
            foreach($equipos_zona2 as $equipos){
                    if($equipofijo == $equipos){
                            continue;
                    }
                    $combinaciones = array($equipofijo,$equipos);
                    sort($combinaciones);                           // Ordeno el arreglo
                    if(!in_array($combinaciones,$partidos_zona2)){           // Si no esta agrego el partido
                            $partidos_zona2[] = $combinaciones;
                    }
            }
    }

    for ($row = 0; $row < count($partidos_zona1, COUNT_RECURSIVE); $row++){
        for ($col = 0; $col < count($partidos_zona1, COUNT_RECURSIVE); $col++)
        {
            echo $partidos_zona2[$row][$col];

        }
        echo "<br>";
    }


    /*for($i = 0; $i < 4; $i++){                                      // Obtengo los 4 maximos para la siguiente ronda
        $val1 = max($puntos_zona1);
        $val2 = max($puntos_zona2);
        $semi_zona1[i] = $val1;
        $semi_zona2[i] = $val2;
    }*/

}else if(count($equipos_zona1) % 2 != 0 && count($equipos_zona2) % 2 != 0){
    array_push($equipos_zona2, "bot");                              // Agrego un bot para que al que le toque pase directo.

    foreach($equipos_zona1 as $equipofijo){
            foreach($equipos_zona1 as $equipos){
                    if($equipofijo == $equipos){
                            continue;
                    }
                    $combinaciones = array($equipofijo,$equipos);
                    sort($combinaciones);                           // Ordeno el arreglo
                    if(!in_array($combinaciones,$partidos_zona1)){           // Si no esta agrego el partido
                            $partidos_zona1[] = $combinaciones;
                    }
            }
    }
    var_dump($partidos_zona1);

    foreach($equipos_zona2 as $equipofijo){
            foreach($equipos_zona2 as $equipos){
                    if($equipofijo == $equipos){
                            continue;
                    }
                    $combinaciones = array($equipofijo,$equipos);
                    sort($combinaciones);                           // Ordeno el arreglo
                    if(!in_array($combinaciones,$partidos_zona2)){           // Si no esta agrego el partido
                            $partidos_zona2[] = $combinaciones;
                    }
            }
    }


    /*for($i = 0; $i < $cuantsemis; $i++){                                      // Obtengo los 4 maximos para la siguiente ronda
        $val1 = max($puntos_zona1);
        $val2 = max($puntos_zona2);
        $semi_zona1[i] = $val1;
        $semi_zona2[i] = $val2;
    }*/
}

//-=== Aca genero los partidos de la semifinal o final. Dependiendo del caso ==-//
/*if($equipos_zona1 % 2 == 0 && $equipos_zona2 % 2 == 0)
{
    $i = 0;
    $j = count($semi_zona2)-1;

    while( i < $semi_zona1 && j >= 0){
        $partidos[i] = $semi_zona1[i] && $semi_zona2[j]
        $i++;
        $j--;
    }
}else{
    array_push($semi_zona2, "bot");
    $i = 0;
    $j = count($semi_zona2)-1;

    while( i < $semi_zona1 && j >= 0){
        $partidos[i] = $semi_zona1[i] && $semi_zona2[j]
        $i++;
        $j--;
    }
}*/
?>
