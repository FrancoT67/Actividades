<?php
session_start();
require("core/core.php");
require("config/sys.conf.php");
require("models/class.User.php");
require("models/class.Socio.php");
require("models/class.Deportivo.php");
require("models/class.Facturacion.php");
require("models/class.Loggin.php");
header("Content-Type: text/html;charset=utf-8");

define("TITLE", "Facturacion");

//Llamada a la vista
if($_SESSION['api_id']['login'])
{

    $user = new User($_SESSION['api_id']['uid']);

    define("PRIVILEGIO", $temp);

    $accion = (!empty($_POST['funcion'])) ? $_POST['funcion'] : ((!empty($vista[1])) ? $vista[1] : 'index');
    $dato = (!empty($_POST['dato'])) ? $_POST['dato'] : ((!empty($vista[2])) ? $vista[2] : NULL);

    if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR || $_SESSION['api_id']['uPrivilegio'] == User::TIPO_COBRADOR)
    {
        call_user_func($accion, $dato);
    }else if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
        header("Location: /".$root."/logout");
    }else{
        ErrorPrivilegio();
    }

}else
{

    //Llamada a la vista
    header("location:  /".$root."/login");

}

//Funcion muestra vista Indice
function index () {

    $facturas = Facturacion::ListarFacturas($tipo = NULL, $fEmision = NULL, $estado = $_GET['lista']);

    if(is_array($facturas) || is_object($facturas)){
        foreach($facturas as $i => $factura){
            // Genero objeto equipo vacio
            $equipo = new Equipo(0);

            $cobros = Cobro::ListarCobros( 0, $factura['fid']);
            $detalles = Detalle::ListarDetalles($factura['fid']);
            $facturas[$i]['TotalCobrado'] = 0;
            $facturas[$i]['TotalDeuda'] = 0;

            if(is_array($cobros)){
                foreach($cobros as $cobro){
                    $facturas[$i]['TotalCobrado'] += $cobro['monto'];
                }
            }

            if(is_array($detalles)){
                foreach($detalles as $detalle){
                    $facturas[$i]['TotalDeuda'] += $detalle['monto'];
                }
            }

            if($factura['tipo'] == Facturacion::TIPO_FACTURA_A){

                $cotribucion = $equipo->ListarContribucionDeportiva(0, 0, NULL, $factura['fid']);
                $equipo = Equipo::ObtenerPorId($cotribucion[0]['eid']);
                $categoria = Categoria::ObtenerPorCid($equipo->GetCategoria());
                $facturas[$i]['remitente'] = $equipo->GetNombre()." (".$categoria->GetNombre().") - Cuota Unica";

            } else {
                // Genero objeto socio vacio
                $socio = new Socio(0);
                // Genero objeto jugador vacio
                $jugador = new Jugador(0);

                // Obtengo lista de cuotas SI ES QUE EXISTEN
                $cuotas = $socio->Cuota(0, $factura['fid']);

                // Obtengo lista de multas jugador SI ES QUE EXISTEN
                $multasJugador = $jugador->Multas($factura['fid']);

                // Obtengo lista de multas equipo SI ES QUE EXISTEN
                $multasEquipo = $equipo->Multas($factura['fid']);

                // Obtengo lista de deduas socios SI ES QUE EXISTEN
                $deduasSocio = Deuda::ListarDeudasSocio(0,  0, 0, NULL, $factura['fid']);

                // Obtengo lista de deduas socios SI ES QUE EXISTEN
                $deudasEquipo = Deuda::ListarDeudasEquipo(0,  0, 0, NULL, $factura['fid']);

                if(is_array($cuotas) || is_object($cuotas)){

                    $socio = new Socio($cuotas[0]['sid']);

                    // Genero el objeto jugador apartir del SID
                    $jugador = Jugador::ObtenerPorSid($socio->GetId());

                    // Genero el objeto equipo apartir del EID
                    $equipo = Equipo::ObtenerPorId($jugador->GetEquipo());

                    // Genero el objeto usuario apartir del objeto socio
                    $usuario = User::ObtenerPorId($socio->GetUid());

                    $facturas[$i]['remitente'] = $usuario->GetApellido()." ".$usuario->GetNombre()." (".$equipo->GetNombre().") - Cuota";

                }else if(is_array($multasJugador) || is_object($multasJugador)){

                    $jugador = new Jugador($multasJugador[0]['jugador']);

                    $socio = new Socio($jugador->GetSid());

                    // Genero el objeto equipo apartir del EID
                    $equipo = Equipo::ObtenerPorId($jugador->GetEquipo());

                    // Genero el objeto usuario apartir del objeto socio
                    $usuario = User::ObtenerPorId($socio->GetUid());

                    $facturas[$i]['remitente'] = $usuario->GetApellido()." ".$usuario->GetNombre()." (".$equipo->GetNombre().") - Multa";

                }else if(is_array($multasEquipo) || is_object($multasEquipo)){

                    $equipo = Equipo::ObtenerPorId($multasEquipo[0]['equipo']);

                    $categoria = Categoria::ObtenerPorCid($equipo->GetCategoria());
                    $facturas[$i]['remitente'] = $equipo->GetNombre()." (".$categoria->GetNombre().") - Multa";

                }else if(is_array($deduasSocio) || is_object($deduasSocio)){

                    $socio = new Socio($deduasSocio[0]['sid']);

                    // Genero el objeto jugador apartir del SID
                    $jugador = Jugador::ObtenerPorSid($socio->GetId());

                    // Genero el objeto equipo apartir del EID
                    $equipo = Equipo::ObtenerPorId($jugador->GetEquipo());

                    // Genero el objeto usuario apartir del objeto socio
                    $usuario = User::ObtenerPorId($socio->GetUid());

                    $facturas[$i]['remitente'] = $usuario->GetApellido()." ".$usuario->GetNombre()." (".$equipo->GetNombre().") - Deuda";

                }else if(is_array($deudasEquipo) || is_object($deudasEquipo)){

                    $equipo = Equipo::ObtenerPorId($deudasEquipo[0]['eid']);

                    $categoria = Categoria::ObtenerPorCid($equipo->GetCategoria());
                    $facturas[$i]['remitente'] = $equipo->GetNombre()." (".$categoria->GetNombre().") - Deuda";

                }
            }

        }
    }
    require_once("views/facturacion.phtml");

}

//Funcion Ver
function ver ($fid) {

    require_once("views/facturacion_ver.phtml");

}

//Funcion listar detalles de la factura
function ListarDetalles ($dato) {
    $detalles = Detalle::ListarDetalles($dato);

    echo json_encode($detalles);
}

//Funcion listar cobros de la factura
function ListarCobros ($dato) {
    $cobros = Cobro::ListarCobros(0, $dato);

    echo json_encode($cobros);
}

//Funcion Ingresar cobro
function IngresarCobro ($dato) {
    $fid = $_POST['fid'];
    $monto = $_POST['monto'];
    $forma = $_POST['forma'];
    $comentario = $_POST['comentario'];

    $cobro = new Cobro(0, $fid, $monto, $divisa, $forma, date('Y-n-j'), $comentario, $_SESSION['api_id']['uid']);

    $resultado = $cobro->registro();

    if(is_numeric($resultado)){

        EnviarAlerta('success', 'Se registro el cobro');
        $action = "Ingreso cobro $".$monto." forma ".$forma." Comprobante:".$fid;
        $log = array("user" => $_SESSION['api_id']['uid'], "action" => $action);
        Loggin::register(json_encode($log));

    }else{

        EnviarAlerta('error', 'No se pudo registrar el cobro: '.$resultado);

    }
}

//Funcion Eliminar Cobro
function EliminarCobro ($dato) {
    $cobro = new Cobro($dato);

    $resultado = $cobro->eliminar();
    if(is_numeric($resultado)){

        EnviarAlerta('success', 'Se elimino el cobro');
        $action = "Elimino cobro ID:".$cobro->GetCbid()." $".$cobro->GetMonto()." forma ".$cobro->GetForma()." Comprobante:".$cobro->GetFid()." Cobrador: ".$cobro->GetCobrador();
        $log = array("user" => $_SESSION['api_id']['uid'], "action" => $action);
        Loggin::register(json_encode($log));
    }else{

        EnviarAlerta('error', 'No se pudo eliminar el cobro: '.$resultado);

    }
}

//Funcion de consulta de la factura
function ConsultaFactura ($dato) {

    // Genero El objeto factura apartir de $dato (FID)
    $factura = Facturacion::buscarPorId($dato);

    // Genero objeto equipo vacio
    $equipo = new Equipo(0);

    if($factura->GetTipo() == Facturacion::TIPO_FACTURA_A){

        $cotribucion = $equipo->ListarContribucionDeportiva(0, 0, NULL, $dato);
        $equipo = Equipo::ObtenerPorId($cotribucion[0]['eid']);
        $categoria = Categoria::ObtenerPorCid($equipo->GetCategoria());
        $remitente = $equipo->GetNombre()." (".$categoria->GetNombre().") - Cuota Unica";

    } else {
        // Genero objeto socio vacio
        $socio = new Socio(0);
        // Genero objeto jugador vacio
        $jugador = new Jugador(0);

        // Obtengo lista de cuotas SI ES QUE EXISTEN
        $cuotas = $socio->Cuota(0, $dato);

        // Obtengo lista de multas jugador SI ES QUE EXISTEN
        $multasJugador = $jugador->Multas($dato);

        // Obtengo lista de multas equipo SI ES QUE EXISTEN
        $multasEquipo = $equipo->Multas($dato);

        // Obtengo lista de deduas socios SI ES QUE EXISTEN
        $deduasSocio = Deuda::ListarDeudasSocio(0,  0, 0, NULL, $dato);

        // Obtengo lista de deduas equipos SI ES QUE EXISTEN
        $deudasEquipo = Deuda::ListarDeudasEquipo(0,  0, 0, NULL, $dato);

        if(is_array($cuotas) || is_object($cuotas)){

            $socio = new Socio($cuotas[0]['sid']);

            // Genero el objeto usuario apartir del objeto socio
            $usuario = User::ObtenerPorId($socio->GetUid());

            $remitente = $usuario->GetNombre()." ".$usuario->GetApellido()." - Cuota";

        }else if(is_array($multasJugador) || is_object($multasJugador)){

            $jugador = new Jugador($multasJugador[0]['jugador']);

            $socio = new Socio($jugador->GetSid());

            // Genero el objeto usuario apartir del objeto socio
            $usuario = User::ObtenerPorId($socio->GetUid());

            $remitente = $usuario->GetNombre()." ".$usuario->GetApellido()." - Multa";

        }else if(is_array($multasEquipo) || is_object($multasEquipo)){

            $equipo = Equipo::ObtenerPorId($multasEquipo[0]['equipo']);

            $categoria = Categoria::ObtenerPorCid($equipo->GetCategoria());
            $remitente = $equipo->GetNombre()." (".$categoria->GetNombre().") - Multa";

        }else if(is_array($deduasSocio) || is_object($deduasSocio)){

            $socio = new Socio($deduasSocio[0]['sid']);

            // Genero el objeto jugador apartir del SID
            $jugador = Jugador::ObtenerPorSid($socio->GetId());

            // Genero el objeto equipo apartir del EID
            $equipo = Equipo::ObtenerPorId($jugador->GetEquipo());

            // Genero el objeto usuario apartir del objeto socio
            $usuario = User::ObtenerPorId($socio->GetUid());

            $remitente = $usuario->GetApellido()." ".$usuario->GetNombre()." (".$equipo->GetNombre().") - Deuda";

        }else if(is_array($deudasEquipo) || is_object($deudasEquipo)){

            $equipo = Equipo::ObtenerPorId($deudasEquipo[0]['eid']);

            $categoria = Categoria::ObtenerPorCid($equipo->GetCategoria());
            $remitente = $equipo->GetNombre()." (".$categoria->GetNombre().") - Deuda";

        }

    }

    $json = array("fid" => $factura->GetId(),
    "tipo" => $factura->GetTipo(),
    "fEmision" => $factura->GetfEmision(),
    "estado" => $factura->GetEstado(),
    "remitente" => $remitente);

    echo json_encode($json);
}

/*** Lote factura unica ***/
function LoteFacturaUnica ($dato) {

    global $user;

    //echo $_POST['equipo'];

    // Convierto la cadena JSON a OBJ
    //$obj = json_decode($dato);

    // Convierto el OBJ a Array
    //$datos = get_object_vars($obj[0]);

    // Obtengo las contribuciones deportivas que quiero facturar
    //$contribucionesDeportivas = $datos['contribuciones'];
    $contribucionesDeportivas = explode(",",$_POST['contribuciones']);

    // Obtengo el ID del equipo
    //$eid = $datos['equipo'];
    //$eid = $_POST['equipo'];

    // Obtengo el parametro del valor de la cuota social
    $CuotaMonto = $user->GetParametro(100);

    // Obtengo el parametro del valor de la contribucion deportiva
    $ContribucionDeportivaMonto = $user->GetParametro(101);

    // Inicializo un contador para las contribuciones seleccionadas
    $j = 0;

    for($i = 0; $i < count($contribucionesDeportivas); $i++) {

        $jugadorResultado = array();

        $cuotaUnica = explode(";",$contribucionesDeportivas[$i]);

        if($cuotaUnica[1] > 0){

            $fact = new Facturacion(null, Facturacion::TIPO_FACTURA_A, date("Y-n-j"), Facturacion::ESTADO_IMPAGA);
            $codigo = $fact->registro();

            // Genero objeto facturacion apartir del FID
            $facturacion = new Facturacion($codigo);

            // Genero objeto detalle de factura apartir del FID
            $detalles = new Detalle($codigo);

            $eid = $cuotaUnica[0];//$contribucionesDeportivas[$i];

            // Genero el objeto equipo apartir del ID
            $equipo = Equipo::ObtenerPorId($eid);

            $jugadores = [];

            // Listo los jugadores del equipo en un Array
            $jugadores = Jugador::ListarJugadores(0, $eid);

            $contribucion = $equipo->ContribucionDeportiva($cuotaUnica[1]);

            //$equipo = new Equipo($eid);

            $equipo->ModificarContribucionDeportiva ($cuotaUnica[1], '', 0, '', '', 0, '', $codigo);

            $cuotaunica['monto'] = $ContribucionDeportivaMonto['valor'];

            $totalCuotas = 0;
            $total = 0;

            $u = 0;

            // Listo ID Socio de cada jugador del equipo para posteriormente
            // Obtener su primera cuota impaga
            if(is_array($jugadores) || is_object($jugadores)) {
                foreach($jugadores as $index => $jugador){

                    if($jugador['activo'] == Socio::ESTADO_ACTIVO){

                        // Genero OBJ Socio con ID socio
                        $socio = new Socio($jugador['sid']);

                        // Obtengo el mes de emision de la contribucion deportiva seleccionada
                        $month = date("m",strtotime($contribucion['fEmision']));
                        $date = date("Y-n-j",strtotime($contribucion['fEmision']));
                        /*$fecha = explode("-", $contribucion['fEmision']);
                        $month = $fecha[1];
                        $month = $contribucion[$j]['fEmision'];*/

                        // Listo la cuota impaga del mismo mes que la contribucion deportiva
                        $cuotaSocial = $socio->ListarCuotasImpagas(0, 0, $date);

                        if(is_array($cuotaSocial) || is_object($cuotaSocial)) {
                            foreach($cuotaSocial as $cuota) {
                                $cuotaFecha = $cuota['fEmision'];
                                $socio->EditarCuota ($cuota['cid'], NULL, NULL, NULL, $CuotaMonto['valor'], NULL, $codigo);
                            }
                            $fecha = explode("-", $cuotaFecha);

                            if(!empty($fecha)){
                                $detalle = $jugador['apellido']." ".$jugador['nombre']." - Fecha de cuota: ".$fecha[2]."/".$fecha[1]."/".$fecha[0];

                                $detalles->registro(null, $detalle, $CuotaMonto['valor']);

                                $totalCuotas += $CuotaMonto['valor'];
                            }
                        }

                        // Genero Array con los datos de los jugadores del equipo:
                        // - Nombre del jugador
                        // - Apellido del jugadores
                        // - Fecha de la cuota a pagar
                        // - Monto de la cuota a pagar
                        $jugadorResultado[$u] = array("detalle" => $detalle,
                        "cuotaFecha" => $cuotaFecha,
                        "cuotaMonto" => $CuotaMonto['valor']);

                        $u++;
                    }
                }
            }

            $total = $cuotaunica['monto'] - $totalCuotas;

            $detalles->registro(null, "Contribución deportiva", $total);

            // Guardo en el Array datos del equipo
            // Guardo en el Array las contribuciones seleccionadas (1)
            // Guardo en el Array los jugadores del equipo
            $factura[$j] = array("codigo" => $codigo,
            "equipo" => array("nombre" => $equipo->GetNombre(),
            "categoria" => $equipo->GetCategoria()),
            "contribucion" => array('monto' => $total,
            "fEmision" => $contribucion['fEmision'],
            "fVencimiento" => $contribucion['fVencimiento']),
            "total" => $cuotaunica['monto'],
            "jugadores"  => $jugadorResultado);

            $j++;

        }

    }

    //echo var_dump($factura);
    //echo $month;

    //$boleta = new Boleta (json_encode($factura));

    //$boleta->FacturaUnica ();

    //echo json_encode($factura);

    $boleta = new Boleta ($factura);

    $boleta->FacturaUnica ();

    $action = "Genero Comprobante unica ID: ";
    $log = array("user" => $_SESSION['api_id']['uid'], "action" => $action);
    Loggin::register(json_encode($log));

}

/*** Funcion factura unica ***/
function FacturaUnica ($dato) {
    global $user;
    //echo $_POST['equipo'];
    // Convierto la cadena JSON a OBJ
    //$obj = json_decode($dato);
    // Convierto el OBJ a Array
    //$datos = get_object_vars($obj[0]);
    // Obtengo codigo de la facturar
    $codigo = $_POST['factura'];
    // Obtengo las contribuciones deportivas que quiero facturar
    //$contribucionesDeportivas = $datos['contribuciones'];
    $contribucionesDeportivas = explode(",",$_POST['contribuciones']);
    // Obtengo el ID del equipo
    //$eid = $datos['equipo'];
    $eid = $_POST['equipo'];
    // Genero el objeto equipo apartir del ID
    $equipo = Equipo::ObtenerPorId($eid);
    // Listo los jugadores del equipo en un Array
    $jugadores = Jugador::ListarJugadores(0, $eid);
    // Obtengo el parametro del valor de la cuota social
    $CuotaMonto = $user->GetParametro(100);
    // Obtengo el parametro del valor de la contribucion deportiva
    $ContribucionDeportivaMonto = $user->GetParametro(101);
    // Inicializo un contador para las contribuciones seleccionadas
    $j = 0;
    // Genero objeto facturacion apartir del FID
    $facturacion = new Facturacion($codigo);
    // Genero objeto detalle de factura apartir del FID
    $detalles = new Detalle($codigo);
    for($i = 0; $i < count($contribucionesDeportivas); $i++) {
        if($contribucionesDeportivas[$i] == 1){
            $contribucion = $equipo->ContribucionDeportiva($i);
            $cuotaunica['monto'] = $ContribucionDeportivaMonto['valor'];
            $totalCuotas = 0;
            $total = 0;
            $u = 0;
            // Listo ID Socio de cada jugador del equipo para posteriormente
            // Obtener su primera cuota impaga
            if(is_array($jugadores) || is_object($jugadores)) {
                foreach($jugadores as $index => $jugador){
                    if($jugador['activo'] == Socio::ESTADO_ACTIVO){
                        // Genero OBJ Socio con ID socio
                        $socio = new Socio($jugador['sid']);
                        // Obtengo el mes de emision de la contribucion deportiva seleccionada
                        $month = date("m",strtotime($contribucion['fEmision']));
                        $date = date("Y-n-j",strtotime($contribucion['fEmision']));
                        /*$fecha = explode("-", $contribucion['fEmision']);
                        $month = $fecha[1];
                        $month = $contribucion[$j]['fEmision'];*/
                        // Listo la cuota impaga del mismo mes que la contribucion deportiva
                        $cuotaSocial = $socio->ListarCuotasImpagas(0, 0, $date);
                        if(is_array($cuotaSocial) || is_object($cuotaSocial)) {
                            foreach($cuotaSocial as $cuota) {
                                $cuotaFecha = $cuota['fEmision'];
                                $socio->EditarCuota ($cuota['cid'], NULL, NULL, NULL, $CuotaMonto['valor'], NULL, $codigo);
                            }
                            $fecha = explode("-", $cuotaFecha);
                            if(!empty($fecha)){
                                $detalle = $jugador['apellido']." ".$jugador['nombre']." - Fecha de cuota: ".$fecha[2]."/".$fecha[1]."/".$fecha[0];
                                $detalles->registro(null, $detalle, $CuotaMonto['valor']);
                                $totalCuotas += $CuotaMonto['valor'];
                            }
                        }
                        // Genero Array con los datos de los jugadores del equipo:
                        // - Nombre del jugador
                        // - Apellido del jugadores
                        // - Fecha de la cuota a pagar
                        // - Monto de la cuota a pagar
                        $jugadorResultado[$u] = array("detalle" => $detalle,
                        "cuotaFecha" => $cuotaFecha,
                        "cuotaMonto" => $CuotaMonto['valor']);
                        $u++;
                    }
                }
            }
            $total = $cuotaunica['monto'] - $totalCuotas;
            $detalles->registro(null, "Contribución deportiva", $total);
            // Guardo en el Array datos del equipo
            // Guardo en el Array las contribuciones seleccionadas (1)
            // Guardo en el Array los jugadores del equipo
            $factura[$j] = array("codigo" => $codigo,
            "equipo" => array("nombre" => $equipo->GetNombre(),
            "categoria" => $equipo->GetCategoria()),
            "contribucion" => array('monto' => $total,
            "fEmision" => $contribucion['fEmision'],
            "fVencimiento" => $contribucion['fVencimiento']),
            "total" => $cuotaunica['monto'],
            "jugadores"  => $jugadorResultado);
            $j++;
        }
    }
    //echo var_dump($factura);
    //echo $month;
    //$boleta = new Boleta (json_encode($factura));
    //$boleta->FacturaUnica ();
    //echo json_encode($factura);
    $boleta = new Boleta ($factura);
    $boleta->FacturaUnica ();
    $action = "Genero Comprobante unica ID: ".$codigo;
    $log = array("user" => $_SESSION['api_id']['uid'], "action" => $action);
    Loggin::register(json_encode($log));
}

/*** Funcion factura multa equipo ***/
function FacturaIndividualMultaEquipo ($dato) {

    global $user;

    //echo $_POST['equipo'];

    // Convierto la cadena JSON a OBJ
    //$obj = json_decode($dato);

    // Convierto el OBJ a Array
    //$datos = get_object_vars($obj[0]);

    // Obtengo codigo de la facturar
    $codigo = $_POST['factura'];

    // Obtengo las multas que quiero facturar
    $multas = explode(",", $_POST['multas']);

    // Obtengo el ID del equipo
    //$eid = $datos['equipo'];
    $eid = $_POST['equipo'];

    // Genero el objeto equipo apartir del ID
    $equipo = Equipo::ObtenerPorId($eid);

    // Inicializo un contador para las contribuciones seleccionadas
    $j = 0;

    //Listo tipos Multas
    $tiposMultas = Multa::ListarTiposMultas();

    // Genero objeto facturacion apartir del FID
    $facturacion = new Facturacion($codigo);

    // Genero objeto detalle de factura apartir del FID
    $detalles = new Detalle($codigo);

    for($i = 0; $i < count($multas); $i++) {

        if($multas[$i] == 1){

            $multa = $equipo->Multa($i);

            // Guardo en el Array datos del equipo
            // Guardo en el Array las multas seleccionadas (1)
            if(is_array($tiposMultas) || is_object($tiposMultas)){
                foreach($tiposMultas as $tipo){
                    if($tipo['tmid'] == $multa['tmid']){
                        $multa['descripcion'] = "Multa: ".$tipo['descripcion']." $".$tipo['precio'];
                        $multa['precio'] = $tipo['precio'];
                        $multasEquipo[$j] = $multa;

                        try {
                            $detalles->registro(null, $multa['descripcion'], $tipo['precio']);
                        } catch (Exception $e) {
                            echo $e;
                            return false;
                        }

                        try {
                            $equipo->EditarMulta ($i, NULL, NULL, NULL, NULL, (float) $tipo['precio'], NULL, (int) $codigo);
                        } catch (Exception $e) {
                            echo $e;
                            return false;
                        }
                    }
                }
            }

            $j++;

        }

    }

    $factura = array("codigo" => $codigo,
    "remitente" => "equipo",
    "equipo" => array("nombre" => $equipo->GetNombre(),
    "categoria" => $equipo->GetCategoria()),
    "multas" => $multasEquipo);

    //echo var_dump($factura);
    //echo $month;

    //$boleta = new Boleta (json_encode($factura));

    //$boleta->FacturaUnica ();

    //echo json_encode($factura);

    $boleta = new Boleta ($factura);

    $boleta->FacturaIndividualMulta ();

    $action = "Genero Comprobante Multa equipo ID: ".$codigo;
    $log = array("user" => $_SESSION['api_id']['uid'], "action" => $action);
    Loggin::register(json_encode($log));

}

/*** Funcion factura multa jugador ***/
function FacturaMultaJugador ($dato) {

    global $user;

    //echo $_POST['equipo'];

    // Convierto la cadena JSON a OBJ
    //$obj = json_decode($dato);

    // Convierto el OBJ a Array
    //$datos = get_object_vars($obj[0]);

    // Obtengo codigo de la facturar
    $codigo = $_POST['factura'];

    // Obtengo las multas que quiero facturar
    $multas = explode(",", $_POST['multas']);

    // Obtengo el ID del socio
    $sid = $_POST['socio'];

    // Genero el objeto socio apartir del SID
    $socio =  new Socio($sid);

    // Genero el objeto usuario apartir del objeto socio
    $usuario = User::ObtenerPorId($socio->GetUid());

    // Genero el objeto jugador apartir del SID
    $jugador = Jugador::ObtenerPorSid($sid);

    // Genero el objeto equipo apartir del EID
    $equipo = Equipo::ObtenerPorId($jugador->GetEquipo());

    // Inicializo un contador para las contribuciones seleccionadas
    $j = 0;

    // Genero objeto facturacion apartir del FID
    $facturacion = new Facturacion($codigo);

    // Genero objeto detalle de factura apartir del FID
    $detalles = new Detalle($codigo);

    //Listo tipos Multas
    $tiposMultas = Multa::ListarTiposMultas();

    for($i = 0; $i < count($multas); $i++) {

        if($multas[$i] == 1){

            $multa = $jugador->Multa($i);

            // Guardo en el Array datos del jugador
            // Guardo en el Array las multas seleccionadas (1)
            if(is_array($tiposMultas) || is_object($tiposMultas)){
                foreach($tiposMultas as $tipo){
                    if($tipo['tmid'] == $multa['tmid']){
                        $multa['descripcion'] = "Multa: ".$tipo['descripcion']." $".$tipo['precio'];
                        $multa['precio'] = $tipo['precio'];
                        $multasJugador[$j] = $multa;
                        
                        try {
                            $detalles->registro(null, $multa['descripcion'], $tipo['precio']);
                        } catch (Exception $e) {
                            echo $e;
                            return false;
                        }

                        try {
                            $jugador->EditarMulta ($i, NULL, NULL, NULL, NULL, (float) $tipo['precio'], NULL, (int) $codigo);
                        } catch (Exception $e) {
                            echo $e;
                            return false;
                        }

                    }
                }
            }

            $j++;

        }

    }

    $factura = array("codigo" => $codigo,
    "remitente" => "jugador",
    "jugador" => array("id" => $socio->GetId(),
    "nombre" => $usuario->GetNombre(),
    "apellido" => $usuario->GetApellido()),
    "equipo" => array("nombre" => $equipo->GetNombre()),
    "multas" => $multasJugador);

    //echo var_dump($factura);
    //echo $month;

    //$boleta = new Boleta (json_encode($factura));

    //$boleta->FacturaUnica ();

    //echo json_encode($factura);

    //var_dump($factura);

    $boleta = new Boleta ($factura);

    $boleta->FacturaIndividualMulta ();

    $action = "Genero Comprobante Multa Jugador ID: ".$codigo;
    $log = array("user" => $_SESSION['api_id']['uid'], "action" => $action);
    Loggin::register(json_encode($log));
}

/*** Funcion factura deuda socio ***/
function FacturaDeudaSocio ($dato) {

    global $user;

    $deudasSocio = [];

    // Obtengo codigo de la facturar
    $codigo = $_POST['factura'];

    // Obtengo las multas que quiero facturar
    $deudas = explode(",", $_POST['deudas']);

    // Obtengo el ID del socio
    $sid = $_POST['socio'];

    // Genero el objeto socio apartir del SID
    $socio =  new Socio($sid);

    // Genero el objeto usuario apartir del objeto socio
    $usuario = User::ObtenerPorId($socio->GetUid());

    // Genero el objeto jugador apartir del SID
    $jugador = Jugador::ObtenerPorSid($sid);

    // Genero el objeto equipo apartir del EID
    $equipo = Equipo::ObtenerPorId($jugador->GetEquipo());

    // Genero objeto facturacion apartir del FID
    $facturacion = new Facturacion($codigo);

    // Genero objeto detalle de factura apartir del FID
    $detalles = new Detalle($codigo);

    $j = 0;

    for($i = 0; $i < count($deudas); $i++) {

        if($deudas[$i] == 1){

            $deuda = Deuda::ObtenerPorDsidSocio($i);

            $deuda['descripcion'] = $deuda['concepto']." $".$deuda['importe'];
            $deuda['precio'] = $deuda['importe'];
            
            try {
                $detalles->registro(null, $deuda['concepto'], $deuda['importe']);
            } catch (Exception $e) {
                echo $e;
                return false;
            }

            try {
                $deudaObj = new Deuda($i);
                $deudaObj->modificarSocio(NULL, NULL, NULL, (float) $deuda['importe'], 0, NULL, (int) $codigo);
            } catch (Exception $e) {
                echo $e;
                return false;
            }

            $deudasSocio[$j] = $deuda;
            $j++;
        }

    }

    $factura = array("codigo" => $codigo,
    "remitente" => "socio",
    "socio" => array("id" => $socio->GetId(),
    "nombre" => $usuario->GetNombre(),
    "apellido" => $usuario->GetApellido()),
    "equipo" => array("nombre" => $equipo->GetNombre()),
    "deudas" => $deudasSocio);

    $boleta = new Boleta ($factura);

    $boleta->FacturaIndividualDeuda ();


    $action = "Genero Comprobante Deuda Socio ID: ".$codigo;
    $log = array("user" => $_SESSION['api_id']['uid'], "action" => $action);
    Loggin::register(json_encode($log));

}

/*** Funcion factura deuda equipo ***/
function FacturaDeudaEquipo ($dato) {

    global $user;

    $deudasEquipo = [];

    // Obtengo codigo de la facturar
    $codigo = $_POST['factura'];

    // Obtengo las multas que quiero facturar
    $deudas = explode(",", $_POST['deudas']);

    // Obtengo el ID del socio
    $eid = $_POST['equipo'];

    // Genero el objeto socio apartir del SID
    $equipo = Equipo::ObtenerPorId($eid);

    // Genero objeto facturacion apartir del FID
    $facturacion = new Facturacion($codigo);

    // Genero objeto detalle de factura apartir del FID
    $detalles = new Detalle($codigo);

    $j = 0;

    for($i = 0; $i < count($deudas); $i++) {

        if($deudas[$i] == 1){

            $deuda = Deuda::ObtenerPorDsidEquipo($i);

            $deuda['descripcion'] = $deuda['concepto']." $".$deuda['importe'];
            $deuda['precio'] = $deuda['importe'];
            $detalles->registro(null, $deuda['concepto'], $deuda['importe']);
            $deudasSocio[$j] = $deuda;
            $j++;
        }

    }

    $factura = array("codigo" => $codigo,
    "remitente" => "equipo",
    "equipo" => array("nombre" => $equipo->GetNombre(),
    "categoria" => $equipo->GetCategoria()),
    "deudas" => $deudasSocio);

    $boleta = new Boleta ($factura);

    //var_dump($factura);

    $boleta->FacturaIndividualDeuda ();

    $action = "Genero Comprobante Deuda Equipo ID: ".$codigo;
    $log = array("user" => $_SESSION['api_id']['uid'], "action" => $action);
    Loggin::register(json_encode($log));
}

/*** Funcion factura cuotas socio ***/
function FacturaCuotaSocial ($dato) {

    global $user;

    //echo $_POST['equipo'];

    // Convierto la cadena JSON a OBJ
    //$obj = json_decode($dato);

    // Convierto el OBJ a Array
    //$datos = get_object_vars($obj[0]);

    // Obtengo codigo de la facturar
    $codigo = $_POST['factura'];

    // Obtengo las multas que quiero facturar
    $cuotas = explode(",", $_POST['cuotas']);

    // Obtengo el ID del socio
    $sid = $_POST['socio'];

    // Genero el objeto socio apartir del SID
    $socio =  new Socio($sid);

    // Genero el objeto usuario apartir del objeto socio
    $usuario = User::ObtenerPorId($socio->GetUid());

    // Obtengo el parametro del valor de la cuota social
    $CuotaMonto = $user->GetParametro(100);

    // Genero el objeto jugador apartir del SID
    $jugador = Jugador::ObtenerPorSid($sid);

    // Genero el objeto equipo apartir del EID
    $equipo = Equipo::ObtenerPorId($jugador->GetEquipo());

    // Inicializo un contador para las contribuciones seleccionadas
    $j = 0;

    // Genero objeto facturacion apartir del FID
    $facturacion = new Facturacion($codigo);

    // Genero objeto detalle de factura apartir del FID
    $detalles = new Detalle($codigo);

    for($i = 0; $i < count($cuotas); $i++) {

        if($cuotas[$i] == 1){

            $cuotaSocial = $socio->Cuota($i, 0);

            if(is_array($cuotaSocial) || is_object($cuotaSocial)) {
                foreach($cuotaSocial as $cuota) {

                    $fEmision = explode("-", $cuota['fEmision']);
                    $fVencimiento = explode("-", $cuota['fVencimiento']);

                    $cuotasSociales[$j]['detalle'] = "- Cuota: ".$fEmision[1]."/".$fEmision[0][2].$fEmision[0][3]." - Venc: ".$fVencimiento[2]."/".$fVencimiento[1]."/".$fVencimiento[0];
                    $cuotasSociales[$j]['monto'] = $CuotaMonto['valor'];

                    try {
                        $detalles->registro(null, $cuotasSociales[$j]['detalle'], $cuotasSociales[$j]['monto']);
                    } catch (Exception $e) {
                        echo $e;
                        return false;
                    }

                    try {
                        $socio->EditarCuota ($i, NULL, NULL, NULL, $cuotasSociales[$j]['monto'], NULL, $codigo);
                    } catch (Exception $e) {
                        echo $e;
                        return false;
                    }
                }
            }

            $j++;

        }

    }

    $cuotaDato = end($cuotaSocial);

    $factura = array("codigo" => $codigo,
    "remitente" => "socio",
    "fEmision" => FormatDate($cuotaDato['fEmision']),
    "socio" => array("id" => $socio->GetId(),
    "nombre" => $usuario->GetNombre(),
    "apellido" => $usuario->GetApellido()),
    "equipo" => array("nombre" => $equipo->GetNombre()),
    "cuotas" => $cuotasSociales);

    $boleta = new Boleta ($factura);

    $boleta->FacturaIndividualCuota ();

    $action = "Genero Comprobante Cuota Social ID: ".$codigo;
    $log = array("user" => $_SESSION['api_id']['uid'], "action" => $action);
    Loggin::register(json_encode($log));
}

//Funcion insertar factura
function InsertarRecibo () {

    $factura = new Facturacion(null, Facturacion::TIPO_RECIBO, date("Y-n-j"), Facturacion::ESTADO_IMPAGA);

    if($resultado = $factura->registro()) {
        echo $resultado;
    }
}

//Funcion insertar factura
function InsertarFactura () {

    $factura = new Facturacion(null, Facturacion::TIPO_FACTURA_A, date("Y-n-j"), Facturacion::ESTADO_IMPAGA);

    if($resultado = $factura->registro()) {
        echo $resultado;
    }
}

//Funcion Eliminar Factura
function EliminarFactura ($dato) {
    $factura = new Facturacion($dato);

    if($resultado = $factura->eliminar())
    {

        EnviarAlerta('success', 'Se elimino la factura correctamente: '.$resultado);
        $action = "Elimino comprobante ID: ".$dato;
        $log = array("user" => $_SESSION['api_id']['uid'], "action" => $action);
        Loggin::register(json_encode($log));

    }else{

        EnviarAlerta('success', 'No se pudo eliminar la factura: '.$resultado);
        //EnviarAlerta('error', 'No se pudo crear la cuota correctamente');

    }
}

//Funcion Pagar Factura
function PagarFactura ($dato)  {

    $factura = new Facturacion($dato);

    global $user;

    if($resultado = $factura->modificar(NULL, NULL, Facturacion::ESTADO_PAGADA))
    {

        $ContribucionDeportivaMonto = $user->GetParametro(101);

        $equipo= new Equipo();

        $equipo->PagarContribucionDeportiva(0, $ContribucionDeportivaMonto['valor'], $dato);

        $CuotaMonto = $user->GetParametro(100);

        $socio = new Socio();

        $socio->PagarCuota(0, $CuotaMonto['valor'], $dato);

        $deudas = Deuda::ObtenerPorFidSocio($dato);

        if(is_array($deudas)){
            foreach($deudas as $deuda){
                $obj = new Deuda($deuda['dsid']. $deuda['concepto'], $deuda['fEmision'], $deuda['fVencimiento'], $deuda['importe'], $deuda['sid']);
                $resultado = $obj->modificarSocio($concepto, $fEmision, $fVencimiento, $importe, $sid, Deuda::ESTADO_PAGADA, $fid);


                if($resultado){

                    EnviarAlerta('success', 'Se genero el pago correctamente: '.$resultado);

                    $action = "Efectuo pago comprobante deuda ID: ".$fid." Socio:".$deuda['sid'];
                    $log = array("user" => $_SESSION['api_id']['uid'], "action" => $action);
                    Loggin::register(json_encode($log));

                }else{

                    EnviarAlerta('error', 'No se pudo pagar: '.$resultado);

                }
            }
        }

        $deudas = Deuda::ObtenerPorFidEquipo($dato);

        if(is_array($deudas)){
            foreach($deudas as $deuda){
                $obj = new Deuda($deuda['dsid']. $deuda['concepto'], $deuda['fEmision'], $deuda['fVencimiento'], $deuda['importe'], $deuda['eid']);
                $resultado = $obj->modificarEquipo($concepto, $fEmision, $fVencimiento, $importe, $eid, Deuda::ESTADO_PAGADA, $fid);


                if($resultado){

                    EnviarAlerta('success', 'Se efectuo el pago correctamente: '.$resultado);
                    $action = "Efectuo pago comprobante deuda ID: ".$fid." Equipo:".$deuda['eid'];
                    $log = array("user" => $_SESSION['api_id']['uid'], "action" => $action);
                    Loggin::register(json_encode($log));

                }else{

                    EnviarAlerta('error', 'No se pudo pagar: '.$resultado);

                }
            }
        }

        EnviarAlerta('success', 'Se pago la factura correctamente: '.$resultado);
        $action = "Efectuo pago comprobante comprobante ID: ".$dato;
        $log = array("user" => $_SESSION['api_id']['uid'], "action" => $action);
        Loggin::register(json_encode($log));
    }else{

        EnviarAlerta('success', 'No se pudo pagar la factura: '.$resultado);
        //EnviarAlerta('error', 'No se pudo crear la cuota correctamente');

    }

}

//Funcion Cancelar Pago Factura
function CancelarPagoFactura ($dato)  {

    $factura = new Facturacion($dato);

    if($resultado = $factura->modificar(NULL, NULL, Facturacion::ESTADO_IMPAGA))
    {

        EnviarAlerta('success', 'Se cancelo la factura correctamente: '.$resultado);
        $action = "Cancelo pago comprobante comprobante ID: ".$dato;
        $log = array("user" => $_SESSION['api_id']['uid'], "action" => $action);
        Loggin::register(json_encode($log));
    }else{

        EnviarAlerta('success', 'No se pudo cancelar la factura: '.$resultado);
        //EnviarAlerta('error', 'No se pudo crear la cuota correctamente');

    }

}

//Funcion Pagar Parcial Factura
function PagarParcialFactura ($dato)  {

    $factura = new Facturacion($dato);

    if($resultado = $factura->modificar(NULL, NULL, Facturacion::ESTADO_ADELANTO))
    {

        EnviarAlerta('success', 'Se pago el adelanto de la factura correctamente: '.$resultado);

    }else{

        EnviarAlerta('success', 'No se pudo pagar la factura: '.$resultado);
        //EnviarAlerta('error', 'No se pudo crear la cuota correctamente');

    }

}

//Funcion Generar Factura Generica
function GenerarFactura ($dato) {

    global $user;

    // Obtengo codigo de la facturar
    $fid = $_POST['factura'];

    // Obtengo el tipo de factura
    $tipo = $_POST['tipo'];

    // Obtengo el parametro del valor de la cuota social
    $CuotaMonto = $user->GetParametro(100);

    // Obtengo el parametro del valor de la contribucion deportiva
    $ContribucionDeportivaMonto = $user->GetParametro(101);

    // Genero objeto equipo vacio
    $equipo = new Equipo(0);

    // Obtengo las contribuciones deportivas que quiero facturar SI ES QUE EXISTEN
    $contribucionesDeportivas = $equipo->ListarContribucionDeportiva(0, 0, NULL, $fid);

    //print_r($contribucionesDeportivas);

    $totalCuotas = 0;
    $total = 0;

    // Verifico si contiene dato y recorro el array para obtener datos del equipo
    if(is_array($contribucionesDeportivas) || is_object($contribucionesDeportivas)){
        foreach($contribucionesDeportivas as $contribucion){

            $cuotaunica['monto'] = ($contribucion['monto'] == 0) ? $ContribucionDeportivaMonto['valor'] : $contribucion['monto'];

            // Genero el objeto equipo apartir del ID
            $equipo = Equipo::ObtenerPorId($contribucion['eid']);

            // Listo los jugadores del equipo en un Array
            $jugadores = Jugador::ListarJugadores(0, $contribucion['eid']);

            // Listo ID Socio de cada jugador del equipo para posteriormente
            // Obtener su primera cuota impaga
            if(is_array($jugadores) || is_object($jugadores)) {
                foreach($jugadores as $index => $jugador){

                    // Genero OBJ Socio con ID socio
                    $socio = new Socio($jugador['sid']);

                    // Obtengo el mes de emision de la contribucion deportiva seleccionada
                    $month = date("m",strtotime($contribucion['fEmision']));

                    // Listo la cuota impaga del mismo mes que la contribucion deportiva
                    $cuotaSocial = $socio->ListarCuotasImpagas($month);

                    if(is_array($cuotaSocial) || is_object($cuotaSocial)) {
                        foreach($cuotaSocial as $cuota) {
                            $cuotaFecha = $cuota['fEmision'];
                        }
                    }else {
                        $cuotaSocial = $socio->ListarCuotasPagadas($month);
                        if(is_array($cuotaSocial) || is_object($cuotaSocial)) {
                            foreach($cuotaSocial as $cuota) {
                                $cuotaFecha = $cuota['fEmision'];
                                $estadoCuota = $cuota['estado'];
                                $montoCuota = $cuota['monto'];
                            }
                        }
                    }

                    $fecha = explode("-", $cuotaFecha);

                    if(!empty($fecha)){
                        $detalle = $jugador['apellido']." ".$jugador['nombre']." - Fecha de cuota: ".$fecha[2]."/".$fecha[1]."/".$fecha[0];
                        $detalle .= " ".strtoupper($estadoCuota);
                        $totalCuotas += ($montoCuota == 0) ? $CuotaMonto['valor'] : $montoCuota;
                    }

                    // Genero Array con los datos de los jugadores del equipo:
                    // - Nombre del jugador
                    // - Apellido del jugadores
                    // - Fecha de la cuota a pagar
                    // - Monto de la cuota a pagar
                    $jugadorResultado[$index] = array("detalle" => $detalle,
                    "cuotaFecha" => $cuotaFecha,
                    "cuotaMonto" => ($montoCuota == 0) ? $CuotaMonto['valor'] : $montoCuota);
                }
            }

            $total = $cuotaunica['monto'] - $totalCuotas;

            // Guardo en el Array datos del equipo
            // Guardo en el Array las contribuciones seleccionadas (1)
            // Guardo en el Array los jugadores del equipo
            $factura[0] = array("codigo" => $fid." ".strtoupper($contribucion['estado']),
            "equipo" => array("nombre" => $equipo->GetNombre(),
            "categoria" => $equipo->GetCategoria()),
            "contribucion" => array('monto' => $total,
            "fEmision" => $contribucion['fEmision'],
            "fVencimiento" => $contribucion['fVencimiento']),
            "total" => $cuotaunica['monto'],
            "jugadores"  => $jugadorResultado);
        }
    }

    $boleta = new Boleta ($factura);

    $boleta->FacturaUnica ();
}

//Funcion Generar Recibo Generica
function GenerarRecibo ($dato) {

    global $user;

    // Obtengo el codigo del cobro
    $cbid = $_POST['cbid'];

    // Obtengo codigo de la facturar
    $fid = $_POST['factura'];

    // Obtengo el tipo de factura
    $tipo = $_POST['tipo'];

    // Genero objeto socio vacio
    $socio = new Socio(0);

    // Genero objeto equipo vacio
    $equipo = new Equipo(0);

    // Genero objeto jugador vacio
    $jugador = new Jugador(0);

    // Obtengo el parametro del valor de la cuota social
    $CuotaMonto = $user->GetParametro(100);

    // Obtengo lista de cuotas SI ES QUE EXISTEN
    $cuotas = $socio->Cuota(0, $fid);

    // Obtengo lista de multas jugador SI ES QUE EXISTEN
    $multasJugador = $jugador->Multas($fid);

    // Obtengo lista de multas equipo SI ES QUE EXISTEN
    $multasEquipo = $equipo->Multas($fid);

    //Listo tipos Multas
    $tiposMultas = Multa::ListarTiposMultas();

    // Obtengo lista de deduas socios SI ES QUE EXISTEN
    $deudasSocio = Deuda::ListarDeudasSocio(0,  0, 0, NULL, $fid);

    // Obtengo lista de deduas socios SI ES QUE EXISTEN
    $deudasEquipo = Deuda::ListarDeudasEquipo(0,  0, 0, NULL, $fid);

    // genero objeto cobro
    $cobro = new Cobro($cbid);

    $totalMonto = 0;

    if(is_array($cuotas) || is_object($cuotas)){

        $j = 0;

        foreach($cuotas as $cuota){

            $socio = new Socio($cuota['sid']);

            // Genero el objeto usuario apartir del objeto socio
            $usuario = User::ObtenerPorId($socio->GetUid());

            // Genero el objeto jugador apartir del SID
            $jugador = Jugador::ObtenerPorSid($cuota['sid']);

            // Genero el objeto equipo apartir del EID
            $equipo = Equipo::ObtenerPorId($jugador->GetEquipo());

            $fEmision = explode("-", $cuota['fEmision']);
            $fVencimiento = explode("-", $cuota['fVencimiento']);

            $cuotasSociales[$j]['detalle'] = "- Cuota: ".$fEmision[1]."/".$fEmision[0][2].$fEmision[0][3]." - Venc: ".$fVencimiento[2]."/".$fVencimiento[1]."/".$fVencimiento[0];
            $cuotasSociales[$j]['monto'] = $CuotaMonto['valor'];

            $totalMonto += $CuotaMonto['valor'];

            $j++;

        }

        $factura = array("codigo" => $fid,
        "remitente" => "socio",
        "fEmision" => FormatDate($cuotas[0]['fEmision']),
        "socio" => array("id" => $socio->GetId(),
        "nombre" => $usuario->GetNombre(),
        "apellido" => $usuario->GetApellido()),
        "equipo" => array("nombre" => $equipo->GetNombre()),
        "cuotas" => $cuotasSociales);

        $recibo = array("factura" => $fid,
        "remitente" => "socio",
        "fEmision" => FormatDate($cuotas[0]['fEmision']),
        "socio" => array("id" => $socio->GetId(),
        "nombre" => $usuario->GetNombre(),
        "apellido" => $usuario->GetApellido()),
        "equipo" => array("nombre" => $equipo->GetNombre()),
        "deuda" => $totalMonto,
        "cobro" => array("cbid" => $cobro->GetCbid(),
        "monto" => $cobro->GetMonto(),
        "forma" => $cobro->GetForma(),
        "comentario" => $cobro->GetComentario(),
        "fPago" => $cobro->GetfPago()));

        if($cbid > 0){
            $boleta = new Boleta ($recibo);
            $boleta->FacturaCobro ();
        }else{
            $boleta = new Boleta ($factura);
            $boleta->FacturaIndividualCuota ();
        }
    }

    else if(is_array($multasJugador) ||is_object($multasJugador)){

        // Inicializo un contador
        $j = 0;

        $totalMonto = 0;

        foreach($multasJugador as $multa){

            // Genero el objeto jugador apartir del SID
            $jugador = new Jugador($multa['jugador']);

            $socio = new Socio($jugador->GetSid());

            // Genero el objeto usuario apartir del objeto socio
            $usuario = User::ObtenerPorId($socio->GetUid());

            // Genero el objeto equipo apartir del EID
            $equipo = Equipo::ObtenerPorId($jugador->GetEquipo());

            if(is_array($tiposMultas) || is_object($tiposMultas)){
                foreach($tiposMultas as $tipo){
                    if($tipo['tmid'] == $multa['tmid']){
                        $totalMonto += $tipo['precio'];
                        $multa['descripcion'] = "Multa: ".$tipo['descripcion']." $".$tipo['precio'];
                        $multas[$j] = $multa;
                    }
                }
            }

            $j++;

        }

        $factura = array("codigo" => $fid,
        "remitente" => "jugador",
        "jugador" => array("id" => $socio->GetId(),
        "nombre" => $usuario->GetNombre(),
        "apellido" => $usuario->GetApellido()),
        "equipo" => array("nombre" => $equipo->GetNombre()),
        "multas" => $multas);

        $recibo = array("factura" => $fid,
        "remitente" => "socio",
        "socio" => array("id" => $socio->GetId(),
        "nombre" => $usuario->GetNombre(),
        "apellido" => $usuario->GetApellido()),
        "equipo" => array("nombre" => $equipo->GetNombre()),
        "deuda" => $totalMonto,
        "cobro" => array("cbid" => $cobro->GetCbid(),
        "monto" => $cobro->GetMonto(),
        "forma" => $cobro->GetForma(),
        "comentario" => $cobro->GetComentario(),
        "fPago" => $cobro->GetfPago()));

        if($cbid > 0){
            $boleta = new Boleta ($recibo);
            $boleta->FacturaCobro ();
        }else{
            $boleta = new Boleta ($factura);
            $boleta->FacturaIndividualMulta ();
        }
    }

    else if(is_array($multasEquipo) || is_object($multasEquipo)){

        // Inicializo un contador
        $j = 0;

        $totalMonto = 0;

        foreach($multasEquipo as $multa){

            $equipo = Equipo::ObtenerPorId($multa['equipo']);


            // Guardo en el Array datos del equipo
            // Guardo en el Array las multas seleccionadas (1)

            if(is_array($tiposMultas) || is_object($tiposMultas)){
                foreach($tiposMultas as $tipo){
                    if($tipo['tmid'] == $multa['tmid']){
                        $totalMonto += $tipo['precio'];
                        $multa['descripcion'] = "Multa: ".$tipo['descripcion']." $".$tipo['precio'];
                        $multasEquipo[$j] = $multa;
                        $totalMonto += $precio['precio'];
                    }
                }
            }

            $j++;

        }

        $recibo = array("factura" => $fid,
        "remitente" => "equipo",
        "equipo" => array("nombre" => $equipo->GetNombre()),
        "deuda" => $totalMonto,
        "cobro" => array("cbid" => $cobro->GetCbid(),
        "monto" => $cobro->GetMonto(),
        "forma" => $cobro->GetForma(),
        "comentario" => $cobro->GetComentario(),
        "fPago" => $cobro->GetfPago()));


        $factura = array("codigo" => $fid,
        "remitente" => "equipo",
        "equipo" => array("nombre" => $equipo->GetNombre(),
        "categoria" => $equipo->GetCategoria()),
        "multas" => $multasEquipo);


        if($cbid > 0){
            $boleta = new Boleta ($recibo);
            $boleta->FacturaCobro ();
        }else{
            $boleta = new Boleta ($factura);
            $boleta->FacturaIndividualMulta ();
        }
    }else if(is_array($deudasSocio) || is_object($deudasSocio)){

        $socio = new Socio($deudasSocio[0]['sid']);

        // Genero el objeto jugador apartir del SID
        $jugador = Jugador::ObtenerPorSid($socio->GetId());

        // Genero el objeto equipo apartir del EID
        $equipo = Equipo::ObtenerPorId($jugador->GetEquipo());

        // Genero el objeto usuario apartir del objeto socio
        $usuario = User::ObtenerPorId($socio->GetUid());

        foreach($deudasSocio as $i => $deuda){
            $deudasSocio[$i]['descripcion'] = $deuda['concepto']." $".$deuda['importe'];
            $deudasSocio[$i]['precio'] = $deuda['importe'];
        }

        $factura = array("codigo" => $fid,
        "remitente" => "socio",
        "socio" => array("id" => $socio->GetId(),
        "nombre" => $usuario->GetNombre(),
        "apellido" => $usuario->GetApellido()),
        "equipo" => array("nombre" => $equipo->GetNombre()),
        "deudas" => $deudasSocio);

        $boleta = new Boleta ($factura);

        $boleta->FacturaIndividualDeuda ();

    }else if(is_array($deudasEquipo) || is_object($deudasEquipo)){

        $equipo = Equipo::ObtenerPorId($deudasEquipo[0]['eid']);

        foreach($deudasEquipo as $i => $deuda){
            $deudasEquipo[$i]['descripcion'] = $deuda['concepto']." $".$deuda['importe'];
            $deudasEquipo[$i]['precio'] = $deuda['importe'];
        }

        $factura = array("codigo" => $fid,
        "remitente" => "equipo",
        "equipo" => array("nombre" => $equipo->GetNombre(),
        "categoria" => $equipo->GetCategoria()),
        "deudas" => $deudasEquipo);

        $boleta = new Boleta ($factura);

        $boleta->FacturaIndividualDeuda ();

    } else {

        if($cbid > 0){

            // Obtengo el parametro del valor de la contribucion deportiva
            $ContribucionDeportivaMonto = $user->GetParametro(101);

            // Obtengo las contribuciones deportivas que quiero facturar SI ES QUE EXISTEN
            $contribucionesDeportivas = $equipo->ListarContribucionDeportiva(0, NULL, $fid);

            // Verifico si contiene dato y recorro el array para obtener datos del equipo
            if(is_array($contribucionesDeportivas) || is_object($contribucionesDeportivas)){
                foreach($contribucionesDeportivas as $contribucion){

                    // Genero el objeto equipo apartir del ID
                    $equipo = Equipo::ObtenerPorId($contribucion['eid']);



                }
            }

            $recibo = array("factura" => $fid,
            "remitente" => "equipo",
            "equipo" => array("nombre" => $equipo->GetNombre()),
            "deuda" => $ContribucionDeportivaMonto['monto'],
            "cobro" => array("cbid" => $cobro->GetCbid(),
            "monto" => $cobro->GetMonto(),
            "forma" => $cobro->GetForma(),
            "comentario" => $cobro->GetComentario(),
            "fPago" => $cobro->GetfPago()));

            $boleta = new Boleta ($recibo);
            $boleta->FacturaCobro ();
        }
    }

}

//Funcion Editar Deuda SOCIO
function EditarDeudaSocio () {

    $dsid = $_POST['dsid'];
    $concepto = $_POST['concepto'];
    $fEmision = $_POST['fEmision'];
    $fVencimiento = $_POST['fVencimiento'];
    $importe = $_POST['importe'];
    $sid = $_POST['sid'];
    $estado = $_POST['estado'];
    $fid = $_POST['fid'];

    $deuda = new Deuda($dsid);

    $resultado = $deuda->modificarSocio($concepto, $fEmision, $fVencimiento, $importe, $sid, $estado, $fid);

    if($resultado){

        EnviarAlerta('success', 'Se edito correctamente: '.$resultado);

    }else{

        EnviarAlerta('error', 'No se pudo editar: '.$resultado);

    }
}

//Funcion Editar Deuda EQUIPO
function EditarDeudaEquipo () {

    $dsid = $_POST['dsid'];
    $concepto = $_POST['concepto'];
    $fEmision = $_POST['fEmision'];
    $fVencimiento = $_POST['fVencimiento'];
    $importe = $_POST['importe'];
    $eid = $_POST['eid'];
    $estado = $_POST['estado'];
    $fid = $_POST['fid'];

    $deuda = new Deuda($dsid);

    $resultado = $deuda->modificarEquipo($concepto, $fEmision, $fVencimiento, $importe, $eid, $estado, $fid);

    if($resultado){

        EnviarAlerta('success', 'Se edito correctamente: '.$resultado);

    }else{

        EnviarAlerta('error', 'No se pudo editar: '.$resultado);

    }
}

//Funcion Pagar Deuda socio por Fid
function PagarDeudaSocio () {

    $fid = $_POST['fid'];

    $deudas = Deuda::ObtenerPorFidSocio($fid);

    if(is_array($deudas)){
        foreach($deudas as $deuda){
            $obj = new Deuda($deuda['dsid']. $deuda['concepto'], $deuda['fEmision'], $deuda['fVencimiento'], $deuda['importe'], $deuda['sid']);
            $resultado = $obj->modificarSocio($concepto, $fEmision, $fVencimiento, $importe, $sid, Deuda::ESTADO_PAGADA, $fid);


            if($resultado){

                EnviarAlerta('success', 'Se genero el pago correctamente: '.$resultado);

                $action = "Efectuo pago comprobante deuda ID: ".$fid." Socio:".$deuda['sid'];
                $log = array("user" => $_SESSION['api_id']['uid'], "action" => $action);
                Loggin::register(json_encode($log));

            }else{

                EnviarAlerta('error', 'No se pudo pagar: '.$resultado);

            }
        }
    }

}

//Funcion Cancelar Pago Deuda socio por Fid
function CancelarPagoDeudaSocio () {

    $fid = $_POST['fid'];

    $deudas = Deuda::ObtenerPorFidSocio($fid);

    if(is_array($deudas)){
        foreach($deudas as $deuda){
            $obj = new Deuda($deuda['dsid']. $deuda['concepto'], $deuda['fEmision'], $deuda['fVencimiento'], $deuda['importe'], $deuda['sid']);
            $resultado = $obj->modificarSocio($concepto, $fEmision, $fVencimiento, $importe, $sid, Deuda::ESTADO_IMPAGA, $fid);


            if($resultado){

                EnviarAlerta('success', 'Se cancelo el pago correctamente: '.$resultado);

            }else{

                EnviarAlerta('error', 'No se pudo pagar: '.$resultado);

            }
        }
    }
}

//Funcion Pagar Deuda equipo por Fid
function PagarDeudaEquipo () {

    $fid = $_POST['fid'];

    $deudas = Deuda::ObtenerPorFidEquipo($fid);

    if(is_array($deudas)){
        foreach($deudas as $deuda){
            $obj = new Deuda($deuda['dsid']. $deuda['concepto'], $deuda['fEmision'], $deuda['fVencimiento'], $deuda['importe'], $deuda['eid']);
            $resultado = $obj->modificarEquipo($concepto, $fEmision, $fVencimiento, $importe, $eid, Deuda::ESTADO_PAGADA, $fid);


            if($resultado){

                EnviarAlerta('success', 'Se efectuo el pago correctamente: '.$resultado);
                $action = "Efectuo pago comprobante deuda ID: ".$fid." Equipo:".$deuda['eid'];
                $log = array("user" => $_SESSION['api_id']['uid'], "action" => $action);
                Loggin::register(json_encode($log));

            }else{

                EnviarAlerta('error', 'No se pudo pagar: '.$resultado);

            }
        }
    }
}

//Funcion Cancelar Pago Deuda equipo por Fid
function CancelarPagoDeudaEquipo () {

    $fid = $_POST['fid'];

    $deudas = Deuda::ObtenerPorFidEquipo($fid);

    if(is_array($deudas)){
        foreach($deudas as $deuda){
            $obj = new Deuda($deuda['dsid']. $deuda['concepto'], $deuda['fEmision'], $deuda['fVencimiento'], $deuda['importe'], $deuda['eid']);
            $resultado = $obj->modificarEquipo($concepto, $fEmision, $fVencimiento, $importe, $eid, Deuda::ESTADO_IMPAGA, $fid);


            if($resultado){

                EnviarAlerta('success', 'Se cancelo el pago correctamente: '.$resultado);

            }else{

                EnviarAlerta('error', 'No se pudo pagar: '.$resultado);

            }
        }
    }
}

//Funcion eliminar deuda socio
function EliminarDeudaSocio($dsid){
    $deuda = new Deuda($dsid);

    $resultado = $deuda->eliminarSocio();

    if($resultado){

        EnviarAlerta('success', 'Se elimino correctamente: '.$resultado);
        $action = "Elimino deuda ID: ".$dsid;
        $log = array("user" => $_SESSION['api_id']['uid'], "action" => $action);
        Loggin::register(json_encode($log));

    }else{

        EnviarAlerta('error', 'No se pudo eliminar: '.$resultado);

    }
}

//Funcion eliminar deuda equipo
function EliminarDeudaEquipo($dsid){
    $deuda = new Deuda($dsid);

    $resultado = $deuda->eliminarEquipo();

    if($resultado){

        EnviarAlerta('success', 'Se elimino correctamente: '.$resultado);
        $action = "Elimino deuda ID: ".$dsid;
        $log = array("user" => $_SESSION['api_id']['uid'], "action" => $action);
        Loggin::register(json_encode($log));

    }else{

        EnviarAlerta('error', 'No se pudo eliminar: '.$resultado);

    }
}

// Funcin dividir deudas de equipo
function DividirDeudasEquipo($eid){
    global $user;

    $equipo = Equipo::ObtenerPorId($eid);

    $NombreEquipo = $equipo->getNombre();
    $CategoriaEquipo = $equipo->GetCategoria();
    $EstadoEquipo = $equipo->GetActivo();

    $CuotaMonto = $user->GetParametro(100);
    $ContribucionDeportivaMonto = $user->GetParametro(101);

    $ContribucionDeportivaImpagas = $equipo->ListarContribucionDeportivaImpagas($month, $year);

    $multasImpagas = $equipo->ListarMultasImpagas($year);

    // Obtengo la lsita de deudas impagas del equipo
    $deudasImpagas = Deuda::ListarDeudasEquipo($equipo->GetId(), $month, $year, Deuda::ESTADO_IMPAGA);

    $ConceptoDeuda = "Baja de equipo ".$NombreEquipo;
    $ValorTotal = 0;
    $ValorPorJugador = 0;

    if(is_array($ContribucionDeportivaImpagas)){
        foreach($ContribucionDeportivaImpagas as $contribucion){

            if($contribucion['monto'] == 0)
                $ValorTotal += $ContribucionDeportivaMonto['valor'];
            else
                $ValorTotal += $contribucion['monto'];

            $cuota = new Cuota();
            $cuotas = $cuota->ListarCuotas(0, 0, 0, 0, NULL, $contribucion['fid']);

            //var_dump($contribucion);

            if(is_array($cuotas)){
                foreach($cuotas as $cuota){
                    Cuota::eliminar($cuota['cid']);
                    //echo $cuota['cid'];
                }
            }

            $factura = new Facturacion($contribucion['fid']);
            $factura->eliminar();


            $equipo->EliminarContribucionDeportiva($contribucion['cdid']);

        }
    }

    if(is_array($multasImpagas)){
        foreach($multasImpagas as $multa){
            $ValorTotal += $multa['precio'];
            $equipo->EliminarMulta($multa['mid']);
            $factura = new Facturacion($multa['fid']);
            $factura->eliminar();
        }
    }

    if(is_array($deudasImpagas)){
        foreach($deudasImpagas as $deuda){
            $ValorTotal += $deuda['importe'];
            $dd = new Deuda($deuda['dsid']);
            $dd->eliminarEquipo();
            $factura = new Facturacion($deuda['fid']);
            $factura->eliminar();
        }
    }

    $e = $equipo->TotalJugadores();
    $ValorPorJugador = $ValorTotal/$e['total'];

    $jugadores = Jugador::ListarJugadores(0, $equipo->GetId());
    //$jugadores = Jugador::listarJugadoresHistorial ($equipo->GetId(), $partido['fPartido']);

    if(is_array($jugadores)){
        foreach($jugadores as $jugador){
            $deuda = new Deuda(0, $ConceptoDeuda, date('Y-n-j'), date('Y')."-".(date('n')+1)."-".date('j'), round($ValorPorJugador), $jugador['sid']);
            $deuda->registroSocio();
            $jgdr = Jugador::ObtenerPorSid($jugador['sid']);
            $jgdr->modificar(-1);
            $jgdr->HistorialBaja();
        }
    }

    EnviarAlerta('success', 'Se dio de baja correctamente');
}

?>
