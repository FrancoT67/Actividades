
<?php
session_start();
require("core/core.php");
require("config/sys.conf.php");
require("models/class.User.php");
require("models/class.Socio.php");
require("models/class.Deportivo.php");
define("TITLE", "Jugadores");
//Llamada a la vista
if($_SESSION['api_id']['login'])
{
    $user = new User($_SESSION['api_id']['uid']);
    define("PRIVILEGIO", $temp);
    $accion = (!empty($_POST['funcion'])) ? $_POST['funcion'] : ((!empty($vista[1])) ? $vista[1] : 'index');
    $dato = (!empty($_POST['dato'])) ? $_POST['dato'] : ((!empty($vista[2])) ? $vista[2] : NULL);
    if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR || $_SESSION['api_id']['uPrivilegio'] == User::TIPO_COBRADOR)
    {
        call_user_func($accion, $dato);
    }else if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
        header("Location: /".$root."/logout");
    }else{
        ErrorPrivilegio();
    }
}else
{
    //Llamada a la vista
    header("Location: /".$root."/login");
}
//Funcion muestra vista Indice
function index (){
    $lista = Jugador::ListarJugadores(0, 0, NULL, 0);
    $jugadores = [];
    if(is_array($lista)){
        foreach($lista as $jugador){
            if($jugador['eid'] > 0){
                $jugadores[] = $jugador;
            }
        }
    }
    require_once("views/jugadores.phtml");
}
//Listar Jugadores
function ListarJugadores () {
    $jugadores = Jugador::ListarJugadores(0, 0, NULL, 0);
    if(is_array($jugadores)){
      foreach($jugadores as $j => $jugador){
        $suspensionObj = new Suspension(0, Database::TABLA_SUSPENSIONES_JUGADOR, Database::TABLA_SUSPENSIONES_JUGADOR_CUMPLIDAS, 'jid');
        $suspensiones = $suspensionObj->ListarSuspensiones($jugador['jid'], 0, 0, NULL, -1, -1, NULL);
        if(is_array($suspensiones)){
            foreach($suspensiones as $i => $suspension){
                if($suspension['fecha'] == 0){
                    $datetime1 = new DateTime(date('y-m-j'));
                    $datetime2 = new DateTime($suspensiones[$i]['fVencimiento']);
                    $interval = $datetime1->diff($datetime2);
                    $dias = $interval->format('%R%a');
                    if($dias <= 0){
                        $suspensiones[$i]['cumplida'] = 1;
                    }else{
                        $suspensiones[$i]['cumplida'] = 0;
                    }
                }else{
                    $suspensionObj->SetSPID($suspension['spid']);
                    $cumplidas = $suspensionObj->ListarFechasCumplidas();
                    $suspensiones[$i]['cumplidas'] = $cumplidas;
                    $suspensiones[$i]['cumplidas']['total'] = count($cumplidas);
                    if($suspensiones[$i]['cumplidas']['total'] >= $suspensiones[$i]['fechas']){
                        $suspensiones[$i]['cumplida']['total'] = 1;
                    }else{
                        $suspensiones[$i]['cumplida']['total'] = 0;
                    }
                }
            }
        }
        $jugadores[$j]['suspensiones'] = $suspensiones;
      }
    }
    echo json_encode($jugadores);
}
//Funcion Editar Tipo Multa
function EditarTipoMulta () {
    $tmid = $_POST['tmid'];
    $valor = $_POST['valor'];
    $multa = new Multa();
    $resultado = $multa->EditarTipoMulta($tmid, $valor);
    if($resultado){
        EnviarAlerta('success', 'Se edito la multa correctamente: '.$resultado);
    }else{
        EnviarAlerta('success', 'Se edito la multa correctamente: '.$resultado);
    }
}
//Funcion muestra vista Indice
function suspensiones (){
    require_once("views/jugadores_suspensiones.phtml");
}
//Funcion Editar
function editar ($uid){
    $funcion = 'actualizar';
    $socio =  new Socio($uid);
    $inscripcion = $socio->ConsultaInscripcion();
    if($inscripcion['estado'] == Socio::INSCRIPCION_VENCIDO){
        $colorTaskInscripcion = 'pink';
        $messageTaskInscripcion = 'VENCIDO';
    }else if($inscripcion['estado'] == Socio::INSCRIPCION_OK){
        $colorTaskInscripcion = 'teal';
        $messageTaskInscripcion = 'VALIDO';
    }else if($inscripcion['estado'] == Socio::INSCRIPCION_ADVERTENCIA){
        $colorTaskInscripcion = 'orange';
        $messageTaskInscripcion = 'POR VENCER';
    }
    $emmac = $socio->ConsultaEMMAC();
    if($emmac['estado'] == Socio::EMMAC_VENCIDO){
        $colorTaskEMMAC = 'pink';
        $messageTaskEMMAC = 'VENCIDO';
    }else if($emmac['estado'] == Socio::EMMAC_OK){
        $colorTaskEMMAC = 'teal';
        $messageTaskEMMAC = 'VALIDO';
    }else if($emmac['estado'] == Socio::EMMAC_ADVERTENCIA){
        $colorTaskEMMAC = 'orange';
        $messageTaskEMMAC = 'POR VENCER';
    }else if($emmac['estado'] == Socio::EMMAC_NA_REGISTRO){
        $colorTaskInscripcion = 'purple';
        $messageTaskInscripcion = 'SIN DATO';
    }
    $cuotasPagadas = $socio->ListarCuotasPagadas($year);
    $cuotasImpagas = $socio->ListarCuotasImpagas($year);
    $jugador = Jugador::ObtenerPorSid($socio->GetId());
    $multasPagadas = $jugador->ListarMultasPagadas($year);
    $multasImpagas = $jugador->ListarMultasImpagas($year);
    require_once("views/jugadores_ver.phtml");
}
function EliminarMulta ($mid) {
    $jugador = new Jugador();
    if($resultado = $jugador->EliminarMulta($mid)){
        EnviarAlerta('success', 'Se elimino correctamente la multa');
    }else{
        EnviarAlerta('error', 'No se elimino la cuota');
    }
}
function InsertarMulta () {
    $tmid = $_POST['tmid'];
    $fEmision = $_POST['fEmision'];
    $sid = $_POST['sid'];
    $estado = $_POST['estado'];
    //EnviarAlerta('success', $descripcion." ".$fEmision." ".$fVencimiento." ".$monto." ".$eid." ".$estado);
    $jugador = Jugador::ObtenerPorSid($sid);
    $resultado = $jugador->InsertarMulta($tmid, $fEmision, $estado);
    if($resultado == true){
        EnviarAlerta('success', 'Se inserto correctamente la multa: '.$resultado);
    }else{
        EnviarAlerta('error', 'No se inserto la multa: '.$resultado);
    }
}
//Funcion Listar Tipos Multas
function ListarTiposMultas () {
    $multas = Multa::ListarTiposMultas();
    echo json_encode($multas);
}
//Funcion Editar Multa
function EditarMulta () {
    $tmid = $_POST['tmid'];
    $fEmision = $_POST['fEmision'];
    $mid = $_POST['mid'];
    $jid = $_POST['jugador'];
    $estado = $_POST['estado'];
    $fid = $_POST['fid'];
    $jugador = new Jugador($jid);

    try {
        $jugador->EditarMulta ($mid, $tmid, $jid, $fEmision, NULL, NULL, $estado, $fid);
        EnviarAlerta('success', 'Se edito la multa correctamente: '.$fid);
    }
    
    //catch exception
    catch(Exception $e) {
        EnviarAlerta('error', 'No se pudo crear la cuota correctamente: '.$e);
    }
}
//Funcion Aisgnar Equipo
function AsignarEquipo () {
    $sid = $_POST['sid'];
    $eid = $_POST['equipo'];
    $jugador = Jugador::ObtenerPorSid($sid);
    if($jugador->GetId() > 0){
        if($resultado = $jugador->modificar($eid)){
            $jugador->HistorialBaja();
            if ($eid > 0) {
                $jugador->HistorialAlta($eid);
            }
            EnviarAlerta(1, 'Se asigno el equipo correctamente');
        }else{
            EnviarAlerta(0, 'No se pudo asignar el equipo: '.$resultado);
        }
    }else{
        $jugador = new Jugador();
        $resultado = $jugador->registro($sid, $eid, Jugador::RANGO_JUGADOR);
        if($resultado){
            $jugador->HistorialAlta($eid);
            EnviarAlerta(1, 'Se creo el jugador y asigno el equipo correctamente');
        }else{
            EnviarAlerta(0, 'No se pudo asignar el equipo: '.$resultado);
        }
    }
}
//Funcion Asignar Posicion de juego
function AsignarPosicion () {
    $jid = $_POST['jid'];
    $posicion = $_POST['posicion'];
    $jugador = new Jugador($jid);
    if($jugador->GetId() > 0){
        if($resultado = $jugador->modificar(0, NULL, $posicion)){
            EnviarAlerta('success', 'Se asigno la posicion correctamente: '.$resultado);
        }else{
            EnviarAlerta('error', 'No se pudo asignar la posicion: '.$resultado);
        }
    }
}
//Funcion Listar Suspensiones Provisorias
function ListarSuspensionesProvisorias () {
    $suspensionObj = new Suspension(0, Database::TABLA_SUSPENSIONES_JUGADOR, Database::TABLA_SUSPENSIONES_JUGADOR_CUMPLIDAS, 'jid');
    $suspensiones = $suspensionObj->ListarSuspensiones(0, 0, 0, NULL, -1, -1, NULL, Suspension::ESTADO_PROVISORIA);
    $suspensionesComision = [];
    $suspensionesTribunal = [];
    if(is_array($suspensiones)){
        foreach($suspensiones as $i => $suspension){
            $jugador = new Jugador($suspension['jid']);
            $socio = new Socio($jugador->GetSid());
            $usuario = User::ObtenerPorId($socio->GetUid());
            $suspensiones[$i]['usuario']['nombre'] = $usuario->GetNombre();
            $suspensiones[$i]['usuario']['apellido'] = $usuario->GetApellido();
            if($jugador->GetEquipo() > 0){
                $equipo = Equipo::ObtenerPorId($jugador->GetEquipo());
                $suspensiones[$i]['usuario']['equipo'] = $equipo->GetNombre();
            }
            if($suspension['fecha'] == 0){
                $datetime1 = new DateTime(date('y-m-j'));
                $datetime2 = new DateTime($suspensiones[$i]['fVencimiento']);
                $interval = $datetime1->diff($datetime2);
                $dias = $interval->format('%R%a');
                if($dias <= 0){
                    $suspensiones[$i]['cumplida'] = 1;
                }else{
                    $suspensiones[$i]['cumplida'] = 0;
                }
                $suspensionesComision[] = $suspensiones[$i];
            }else{
                $suspensionObj->SetSPID($suspension['spid']);
                $cumplidas = $suspensionObj->ListarFechasCumplidas();
                $suspensiones[$i]['cumplidas'] = count($cumplidas);
                if($suspensiones[$i]['cumplidas'] >= $suspensiones[$i]['fechas']){
                    $suspensiones[$i]['cumplida'] = 1;
                }else{
                    $suspensiones[$i]['cumplida'] = 0;
                }
                $suspensionesTribunal[] = $suspensiones[$i];
            }
        }
    }
    $resultado = array("comision" => $suspensionesComision, "tribunal" => $suspensionesTribunal);
    echo json_encode($resultado);
}
//Funcion Listar Suspensiones Efecivas
function ListarSuspensionesEfectivas () {
    $suspensionObj = new Suspension(0, Database::TABLA_SUSPENSIONES_JUGADOR, Database::TABLA_SUSPENSIONES_JUGADOR_CUMPLIDAS, 'jid');
    $suspensiones = $suspensionObj->ListarSuspensiones(0, 0, 0, NULL, -1, -1, NULL, Suspension::ESTADO_EFECTIVA);
    $suspensionesComision = [];
    $suspensionesTribunal = [];
    if(is_array($suspensiones)){
        foreach($suspensiones as $i => $suspension){
            $jugador = new Jugador($suspension['jid']);
            $socio = new Socio($jugador->GetSid());
            $usuario = User::ObtenerPorId($socio->GetUid());
            $suspensiones[$i]['usuario']['nombre'] = $usuario->GetNombre();
            $suspensiones[$i]['usuario']['apellido'] = $usuario->GetApellido();
            if($jugador->GetEquipo() > 0){
                $equipo = Equipo::ObtenerPorId($jugador->GetEquipo());
                $suspensiones[$i]['usuario']['equipo'] = $equipo->GetNombre();
            }
            if($suspension['fecha'] == 0){
                $datetime1 = new DateTime(date('y-m-j'));
                $datetime2 = new DateTime($suspensiones[$i]['fVencimiento']);
                $interval = $datetime1->diff($datetime2);
                $dias = $interval->format('%R%a');
                $suspensiones[$i]['dias'] = $dias;
                if($dias <= 0){
                    $suspensiones[$i]['cumplida'] = 1;
                }else{
                    $suspensiones[$i]['cumplida'] = 0;
                }
                $suspensionesComision[] = $suspensiones[$i];
            }else{
                $suspensionObj->SetSPID($suspension['spid']);
                $cumplidas = $suspensionObj->ListarFechasCumplidas();
                $suspensiones[$i]['cumplidas'] = count($cumplidas);
                if($suspensiones[$i]['cumplidas'] >= $suspensiones[$i]['fechas']){
                    $suspensiones[$i]['cumplida'] = 1;
                }else{
                    $suspensiones[$i]['cumplida'] = 0;
                }
                $suspensionesTribunal[] = $suspensiones[$i];
            }
        }
    }
    $resultado = array("comision" => $suspensionesComision, "tribunal" => $suspensionesTribunal);
    echo json_encode($resultado);
}
//Funcion Regex Jugadores
function RegexJugador () {
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
    $nombre = $_POST['nombre'];
    $usuarios = User::RegexUsuarios($nombre);
    $resultado = [];
    if(is_array($usuarios)){
        foreach($usuarios as $u => $usuario){
            $socio = Socio::ObtenerPorUid($usuario['id']);
            $jugador = Jugador::ObtenerPorSid($socio->GetId());
            if($jugador->GetEquipo() > 0){
                $equipo = Equipo::ObtenerPorId($jugador->GetEquipo());
                $categoria = Categoria::ObtenerPorCid($equipo->GetCategoria());
                $usuarios[$u]['sid'] = $socio->GetId();
                $usuarios[$u]['jid'] = $jugador->GetId();
                $usuarios[$u]['equipo'] = $equipo->GetNombre();
                $usuarios[$u]['categoria'] = $categoria->GetNombre();
                $resultado[] = $usuarios[$u];
            }
        }
    }
    echo json_encode($resultado);
}
//Funcion Insertar suspension comision
function InsertarSuspensionComision () {
    $jid = $_POST['jid'];
    $comentario = $_POST['comentario'];
    $fEmision = $_POST['fEmision'];
    $fVencimiento = $_POST['fVencimiento'];
    $estado = $_POST['estado'];
    $jugador = new Jugador($jid);
    $resultado = $jugador->InsertarSuspensionComision($fEmision, $fVencimiento, $estado, $comentario);
    if($resultado > 0){
        echo $resultado;
    }else{
        EnviarAlerta('error', 'No se pudo insertar la suspension: '.$resultado);
    }
}
//Funcion Editar suspension comision
function EditarSuspensionComision () {
    $spid = $_POST['spid'];
    $jid = $_POST['jid'];
    $comentario = $_POST['comentario'];
    $fEmision = $_POST['fEmision'];
    $fVencimiento = $_POST['fVencimiento'];
    $estado = $_POST['estado'];
    $suspensionObj = new Suspension($spid, Database::TABLA_SUSPENSIONES_JUGADOR, Database::TABLA_SUSPENSIONES_JUGADOR_CUMPLIDAS, 'jid');
    $resultado = $suspensionObj->modificar (0, 0, $fEmision, -1, -1, $fVencimiento, $estado, $comentario);
    if($resultado > 0){
        echo $resultado;
    }else{
        EnviarAlerta('error', 'No se pudo insertar la suspension: '.$resultado);
    }
}
//Funcion Insertar suspension tribunal
function InsertarSuspensionTribunal () {
    $jid = $_POST['jid'];
    $comentario = $_POST['comentario'];
    $fEmision = $_POST['fEmision'];
    $cmid = $_POST['cmid'];
    $fecha = $_POST['fecha'];
    $fechas = $_POST['fechas'];
    $estado = $_POST['estado'];
    $jugador = new Jugador($jid);
    $resultado = $jugador->InsertarSuspensionTribunal($fEmision, $cmid, $fecha, $fechas, $estado, $comentario);
    if($resultado > 0){
        echo $resultado;
    }else{
        EnviarAlerta('error', 'No se pudo insertar la suspension: '.$resultado);
    }
}
//Funcion Editar suspension tribunal
function EditarSuspensionTribunal () {
    $spid = $_POST['spid'];
    $jid = $_POST['jid'];
    $comentario = $_POST['comentario'];
    $fEmision = $_POST['fEmision'];
    $cmid = $_POST['cmid'];
    $fecha = $_POST['fecha'];
    $fechas = $_POST['fechas'];
    $estado = $_POST['estado'];
    $suspensionObj = new Suspension($spid, Database::TABLA_SUSPENSIONES_JUGADOR, Database::TABLA_SUSPENSIONES_JUGADOR_CUMPLIDAS, 'jid');
    $resultado = $suspensionObj->modificar (0, 0, $fEmision, $fecha, $fechas, NULL, $estado, $comentario);
    if($resultado > 0){
        echo $resultado;
    }else{
        EnviarAlerta('error', 'No se pudo insertar la suspension: '.$resultado);
    }
}
//Funcion Eliminar suspension
function EliminarSuspension () {
    $spid = $_POST['spid'];
    $suspensionObj = new Suspension($spid, Database::TABLA_SUSPENSIONES_JUGADOR, Database::TABLA_SUSPENSIONES_JUGADOR_CUMPLIDAS, 'jid');
    $resultado = $suspensionObj->eliminar ($spid);
    if($resultado > 0){
        echo $resultado;
    }else{
        EnviarAlerta('error', 'No se pudo eliminar la suspension: '.$resultado);
    }
}
//Funcion insertar fecha cumplida suspension
function InsertarFechaCumplidaSuspension () {
    $spid = $_POST['spid'];
    $fecha = $_POST['fecha'];
    $instancia = $_POST['instancia'];
    $fEmision = Date('Y-n-j');
    $suspensionObj = new Suspension($spid, Database::TABLA_SUSPENSIONES_JUGADOR, Database::TABLA_SUSPENSIONES_JUGADOR_CUMPLIDAS, 'jid');
    $resultado = $suspensionObj->InsertarFechaCumplida ($fecha, $fEmision, $instancia);
    if($resultado > 0){
        echo $resultado;
    }else{
        EnviarAlerta('error', 'No se pudo cumplir la fecha: '.$resultado);
    }
}
//Funcion Asignar delegado
function AsignarDelegado () {
    $jid = $_POST['jid'];
    $eid = $_POST['eid'];
    $JugadoresDelegado = Jugador::ListarJugadores(0, $eid, Jugador::RANGO_DELEGADO);
    if(is_array($JugadoresDelegado)){
        $delegado = new Jugador($JugadoresDelegado[0]['jid']);
        $delegado->modificar(0, Jugador::RANGO_JUGADOR);
    }
    $jugador = new Jugador($jid);
    $resultado = $jugador->modificar(0, Jugador::RANGO_DELEGADO);
    if($resultado){
        EnviarAlerta('success', 'Se Asigno correctamente como delegado: '.$resultado);
    }else{
        EnviarAlerta('error', 'No se pudo asignar al delago: '.$resultado);
    }
}
?>
