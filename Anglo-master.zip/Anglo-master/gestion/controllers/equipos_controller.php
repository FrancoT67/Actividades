<?php
session_start();
require("core/core.php");
require("config/sys.conf.php");
require("models/class.User.php");
require("models/class.Socio.php");
require("models/class.Facturacion.php");
require("models/class.Deportivo.php");

define("TITLE", "Equipos");

//Llamada a la vista
if($_SESSION['api_id']['login'])
{

  $user = new User($_SESSION['api_id']['uid']);

  define("PRIVILEGIO", $temp);

  $accion = (!empty($_POST['funcion'])) ? $_POST['funcion'] : ((!empty($vista[1])) ? $vista[1] : 'index');
  $dato = (!empty($_POST['dato'])) ? $_POST['dato'] : ((!empty($vista[2])) ? $vista[2] : NULL);

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR || $_SESSION['api_id']['uPrivilegio'] == User::TIPO_COBRADOR  || $_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO)
  {
    call_user_func($accion, $dato);
  }else{
    ErrorPrivilegio();
  }

}else
{
  //Llamada a la vista
  header("Location: /".$root."/login");
}

//Funcion muestra vista Indice
function index (){

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
    header("Location: /".$root."/logout");
  }else{
    $lista = Equipo::ListarEquipos();

    require_once("views/equipos.phtml");
  }

}

//Funcion muestra vista Indice
function suspensiones (){

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
    header("Location: /".$root."/logout");
  }else{
    require_once("views/equipos_suspensiones.phtml");
  }

}

//Funcion Regex Equipos
function RegexEquipo () {
  $nombre = $_POST['nombre'];

  $equipos = Equipo::RegexEquipo($nombre);

  echo json_encode($equipos);
}

//Funcion muestra vista agregar
function agregar (){

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
    header("Location: /".$root."/logout");
  }else{
    $funcion = 'insertar';

    $ListaCategorias = Categoria::ListarCategorias();

    require_once("views/equipos_agregar.phtml");
  }

}

//Funcion Editar
function editar ($eid){

  $funcion = 'actualizar';

  $equipo = Equipo::ObtenerPorId($eid);

  $ListaCategorias = Categoria::ListarCategorias();

  $EID = $eid;
  $Nombre = $equipo->getNombre();
  $Categoria = $equipo->getCategoria();
  $fCreacion = $equipo->GetfCreacion();

  require_once("views/equipos_agregar.phtml");

}

//Funcion Ver
function ver ($eid){

  $lista = Jugador::ListarJugadores(0, $eid);

  require_once("views/equipos_ver.phtml");

}

//Funcion Eliminar
function eliminar ($eid){

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
    header("Location: /".$root."/logout");
  }else{
    $equipo = new Equipo($eid);

    if($resultado = $equipo->eliminar()){

      EnviarAlerta('success', 'Se elimino correctamente el equipo');

    }else{

      EnviarAlerta('error', 'No se pudo eliminar el equipo');

    }
  }

}

//Funcion Insertar
function insertar (){

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
    header("Location: /".$root."/logout");
  }else{
    $Nombre = $_POST['nombre'];
    $Categoria = $_POST['categoria'];
    $fCreacion = $_POST['fCreacion'];

    $equipo = new Equipo();

    if($EID = $equipo->registro($Nombre, $Categoria, $fCreacion)){

      EnviarAlerta('success', 'Se creo el equipo correctamente');

    }else{

      EnviarAlerta('error', 'No se pudo crear el equipo.');

    }
  }
}

//Funcion Actualizar
function actualizar (){

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
    header("Location: /".$root."/logout");
  }else{
    $EID = $_POST['id'];
    $Nombre = $_POST['nombre'];
    $Categoria = $_POST['categoria'];
    $fCreacion = $_POST['fCreacion'];

    $equipo = new Equipo($EID);

    if($EID = $equipo->modificar($Nombre, $Categoria, $fCreacion)){

      EnviarAlerta('success', 'Se actualizo el equipo correctamente');

    }else{

      EnviarAlerta('error', 'No se pudo actualizar el equipo.');

    }
  }
}

function ConsultaEquipo ($eid) {

  global $user;

  $equipo = Equipo::ObtenerPorId($eid);

  $NombreEquipo = $equipo->getNombre();
  $CategoriaEquipo = $equipo->GetCategoria();
  $EstadoEquipo = $equipo->GetActivo();

  $CuotaMonto = $user->GetParametro(100);
  $ContribucionDeportivaMonto = $user->GetParametro(101);

  $ContribucionDeportivaPagadas = $equipo->ListarContribucionDeportivaPagadas($month, $year);

  $ContribucionDeportivaImpagas = $equipo->ListarContribucionDeportivaImpagas($month, $year);

  $multasPagadas = $equipo->ListarMultasPagadas($year);

  $multasImpagas = $equipo->ListarMultasImpagas($year);

  // Obtengo la lista de deudas pagadas del equipo
  $deudasPagadas = Deuda::ListarDeudasEquipo($equipo->GetId(), $month, $year, Deuda::ESTADO_PAGADA);

  // Obtengo la lsita de deudas impagas del equipo
  $deudasImpagas = Deuda::ListarDeudasEquipo($equipo->GetId(), $month, $year, Deuda::ESTADO_IMPAGA);

  $resultado = array( "equipo" => array("nombre" => $NombreEquipo, "categoria" => $CategoriaEquipo, "activo" => $EstadoEquipo),

  "dt" => $equipo->obtenerDt(1),

  "cuotamonto" => $CuotaMonto,

  "contribuciondeportivamonto" => $ContribucionDeportivaMonto,

  "contribuciondeportivapagadas" => (!empty($ContribucionDeportivaPagadas)) ? $ContribucionDeportivaPagadas : array(),

  "contribuciondeportivaimpagas" => (!empty($ContribucionDeportivaImpagas)) ? $ContribucionDeportivaImpagas : array(),

  "multaspagadas" => (!empty($multasPagadas)) ? $multasPagadas : array(),

  "multasimpagas" => (!empty($multasImpagas)) ? $multasImpagas : array(),

  "deudaspagadas" => (!empty($deudasPagadas)) ? $deudasPagadas : array(),

  "deudasimpagas" => (!empty($deudasImpagas)) ? $deudasImpagas : array()
);

echo json_encode($resultado);
}

/**
 * asignar Dt al equipo
 * @method AsignarDt
 * @param [int] eid
 * @param [int] sid
 * @return [json] message
 */
function AsignarDT ($eid) {
  $sid = $_POST['sid'];
  $equipo = Equipo::ObtenerPorId($eid);

  try {
    $equipo->insertarDt($sid);
    EnviarAlerta('success', '');
  } catch (Esxception $e) {
    EnviarAlerta('error', $e);
  }
}
/**
 * Dar de Baja Dt
 * @method DarBajaDt
 * @param [int] dtid
 * @return [] message 
 */
function DarBajaDt ($dtid){
  $equipo = new Equipo();

  try {
    $equipo->bajaDt($dtid);
    EnviarAlerta('succes', 'Se dio de baja el dt');
  } catch (Exception $e) {
    EnviarAlerta('error', $e);
  }

}

function EliminarCuota ($cid) {

  $cuota = new Cuota($cid);
  if($resultado = Cuota::eliminar($cid)){
    if ($cuota->getFid() > 0) {
      $factura = new Facturacion($cuota->getFid());
      $factura->eliminar();
    }
    EnviarAlerta('success', 'Se elimino correctamente la cuota');

  }else{

    EnviarAlerta('error', 'No se elimino la cuota');

  }

}

function EliminarMulta ($mid) {

  $equipo = new Equipo();

  if($resultado = $equipo->EliminarMulta($mid)){

    EnviarAlerta('success', 'Se elimino correctamente la multa: '.$resultado);

  }else{

    EnviarAlerta('error', 'No se elimino la multa: '.$resultado);

  }

}

//Funcion Listar Tipos Multas
function ListarTiposMultas () {
  $multas = Multa::ListarTiposMultas();

  echo json_encode($multas);
}


function InsertarMulta () {

  $tmid = $_POST['tmid'];
  $fEmision = $_POST['fEmision'];
  $eid = $_POST['eid'];
  $estado = $_POST['estado'];

  //EnviarAlerta('success', $descripcion." ".$fEmision." ".$fVencimiento." ".$monto." ".$eid." ".$estado);

  $equipo = new Equipo($eid);

  $resultado = $equipo->InsertarMulta($tmid, $fEmision, $estado);

  if($resultado == true){

    EnviarAlerta('success', 'Se inserto correctamente la multa: '.$resultado);

  }else{

    EnviarAlerta('error', 'No se inserto la multa: '.$resultado);

  }

}

function EliminarContribucionDeportiva ($cdid) {

  $equipo = new Equipo();
  $fid = $equipo->ObtenerContribucionDeportiva($cdid);

  if($resultado = $equipo->EliminarContribucionDeportiva($cdid)){
    if ($fid > 0) {
      $factura = new Facturacion($fid);
      $factura->eliminar();
      Cuota::eliminar(0, 0, NULL,$fid);
    }
    EnviarAlerta('success', 'Se elimino correctamente la contribución deportiva');

  }else{

    EnviarAlerta('error', 'No se elimino la contribución deportiva');

  }

}

//Funcion Insertar contribucion deportiva
function InsertarContribucionDeportiva () {

  $fEmision = $_POST['fEmision'];
  $fVencimiento = $_POST['fVencimiento'];
  $monto = $_POST['monto'];
  $eid = $_POST['eid'];
  $estado = $_POST['estado'];

  $equipo = new Equipo($eid);

  if($equipo->InsertarContribucionDeportiva($fEmision, $fVencimiento, $monto, $estado)){

    EnviarAlerta('success', 'Se creo la contribución deportiva correctamente');

  }else{

    EnviarAlerta('success', 'Se creo la contribución deportiva correctamente');
    //EnviarAlerta('error', 'No se pudo crear la cuota correctamente');

  }

}

//Funcion Editar Contribucion Deportiva
function EditarContribucionDeportiva (){

  $fPago = $_POST['fPago'];
  $fEmision = $_POST['fEmision'];
  $fVencimiento = $_POST['fVencimiento'];
  $monto = $_POST['monto'];
  $eid = $_POST['eid'];
  $cdid = $_POST['cdid'];
  $estado = $_POST['estado'];
  $fid = $_POST['fid'];

  $equipo = new Equipo($eid);

  $resultado = $equipo->ModificarContribucionDeportiva ($cdid, $eid, $fEmision, $fVencimiento, $fPago, $monto, $estado, $fid);

  EnviarAlerta('success', $resultado);

  if($resultado){

    //EnviarAlerta('success', 'Se edito la contribución deportiva correctamente: '.$fid);

  }else{

    //EnviarAlerta('success', 'Se edito la contribución deportiva correctamente: '.$fid);
    //EnviarAlerta('error', 'No se pudo crear la cuota correctamente');

  }

}

//Funcion Pagar Contribucion deportiva
function PagarContribucionDeportiva ($dato) {

  $cdid = $_POST['cdid'];
  $fid = $_POST['fid'];

  global $user;

  $ContribucionDeportivaMonto = $user->GetParametro(101);

  $equipo= new Equipo();

  if($resultado = $equipo->PagarContribucionDeportiva($cdid, $ContribucionDeportivaMonto['valor'], $fid))
  {

    EnviarAlerta('success', 'Se efectuo exitosamente: '.$resultado);

  }else{

    EnviarAlerta('error', 'No se pudo efectuar: '.$resultado);

  }
}

//Funcion Cenclar Pago Contribucion deportiva
function CancelarPagoContribucionDeportiva ($dato) {

  $cdid = $_POST['cdid'];
  $fid = $_POST['fid'];

  global $user;

  $ContribucionDeportivaMonto = $user->GetParametro(101);

  $equipo= new Equipo();

  if($resultado = $equipo->CancelarPagoContribucionDeportiva($cdid, $fid))
  {

    EnviarAlerta('success', 'Se efectuo exitosamente: '.$resultado);

  }else{

    EnviarAlerta('error', 'No se pudo efectuar: '.$resultado);

  }
}

//Funcion Pagar Multa
function PagarMulta ($dato) {

  // Tomo la variable global user
  global $user;

  // Obtengo datos de POST
  //$datos = explode(",", $dato);

  // Guardo MID (id de multa)
  //$mid = $datos[0];
  //$mid = $_POST['mid'];

  // Guardo monto de la multa
  //$monto = $datos[1];
  //$monto = $_POST['monto'];

  // Guardo FID (id de factura)
  $fid = $_POST['fid'];

  $equipo = new Equipo();

  if($resultado = $equipo->PagarMulta($mid, $fid))
  {

    EnviarAlerta('success', 'Se efectuo exitosamente: '.$resultado);

  }else{

    EnviarAlerta('error', 'No se pudo efectuar: '.$resultado);

  }
}

//Funcion Editar Multa
function EditarMulta (){

  $tmid = $_POST['tmid'];
  $fEmision = $_POST['fEmision'];
  $mid = $_POST['mid'];
  $eid = $_POST['equipo'];
  $estado = $_POST['estado'];
  $fid = $_POST['fid'];

  $equipo = new Equipo($eid);

  if($equipo->EditarMulta ($mid, $tmid, $eid, $fEmision, $fPago, $monto, $estado, $fid)){

    EnviarAlerta('success', 'Se edito la multa correctamente: '.$fid);

  }else{

    EnviarAlerta('success', 'Se edito la multa correctamente: '.$fid);
    //EnviarAlerta('error', 'No se pudo crear la cuota correctamente');

  }

}


//Funcion listar equipos por categoria
function ListarEquipos ($dato) {

  $lista = Equipo::ListarEquipos(0, 0, NULL, $dato);

  if(!is_array($lista)){
    $lista = array();
  }

  echo json_encode($lista);
}

//Funcion listar categorias
function ListarCategorias () {

  $lista = Categoria::ListarCategorias();

  if(!is_array($lista)){
    $lista = array();
  }

  echo json_encode($lista);
}

//Funcion Emitir contribuciones deportivas
//a todos los equipos que no tengan
//contribucion deportiva emitida del mes
function EmitirContribucionesDeportivas ($dato) {

  global $user;

  $month = $dato;

  // Obtengo lista de equipos activos
  $equipos = Equipo::ListarEquipos();

  // Obtengo el parametro de vencimiento de la cuota unica
  $Vencimiento = $user->GetParametro(102);

  // Contador de socios sin contribuciones emitidas
  $equiposSinContribuciones = 0;

  // Verifico si tengo una lista
  // y reccorro la misma para ver
  // si tienen emitida la contribucion del mes actual
  if(is_array($equipos) || is_object($equipos)) {
    foreach($equipos as $equipo) {

      if($equipo['activo'] == 1){
        // Genero objeto Socio
        $equipoTemp = new Equipo($equipo['eid']);

        $month = date('m');
        $year = date('Y');

        // Obtengo lista de contribuciones pagadas de este mes
        $contribucionesPagadas = $equipoTemp->ListarContribucionDeportiva($month, $year, Equipo::CONTRIBUCION_ESTADO_PAGADA);

        // Obtengo lista de contribuciones impagas de este mes
        $contribucionesImpagas = $equipoTemp->ListarContribucionDeportiva($month, $year, Equipo::CONTRIBUCION_ESTADO_IMPAGA);

        //if(count($contribucionesPagadas) == 0 && count($contribucionesImpagas) == 0 && $equipo['activo']) {
        if($equipo['activo']) {
          $equipoTemp->InsertarContribucionDeportiva(date('Y-n-j'), date('Y-n')."-".$Vencimiento['valor'], 0, Equipo::CONTRIBUCION_ESTADO_IMPAGA);
          $equiposSinContribuciones++;
        }
      }
    }

    if($equiposSinContribuciones > 0){

      EnviarAlerta('success', 'Se efectuo exitosamente');

    }else{

      EnviarAlerta('error', 'No se pudo efectuar');

    }
  }
}

//Funcion Estadisticas publicas
function EstadisticasEquipo () {

  $eid = $_POST['eid'];

  $equipoObj = Equipo::ObtenerPorId($eid);
  $categoria = Categoria::ObtenerPorCid($equipoObj->GetCategoria());

  $ListaCampeonatos = Campeonato::ListarCampeonatos(0, 0, $equipoObj->GetCategoria());
  $arquero = Jugador::ListarJugadores(0, $eid, NULL, 0, Jugador::POSICION_ARQUERO);
  $delegado = Jugador::ListarJugadores(0, $eid, Jugador::RANGO_DELEGADO);
  $jugadores = Jugador::ListarJugadores(0, $eid);

  $equipo['nombre'] = $equipoObj->GetNombre();
  $equipo['categoria'] = $categoria->GetNombre();
  $equipo['arquero'] = $arquero[0];
  $equipo['delegado'] = $delegado[0];
  $equipo['jugadores'] = $jugadores;
  $equipo['posicion'] = 0;
  $equipo['pj'] = 0;
  $equipo['pg'] = 0;
  $equipo['pe'] = 0;
  $equipo['pp'] = 0;
  $equipo['gf'] = 0;
  $equipo['gc'] = 0;
  $equipo['pts'] = 0;
  $equipo['ps']= 0; //Partidos suspendidos

  $timeNow = date('H:i:s');

  if(is_array($ListaCampeonatos)){

    $idCampeonato = end($ListaCampeonatos);
    $campeonato = new Campeonato($idCampeonato['cmid']);
    $partidos = $campeonato->ListarFechas(0, $eid);
    $objPartido = new Partido();

    $golesJugadores = $campeonato->GolesPorJugador($eid);

    if(is_array($golesJugadores)){
      foreach($golesJugadores as $ju => $gol){
        $jugador = new Jugador($gol['jid']);
        $socio = new Socio($jugador->GetSid());
        $usuario = User::ObtenerPorId($socio->GetUid());
        $golesJugadores[$ju]['apellido'] = $usuario->GetApellido();
        $golesJugadores[$ju]['nombre'] = $usuario->GetNombre();
      }
    }

    if(is_array($partidos) || is_object($partidos)){
      foreach($partidos as $p => $partido){
        $DiffTime = strtotime($partido['hPartido']) - strtotime($timeNow);
        $DiffDate = FechaJuliana(date($partido['fPartido'])) - FechaJuliana(date('Y-n-j'));

        $eidRival = ($partido['eid1'] != $eid) ? $partido['eid1'] : $partido['eid2'];
        $rival = Equipo::ObtenerPorId($eidRival);
        $partidos[$p]['rival'] = $rival->GetNombre();

        if((GetDif($partido['fPartido']) == true && $DiffDate < 0 && $partido['fPartido'] != '0000-00-00') || ($DiffDate == 0 && $DiffTime < 0  && $partido['fPartido'] != '0000-00-00')){
          $equipo['pj'] += 1;
          $golesEquipo1 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid1']);
          $golesEquipo2 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid2']);
          $totalGolesEquipo1 = 0;
          $totalGolesEquipo2 = 0;

          if($partido['suspendido'] == -1){

            $golesEquipo1 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid1']);

            if(is_array($golesEquipo1) || is_object($golesEquipo1)){
              foreach($golesEquipo1 as $goles){
                $totalGolesEquipo1 += $goles['cantidad'];
              }
            }

            $golesEquipo2 = $objPartido->ListarGoles(0, $partido['ptid'], 0, $partido['eid2']);

            if(is_array($golesEquipo2) || is_object($golesEquipo2)){
              foreach($golesEquipo2 as $goles){
                $totalGolesEquipo2 += $goles['cantidad'];
              }
            }

            $partidos[$p]['gol1'] = $totalGolesEquipo1;
            $partidos[$p]['gol2'] = $totalGolesEquipo2;
            $partidos[$p]['estado'] = -1;

            if($partido['eid1'] == $eid){
              $equipo['gf'] += $totalGolesEquipo1;
              $equipo['gc'] += $totalGolesEquipo2;
              if($totalGolesEquipo1 > $totalGolesEquipo2){
                $equipo['pg'] += 1;
                $equipo['pts'] += 3;
              }else if($totalGolesEquipo1 < $totalGolesEquipo2){
                $equipo['pp'] += 1;
              }
            }else if($partido['eid2'] == $eid){
              $equipo['gc'] += $totalGolesEquipo1;
              $equipo['gf'] += $totalGolesEquipo2;
              if($totalGolesEquipo2 > $totalGolesEquipo1){
                $equipo['pg'] += 1;
                $equipo['pts'] += 3;
              }else if($totalGolesEquipo2 < $totalGolesEquipo1){
                $equipo['pp'] += 1;
              }
            }

            if($totalGolesEquipo2 == $totalGolesEquipo1){
              $equipo['pe'] += 1;
              $equipo['pts'] += 1;
            }
          }else{
            if($partido['suspendido'] == $eid){
              //$equipo['pg'] += 1;
              $equipo['pts'] += 3;
              $partidos[$p]['estado'] = 'Suspendido Ganado';
            }else if($partido['suspendido'] != $eid){
              //$equipo['pp'] += 1;
              $equipo['ps'] += 1;
              $partidos[$p]['estado'] = 'Suspendido Perdido';
            }
          }
        }
      }
    }
  }

  $equipo['goleadores'] = $golesJugadores;

  echo json_encode(array("equipo" => $equipo, "partidos" => $partidos));
}

//Funcion total Jugadores
function TotalJugadores($dato){
  // Genero el objeto equipo apartir del EID
  $equipo = Equipo::ObtenerPorId($dato);

  $totalJugadores = $equipo->TotalJugadores();

  echo $totalJugadores['total'];
}

//Funcion dar baja Equipo
function DarBaja ($dato) {

  // Genero el objeto Equipo apartir del dato POST
  $equipo = new Equipo($dato);

  // Confirmo si se efectuo la accion
  if($resultado = $equipo->DarBaja())
  {

    EnviarAlerta('success', 'Se efectuo exitosamente: '.$resultado);

  }else{

    EnviarAlerta('error', 'No se pudo efectuar: '.$resultado);

  }

}

// Funcion Deudas Equipo
function deudasEquipo($eid){

  global $user;

  $equipoObj = Equipo::ObtenerPorId($eid);
  $contribuciones = $equipoObj->ListarContribucionDeportiva(0, 0, Equipo::CONTRIBUCION_ESTADO_IMPAGA);
  // Obtengo el parametro del valor de la cuota unica
  $CuotaMonto = $user->GetParametro(101);
  if($equipoObj->GetId() > 0){
    $multas = $equipoObj->ListarMultasImpagas();
  }
  $deudas = Deuda::ListarDeudasEquipo($eid, 0, 0, Deuda::ESTADO_IMPAGA);

  $lista = array();

  $fidCuotasUnicas = array();

  if(is_array($contribuciones)){
    foreach($contribuciones as $contribucion){
      $saldo = 0;
      if($contribucion['fid'] > 0){
        $cobros = Cobro::ListarCobros(0, $contribucion['fid']);
        if(is_array($cobros)){
          foreach($cobros as $cobro){
            $saldo += $cobro['monto'];
          }
        }
      }
      $monto = (($contribucion['monto'] == 0) ? $CuotaMonto['valor'] : $contribucion['monto']);
      $lista[] = array("descripcion" => 'Cuota '.FormatDate($contribucion['fEmision']).(($contribucion['fid'] > 0) ? ' Factura ID: '.$contribucion['fid'] : ''),
      "equipo" => $equipoObj->GetNombre(),
      "monto" => $monto,
      "saldo" => $monto-$saldo,
      "fEmision" => $contribucion['fEmision'], "fVencimiento" => $contribucion['fVencimiento']);
      $fidCuotasUnicas[] = $contribucion['fid'];
    }
  }

  if(is_array($multas)){
    foreach($multas as $multa){
      $tipoMulta = Multa::ListarTiposMultas($multa['tmid']);
      $saldo = 0;
      if($multa['fid'] > 0){
        $cobros = Cobro::ListarCobros(0, $multa['fid']);
        if(is_array($cobros)){
          foreach($cobros as $cobro){
            $saldo += $cobro['monto'];
          }
        }
      }
      $monto = (($multa['monto'] == 0) ? $tipoMulta[0]['precio'] : $multa['monto']);
      $lista[] = array("descripcion" => 'Multa '.FormatDate($multa['fEmision']).(($multa['fid'] > 0) ? ' Factura ID: '.$multa['fid'] : ''),
      "equipo" => $equipoObj->GetNombre(),
      "monto" => $monto,
      "saldo" => $monto-$saldo,
      "fEmision" => $multa['fEmision'], "fVencimiento" => '');
    }
  }

  if(is_array($deudas)){
    foreach($deudas as $deuda){
      $saldo = 0;
      if($deuda['fid'] > 0){
        $cobros = Cobro::ListarCobros(0, $deuda['fid']);
        if(is_array($cobros)){
          foreach($cobros as $cobro){
            $saldo += $cobro['monto'];
          }
        }
      }
      $lista[] = array("descripcion" => $deuda['concepto'].(($deuda['fid'] > 0) ? ' Factura ID: '.$deuda['fid'] : ''),
      "equipo" => $equipoObj->GetNombre(),
      "monto" => $deuda['importe'],
      "saldo" => $deuda['importe']-$saldo,
      "fEmision" => $deuda['fEmision'], "fVencimiento" => $deuda['fVencimiento']);
    }
  }

  //Deudas jugadores
  $jugadores = Jugador::ListarJugadores(0, $eid);

  if(is_array($jugadores)){
    foreach($jugadores as $jugador){
      $cuotas = Cuota::ListarCuotas(0, $jugador['sid'], 0, 0, Cuota::ESTADO_IMPAGA);
      $objJugador= Jugador::ObtenerPorSid($jugador['sid']);
      // Obtengo el parametro del valor de la cuota social
      $CuotaMonto = $user->GetParametro(100);
      if($objJugador->GetId() > 0){
        $multas = $objJugador->ListarMultasImpagas();
      }

      $deudas = Deuda::ListarDeudasSocio($jugador['sid'], 0, 0, Deuda::ESTADO_IMPAGA);

      if(is_array($cuotas)){
        foreach($cuotas as $cuota){
          if(!in_array($cuota['fid'], $fidCuotasUnicas)){
            $saldo = 0;
            if($cuota['fid'] > 0){
              $cobros = Cobro::ListarCobros(0, $cuota['fid']);
              if(is_array($cobros)){
                foreach($cobros as $cobro){
                  $saldo += $cobro['monto'];
                }
              }
            }
            $monto = (($cuota['monto'] == 0) ? $CuotaMonto['valor'] : $cuota['monto']);
            $lista[] = array("descripcion" => $jugador['apellido'].' '.$jugador['nombre'].' Cuota '.FormatDate($cuota['fEmision'].(($cuota['fid'] > 0) ? ' Factura ID: '.$cuota['fid'] : '')),
            "equipo" => $equipoObj->GetNombre(),
            "monto" => $monto,
            "saldo" => $monto-$saldo,
            "fEmision" => $cuota['fEmision'], "fVencimiento" => $cuota['fVencimiento']);
          }
        }
      }

      if(is_array($multas)){
        foreach($multas as $multa){
          $tipoMulta = Multa::ListarTiposMultas($multa['tmid']);
          $saldo = 0;
          if($multa['fid'] > 0){
            $cobros = Cobro::ListarCobros(0, $multa['fid']);
            if(is_array($cobros)){
              foreach($cobros as $cobro){
                $saldo += $cobro['monto'];
              }
            }
          }
          $monto = (($multa['monto'] == 0) ? $tipoMulta[0]['precio'] : $multa['monto']);
          $lista[] = array("descripcion" => $jugador['apellido'].' '.$jugador['nombre'].' Multa '.FormatDate($multa['fEmision'].(($multa['fid'] > 0) ? ' Factura ID: '.$multa['fid'] : '')),
          "equipo" => $equipoObj->GetNombre(),
          "monto" => $monto,
          "saldo" => $monto-$saldo,
          "fEmision" => $multa['fEmision'], "fVencimiento" => '');
        }
      }

      if(is_array($deudas)){
        foreach($deudas as $deuda){
          $saldo = 0;
          if($deuda['fid'] > 0){
            $cobros = Cobro::ListarCobros(0, $deuda['fid']);
            if(is_array($cobros)){
              foreach($cobros as $cobro){
                $saldo += $cobro['monto'];
              }
            }
          }
          $lista[] = array("descripcion" => $jugador['apellido'].' '.$jugador['nombre'].' '.$deuda['concepto'].(($deuda['fid'] > 0) ? ' Factura ID: '.$deuda['fid'] : ''),
          "equipo" => $equipoObj->GetNombre(),
          "monto" => $deuda['importe'],
          "saldo" => $deuda['importe']-$saldo,
          "fEmision" => $deuda['fEmision'], "fVencimiento" => $deuda['fVencimiento']);
        }
      }
    }
  }

  echo json_encode($lista);
}

//Funcion Insertar Deuda
function InsertarDeuda (){

  $fEmision = $_POST['fEmision'];
  $fVencimiento = $_POST['fVencimiento'];
  $monto = $_POST['fImporte'];
  $descripcion = $_POST['dDescripcion'];
  $eid = $_POST['eid'];
  $estado = $_POST['estado'];

  $deuda = new Deuda(0, $descripcion, $fEmision, $fVencimiento, $monto, $eid);
  if($deuda->registroEquipo()){

    EnviarAlerta('success', 'Se creo la deuda correctamente');

  }else{

    EnviarAlerta('success', 'Se creo la deuda correctamente');
    //EnviarAlerta('error', 'No se pudo crear la cuota correctamente');

  }  

}

/**
 * Listar jugadores suspendidos equipo
 * @method listarJugadoresSuspendidosEquipo
 * @param [int] equipo id
 * @return [json] jugadores
 */
function listarJugadoresSuspendidosEquipo ($eid) {
  $suspendidos = Jugador::ListarJugadoresSuspendidos($eid);

  echo json_encode($suspendidos);
}
?>
