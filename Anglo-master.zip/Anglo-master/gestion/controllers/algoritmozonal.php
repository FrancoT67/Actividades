
<?php
ini_set('max_execution_time', 300);
$equipos = array("equipo1", "equipo2","equipo3",
				 "equipo4","equipo5","equipo6","equipo7",
				 "equipo8","equipo9","equipo10","equipo11",
				 "equipo12","equipo13","equipo14","equipo15",
				 "equipo16", "equipo17", "equipo18", "equipo19",
				 "equipo20", "equipo21", "equipo22");
$zonas = 4;

$countequipos = count($equipos);
$totalEquiposGrupo = $countequipos/$zonas;
$grupos = array();
$equiposUsados = array();
$random = 0;

//Asignacion de equipos a zonas
for($i = 1; $i < $zonas+1; $i++){
    for($j = 0; $j < $totalEquiposGrupo; $j++){
        //$random = mt_rand() % ($countequipos);
        $random = randomNumber(0, $countequipos-1, $equiposUsados);
        $equiposUsados[] = $random;
        $grupos[$i-1]['equipos'][] = $equipos[$random];
    }
}


for($i = 1; $i < $zonas+1; $i++){
echo "Grupo ".$i."<br>";
foreach($grupos[$i - 1]['equipos'] as $a){
echo $a."<br>";
}
}

function randomNumber($from, $to, array $excluded = [])
{
$func = function_exists('random_int') ? 'random_int' : 'mt_rand';

do {
$number = $func($from, $to);
} while (in_array($number, $excluded, true));

return $number;
}

?>
