<?php
session_start();
require("core/core.php");
require("config/sys.conf.php");
require("models/class.User.php");
require("models/class.Socio.php");
require("models/class.Deportivo.php");

define("TITLE", 'Suspensiones');

//Llamada a la vista
if($_SESSION['api_id']['login'])
{

    $user = new User($_SESSION['api_id']['uid']);

    define("PRIVILEGIO", $temp);

    $accion = (!empty($_POST['funcion'])) ? $_POST['funcion'] : ((!empty($vista[1])) ? $vista[1] : 'index');
    $dato = (!empty($_POST['dato'])) ? $_POST['dato'] : ((!empty($vista[2])) ? $vista[2] : NULL);

    if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR)
    {
        call_user_func($accion, $dato);
    }else{
        ErrorPrivilegio();
    }

}else
{
    //Llamada a la vista
    header("Location: /".$root."/login");
}

//Funcion muestra vista Indice
function index () {

    require_once("views/jugadores_suspensiones.phtml");

}
?>
