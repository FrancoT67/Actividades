<?php
session_start();
require("core/core.php");
require("config/sys.conf.php");
require("models/class.User.php");
require("models/class.Socio.php");
require("models/class.Facturacion.php");
require("models/class.Deportivo.php");

define("TITLE", 'Informes');

//Llamada a la vista
if($_SESSION['api_id']['login'])
{

  $user = new User($_SESSION['api_id']['uid']);

  define("PRIVILEGIO", $temp);

  $accion = (!empty($_POST['funcion'])) ? $_POST['funcion'] : ((!empty($vista[1])) ? $vista[1] : 'index');
  $dato = (!empty($_POST['dato'])) ? $_POST['dato'] : ((!empty($vista[2])) ? $vista[2] : NULL);

  if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ADMINISTRADOR || $_SESSION['api_id']['uPrivilegio'] == User::TIPO_COBRADOR)
  {
      call_user_func($accion, $dato);
  }else if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_ESTADISTA){
      header("Location: /".$root."/campeonatos");
  }else if($_SESSION['api_id']['uPrivilegio'] == User::TIPO_INVITADO){
      header("Location: /".$root."/logout");
  }else{
      header("Location: /".$root."/logout");
  }

}else
{
  header("Location: /".$root."/logout");
}

//Funcion muestra vista Indice
function index () {

    require_once("views/informes.phtml");

}

function deudaSocios () {

    global $user;

    $socios = Socio::ListarSocios();

    $count = 0;

    if(is_array($socios)){
        foreach($socios as $socio){
            $cuotas = Cuota::ListarCuotas(0, $socio['sid'], 0, 0, Cuota::ESTADO_IMPAGA);
            $jugador = Jugador::ObtenerPorSid($socio['sid']);
            // Obtengo el parametro del valor de la cuota social
            $CuotaMonto = $user->GetParametro(100);
            if($jugador->GetId() > 0){
                $multas = $jugador->ListarMultasImpagas();
            }

            $deudas = Deuda::ListarDeudasSocio($socio['sid'], 0, 0, Deuda::ESTADO_IMPAGA);

            $socios[$count]['cuotas'] = $cuotas;
            $socios[$count]['multas'] = $multas;
            $socios[$count]['deudas'] = $deudas;
            $socios[$count]['cuotaMonto'] = $CuotaMonto;

            $count++;
        }
    }

    require_once("views/informe_deuda_socios.phtml");

}

function deudaEquipos () {

    global $user;

    $equipos = Equipo::ListarEquipos();

    $count = 0;

    if(is_array($equipos)){
        foreach($equipos as $equipo){
            $equipoObj = new Equipo($equipo['eid']);
            $categoria = Categoria::ObtenerPorCid($equipo['categoria']);
            $contribuciones = $equipoObj->ListarContribucionDeportiva(0, 0, Equipo::CONTRIBUCION_ESTADO_IMPAGA);
            // Obtengo el parametro del valor de la cuota unica
            $CuotaMonto = $user->GetParametro(101);
            if($equipoObj->GetId() > 0){
                $multas = $equipoObj->ListarMultasImpagas();
            }
            $deudas = Deuda::ListarDeudasEquipo($equipo['eid'], 0, 0, Deuda::ESTADO_IMPAGA);

            $equipos[$count]['contribuciones'] = $contribuciones;
            $equipos[$count]['multas'] = $multas;
            $equipos[$count]['deudas'] = $deudas;
            $equipos[$count]['categoriaO'] = $categoria;
            $equipos[$count]['cuotaMonto'] = $CuotaMonto;

            $count++;
        }
    }

    require_once("views/informe_deuda_equipos.phtml");

}

function sociosActivos () {

    $jugadores = Jugador::ListarJugadores(0, 0, NULL, Socio::ESTADO_ACTIVO);

    if(is_array($jugadores)){
        foreach($jugadores as $j => $jugador){
            $categoria = Categoria::ObtenerPorCid($jugador['categoria']);

            $jugadores[$j]['categoriaO'] = $categoria;
        }
    }

    require_once("views/informe_socios_activos.phtml");

}

function cobranzas () {

    require_once("views/informe_cobranzas.phtml");

}

?>
